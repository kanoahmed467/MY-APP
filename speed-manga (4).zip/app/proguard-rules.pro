# R8 / ProGuard Optimizations for Jetpack Compose, Coil, and Network Stack
-dontwarn javax.annotation.**
-dontwarn org.codehaus.mojo.animal_sniffer.**

# Jetpack Compose inline and layout optimizations
-keepclassmembers class * {
    @androidx.compose.runtime.Composable *;
}
-dontwarn androidx.compose.**

# Coil Image Loader
-keep class coil.** { *; }
-dontwarn coil.**

# OkHttp & Moshi Data Serialization
-keepclassmembers class * {
    @com.squareup.moshi.Json *;
}
-keep class com.example.data.models.** { *; }
-keep class com.example.data.local.** { *; }

# Kotlin Coroutines
-keepclassmembers class kotlinx.coroutines.** { *; }

