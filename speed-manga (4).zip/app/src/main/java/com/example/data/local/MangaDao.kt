package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MangaDao {
    @Query("SELECT * FROM favorites ORDER BY addedAt DESC")
    fun getAllFavorites(): Flow<List<FavoriteMangaEntity>>

    @Query("SELECT * FROM favorites WHERE mangaId = :mangaId LIMIT 1")
    fun getFavoriteById(mangaId: String): Flow<FavoriteMangaEntity?>

    @Query("SELECT * FROM favorites WHERE mangaId = :mangaId LIMIT 1")
    suspend fun getFavoriteByIdDirect(mangaId: String): FavoriteMangaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteMangaEntity)

    @Query("DELETE FROM favorites WHERE mangaId = :mangaId")
    suspend fun deleteFavorite(mangaId: String)

    @Query("SELECT * FROM reading_history ORDER BY updatedAt DESC")
    fun getReadingHistory(): Flow<List<ReadingHistoryEntity>>

    @Query("SELECT * FROM reading_history WHERE mangaId = :mangaId LIMIT 1")
    fun getHistoryById(mangaId: String): Flow<ReadingHistoryEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: ReadingHistoryEntity)

    @Query("SELECT * FROM comments WHERE mangaId = :mangaId ORDER BY timestamp DESC")
    fun getCommentsForManga(mangaId: String): Flow<List<CommentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: CommentEntity)

    @Query("UPDATE comments SET likes = :likes, isLikedByMe = :isLiked WHERE id = :commentId")
    suspend fun updateCommentLike(commentId: String, likes: Int, isLiked: Boolean)

    @Query("SELECT * FROM downloaded_chapters ORDER BY downloadedAt DESC")
    fun getAllDownloadedChapters(): Flow<List<DownloadedChapterEntity>>

    @Query("SELECT * FROM downloaded_chapters")
    suspend fun getAllDownloadedChaptersDirect(): List<DownloadedChapterEntity>

    @Query("SELECT * FROM downloaded_chapters WHERE chapterId = :chapterId LIMIT 1")
    fun getDownloadedChapter(chapterId: String): Flow<DownloadedChapterEntity?>

    @Query("SELECT * FROM downloaded_chapters WHERE chapterId = :chapterId LIMIT 1")
    suspend fun getDownloadedChapterDirect(chapterId: String): DownloadedChapterEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownloadedChapter(downloaded: DownloadedChapterEntity)

    @Query("DELETE FROM downloaded_chapters WHERE chapterId = :chapterId")
    suspend fun deleteDownloadedChapter(chapterId: String)
}
