package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "favorites")
data class FavoriteMangaEntity(
    @PrimaryKey val mangaId: String,
    val title: String,
    val titleArabic: String,
    val coverUrl: String,
    val rating: Float,
    val totalChapters: Int,
    val status: String,
    val category: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "reading_history")
data class ReadingHistoryEntity(
    @PrimaryKey val mangaId: String,
    val mangaTitle: String,
    val coverUrl: String,
    val chapterId: String,
    val chapterTitle: String,
    val lastPageIndex: Int,
    val totalPages: Int,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "comments")
data class CommentEntity(
    @PrimaryKey val id: String,
    val mangaId: String,
    val chapterId: String? = null,
    val userName: String,
    val userAvatar: String = "",
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val likes: Int = 0,
    val isLikedByMe: Boolean = false
)

@Entity(tableName = "downloaded_chapters")
data class DownloadedChapterEntity(
    @PrimaryKey val chapterId: String,
    val mangaId: String,
    val mangaTitle: String,
    val chapterTitle: String,
    val coverUrl: String,
    val localPagePathsJson: String, // Comma-separated or JSON list of local file paths
    val downloadedAt: Long = System.currentTimeMillis(),
    val totalSizeMb: String = "0 MB"
)
