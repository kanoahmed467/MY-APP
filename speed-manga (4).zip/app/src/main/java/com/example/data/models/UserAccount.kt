package com.example.data.models

data class UserAccount(
    val id: String = java.util.UUID.randomUUID().toString(),
    val name: String = "",
    val email: String = "",
    val passwordHash: String = "",
    val isVerified: Boolean = false,
    val verificationCode: String = "",
    val avatarUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
