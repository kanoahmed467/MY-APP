package com.example.data.network

import android.util.Log
import okhttp3.Dns
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.UnknownHostException

/**
 * High-performance, Cellular/Mobile-Data friendly DNS implementation for OkHttp.
 * Prioritizes IPv4 addresses first to eliminate 12-second socket connection hangs
 * on cellular networks (WE, Vodafone, Orange, Etisalat) where IPv6 routes are often unrouted or dropped.
 */
object FastDns : Dns {
    private const val TAG = "FastDns"

    override fun lookup(hostname: String): List<InetAddress> {
        return try {
            val addresses = Dns.SYSTEM.lookup(hostname)
            reorderIPv4First(addresses)
        } catch (e: UnknownHostException) {
            Log.w(TAG, "System DNS failed for $hostname, attempting Direct InetAddress lookup...")
            try {
                val sysAddresses = InetAddress.getAllByName(hostname).toList()
                if (sysAddresses.isNotEmpty()) {
                    reorderIPv4First(sysAddresses)
                } else {
                    throw e
                }
            } catch (_: Exception) {
                throw e
            }
        }
    }

    private fun reorderIPv4First(addresses: List<InetAddress>): List<InetAddress> {
        val ipv4 = addresses.filterIsInstance<Inet4Address>()
        val ipv6 = addresses.filterIsInstance<Inet6Address>()
        return if (ipv4.isNotEmpty()) {
            ipv4 + ipv6
        } else {
            addresses
        }
    }
}
