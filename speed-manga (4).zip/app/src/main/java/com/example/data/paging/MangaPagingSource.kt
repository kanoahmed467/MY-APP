package com.example.data.paging

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.example.data.models.MangaItem

class MangaPagingSource(
    private val fetchPage: suspend (page: Int) -> List<MangaItem>
) : PagingSource<Int, MangaItem>() {

    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, MangaItem> {
        val page = params.key ?: 1
        return try {
            val response = fetchPage(page)
            LoadResult.Page(
                data = response,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (response.isEmpty()) null else page + 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, MangaItem>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }
}
