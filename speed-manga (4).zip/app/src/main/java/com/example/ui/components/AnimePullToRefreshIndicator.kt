package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.pulltorefresh.PullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.DarkSurface

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnimePullToRefreshIndicator(
    state: PullToRefreshState,
    isRefreshing: Boolean,
    modifier: Modifier = Modifier
) {
    // Anime loading GIF (Nezuko running)
    val gifUrl = "https://media.tenor.com/bYx3VjW3lGMAAAAj/nezuko-kamado.gif"
    
    val scale by animateFloatAsState(
        targetValue = if (isRefreshing) 1f else state.distanceFraction.coerceIn(0f, 1f),
        label = "pull_scale"
    )

    Box(
        modifier = modifier
            .padding(top = 16.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = scale
                translationY = state.distanceFraction * 100f // Pull down effect
            }
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(DarkSurface)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(gifUrl)
                .crossfade(true)
                .build(),
            contentDescription = "Loading",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
