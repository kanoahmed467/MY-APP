package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.automirrored.filled.FormatListBulleted
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.LibraryCategory
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaRedLight
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab

import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Verified
import com.example.data.models.UserAccount

@Composable
fun AppNavigationDrawerContent(
    currentTab: MainTab,
    currentUser: UserAccount? = null,
    onSelectTab: (MainTab) -> Unit,
    onSelectLibraryCategory: (LibraryCategory) -> Unit,
    onCloseDrawer: () -> Unit,
    onSelectGenre: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    ModalDrawerSheet(
        drawerContainerColor = DarkSurface,
        drawerContentColor = TextPrimary,
        modifier = modifier.width(280.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .background(DarkSurface)
                .statusBarsPadding()
        ) {
            // Profile Header Section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        onSelectTab(MainTab.PROFILE)
                        onCloseDrawer()
                    }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar Placeholder
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MangaRedPrimary.copy(alpha = 0.2f))
                        .border(1.5.dp, MangaRedPrimary, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = currentUser?.name?.take(1)?.uppercase() ?: "؟",
                        color = MangaRedPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = currentUser?.name ?: "تسجيل الدخول",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        if (currentUser?.isVerified == true) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "حساب مفعل",
                                tint = Color(0xFF4CAF50),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = if (currentUser != null) currentUser.email else "اضغط لإنشاء حساب مفعل",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                // Bell Notifications Button
                IconButton(onClick = {
                    onSelectTab(MainTab.PROFILE)
                    onCloseDrawer()
                }) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "الإشعارات",
                        tint = TextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            HorizontalDivider(color = DarkBorder, thickness = 1.dp)

            // Scrollable Menu List
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 8.dp)
            ) {
                DrawerMenuItem(
                    label = "آخر التحديثات",
                    icon = Icons.Default.NewReleases,
                    isSelected = currentTab == MainTab.HOME,
                    hasAlertBadge = true,
                    onClick = {
                        onSelectTab(MainTab.HOME)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "لائحة المانجا",
                    icon = Icons.AutoMirrored.Filled.FormatListBulleted,
                    isSelected = currentTab == MainTab.EXPLORE,
                    onClick = {
                        onSelectTab(MainTab.EXPLORE)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "التصنيفات",
                    icon = Icons.Default.Category,
                    isSelected = false,
                    onClick = {
                        onSelectTab(MainTab.EXPLORE)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "أفضل المانجات",
                    icon = Icons.Default.BarChart,
                    isSelected = false,
                    onClick = {
                        onSelectGenre("أفضل المانجات")
                        onSelectTab(MainTab.EXPLORE)
                        onCloseDrawer()
                    }
                )

                DrawerSectionHeader(title = "تحميلاتي")

                DrawerMenuItem(
                    label = "المانجات المحملة",
                    icon = Icons.Default.CloudDownload,
                    isSelected = currentTab == MainTab.DOWNLOADED_MANGA,
                    onClick = {
                        onSelectTab(MainTab.DOWNLOADED_MANGA)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "قائمة التحميل",
                    icon = Icons.Default.CloudQueue,
                    isSelected = currentTab == MainTab.DOWNLOAD_QUEUE,
                    onClick = {
                        onSelectTab(MainTab.DOWNLOAD_QUEUE)
                        onCloseDrawer()
                    }
                )

                DrawerSectionHeader(title = "قائمتي ومكتبتي")

                DrawerMenuItem(
                    label = "المفضلة",
                    icon = Icons.Default.Favorite,
                    isSelected = currentTab == MainTab.FAVORITES,
                    onClick = {
                        onSelectTab(MainTab.FAVORITES)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "قائمتي والمكتبة",
                    icon = Icons.AutoMirrored.Filled.FormatListBulleted,
                    isSelected = currentTab == MainTab.LIBRARY,
                    onClick = {
                        onSelectTab(MainTab.LIBRARY)
                        onCloseDrawer()
                    }
                )

                DrawerMenuItem(
                    label = "سجل القراءة",
                    icon = Icons.Default.History,
                    isSelected = currentTab == MainTab.LIBRARY,
                    onClick = {
                        onSelectLibraryCategory(LibraryCategory.HISTORY)
                        onSelectTab(MainTab.LIBRARY)
                        onCloseDrawer()
                    }
                )

                DrawerSectionHeader(title = "الإعدادات")

                DrawerMenuItem(
                    label = "الإعدادات",
                    icon = Icons.Default.Settings,
                    isSelected = currentTab == MainTab.PROFILE,
                    onClick = {
                        onSelectTab(MainTab.PROFILE)
                        onCloseDrawer()
                    }
                )
            }
        }
    }
}

@Composable
private fun DrawerSectionHeader(title: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
        )
    }
}

@Composable
private fun DrawerMenuItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    hasAlertBadge: Boolean = false
) {
    val backgroundColor = if (isSelected) MangaRedLight.copy(alpha = 0.15f) else Color.Transparent
    val textColor = if (isSelected) MangaRedPrimary else TextPrimary
    val iconColor = if (isSelected) MangaRedPrimary else TextSecondary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (hasAlertBadge) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(MangaRedPrimary),
                contentAlignment = Alignment.Center
            ) {
                Text("!", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        } else {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = textColor,
            modifier = Modifier.weight(1f)
        )
    }
}
