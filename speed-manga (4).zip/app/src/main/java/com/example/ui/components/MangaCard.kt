package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.models.MangaItem
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

private val CardShape = RoundedCornerShape(14.dp)
private val ImageShape = RoundedCornerShape(10.dp)
private val ImageListShape = RoundedCornerShape(topStart = 13.dp, topEnd = 13.dp)
private val PillShape = RoundedCornerShape(16.dp)

private val CardBgColor = Color(0xFF1B1629)
private val ImageBgColor = Color(0xFF251F36)
private val PillBgColor = Color(0xFF2C243E)
private val BorderColor = Color(0xFF2A233D)

private val ChapterRegex = Regex("\\d+")

@Composable
fun MangaCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier,
    isListView: Boolean = false
) {
    if (isListView) {
        MangaListCard(manga = manga, onClick = onClick, modifier = modifier)
    } else {
        MangaGridCard(manga = manga, onClick = onClick, modifier = modifier)
    }
}

/**
 * Grid View Card matching the Video Design:
 * Dark rounded container (0xFF1A1528), high quality cover, title, and "الفصل-XX" pill badge
 */
@Composable
fun MangaGridCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Image Request with exact grid target size (200x280) for low-RAM background decoding
    val imageRequest = remember(manga.coverUrl, manga.id) {
        ImageRequest.Builder(context)
            .data(manga.coverUrl.ifBlank { null })
            .memoryCacheKey(manga.coverUrl.ifBlank { manga.id })
            .diskCacheKey(manga.coverUrl.ifBlank { manga.id })
            .crossfade(true)
            .size(200, 280)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .placeholder(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .error(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .build()
    }

    val titleText = remember(manga.titleArabic, manga.title) {
        manga.titleArabic.ifEmpty { manga.title }
    }

    val displayRating = remember(manga.rating) {
        if (manga.rating > 0) String.format(java.util.Locale.US, "%.1f", manga.rating) else "8.0"
    }

    val isCompleted = remember(manga.status) {
        manga.status.contains("منتهي") || manga.status.contains("Completed", ignoreCase = true)
    }
    val statusText = if (isCompleted) "منتهية" else "مستمرة"
    val statusColor = if (isCompleted) Color(0xFFF87171) else Color(0xFF4ADE80)

    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = androidx.compose.animation.core.spring(stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
        label = "card_scale"
    )

    val clickModifier = remember(manga, onClick, interactionSource) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null
        ) { onClick(manga) }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CardShape)
            .background(CardBgColor)
            .then(clickModifier)
            .padding(6.dp)
            .testTag("manga_grid_card_${manga.id}"),
        horizontalAlignment = Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(ImageShape)
                .background(ImageBgColor)
        ) {
            if (manga.coverUrl.isNotBlank()) {
                AsyncImage(
                    model = imageRequest,
                    contentDescription = titleText,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                    contentDescription = null,
                    tint = MangaRedPrimary.copy(alpha = 0.7f),
                    modifier = Modifier
                        .size(24.dp)
                        .align(Alignment.Center)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Title
        Text(
            text = titleText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Start,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Status + Rating Row (Manga Slayer Style)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = statusText,
                color = statusColor,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = MangaGold,
                    modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = displayRating,
                    color = MangaGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Detailed List View Card
 */
@Composable
fun MangaListCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Target size tailored for list cover bounds (164x230 for 82x115dp at 2x scale)
    val imageRequest = remember(manga.coverUrl, manga.id) {
        ImageRequest.Builder(context)
            .data(manga.coverUrl.ifBlank { null })
            .memoryCacheKey(manga.coverUrl.ifBlank { manga.id })
            .diskCacheKey(manga.coverUrl.ifBlank { manga.id })
            .crossfade(true)
            .size(164, 230)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .placeholder(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .error(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .build()
    }

    val chapterNum = remember(manga.latestChapter) {
        ChapterRegex.find(manga.latestChapter)?.value ?: "1"
    }

    val titleText = remember(manga.titleArabic, manga.title) {
        manga.titleArabic.ifEmpty { manga.title }
    }

    val displayRating = remember(manga.rating) {
        String.format(java.util.Locale.US, "%.1f", manga.rating)
    }

    val genresText = remember(manga.genres) {
        if (manga.genres.isNotEmpty()) manga.genres.take(4).joinToString(" ,") else "أكشن, خيال"
    }

    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by androidx.compose.animation.core.animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1f,
        animationSpec = androidx.compose.animation.core.spring(stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
        label = "list_card_scale"
    )

    val clickModifier = remember(manga, onClick, interactionSource) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null
        ) { onClick(manga) }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CardShape)
            .background(CardBgColor)
            .then(clickModifier)
            .border(1.dp, BorderColor, CardShape)
            .padding(8.dp)
            .testTag("manga_list_card_${manga.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Cover Image Box
            Box(
                modifier = Modifier
                    .width(82.dp)
                    .height(115.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(ImageBgColor)
            ) {
                if (manga.coverUrl.isNotBlank()) {
                    AsyncImage(
                        model = imageRequest,
                        contentDescription = titleText,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = null,
                        tint = MangaRedPrimary,
                        modifier = Modifier
                            .size(28.dp)
                            .align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Information Column (Manga Slayer Style)
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                // Title
                Text(
                    text = titleText,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Chapter
                Text(
                    text = "الفصل-$chapterNum",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextMuted
                )

                // Status
                Text(
                    text = manga.status.ifEmpty { "مستمرة" },
                    fontSize = 12.sp,
                    color = TextMuted
                )

                // Categories / Genres
                Text(
                    text = genresText,
                    fontSize = 11.sp,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Rating
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = MangaGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = displayRating,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MangaGold
                    )
                }
            }
        }
    }
}

