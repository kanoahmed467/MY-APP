package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.UserAccount
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.AuthManager
import com.example.utils.EmailSender
import com.example.utils.FirebaseEmailLinkAuthManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AuthMode {
    LOGIN,
    REGISTER,
    MAGIC_LINK,
    VERIFY_CODE
}

@Composable
fun AuthScreen(
    authManager: AuthManager,
    onAuthSuccess: (UserAccount) -> Unit,
    onBackClick: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val coroutineScope = rememberCoroutineScope()

    val firebaseEmailLinkAuthManager = remember { FirebaseEmailLinkAuthManager(context, authManager) }
    val googleAuthManager = remember { com.example.utils.GoogleAuthManager(context, authManager) }

    var currentMode by remember { mutableStateOf(AuthMode.LOGIN) }

    // Form inputs
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember {
        mutableStateOf(firebaseEmailLinkAuthManager.getSavedEmailForSignIn() ?: "")
    }
    var passwordInput by remember { mutableStateOf("") }
    var confirmPasswordInput by remember { mutableStateOf("") }
    var verificationCodeInput by remember { mutableStateOf("") }
    var pastedLinkInput by remember { mutableStateOf("") }

    var isPasswordVisible by remember { mutableStateOf(false) }
    var isConfirmPasswordVisible by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    var resendTimer by remember { mutableIntStateOf(60) }

    // SMTP Config Dialog state
    var showSmtpDialog by remember { mutableStateOf(false) }
    var smtpHostInput by remember { mutableStateOf(EmailSender.getSmtpHost(context)) }
    var smtpPortInput by remember { mutableStateOf(EmailSender.getSmtpPort(context).toString()) }
    var smtpEmailInput by remember { mutableStateOf(EmailSender.getSenderEmail(context)) }
    var smtpPassInput by remember { mutableStateOf(EmailSender.getSenderPass(context)) }

    LaunchedEffect(currentMode) {
        if (currentMode == AuthMode.VERIFY_CODE) {
            resendTimer = 60
            while (resendTimer > 0) {
                delay(1000)
                resendTimer--
            }
        }
    }

    // SMTP Settings Modal Dialog
    if (showSmtpDialog) {
        AlertDialog(
            onDismissRequest = { showSmtpDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Settings, contentDescription = null, tint = MangaRedPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إعدادات بريد الإرسال (SMTP / Gmail)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "لإرسال أكواد تفعيل حقيقية عبر SMTP، أدخل بيانات حساب Gmail الخاص بك:",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 17.sp
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkBackground)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "💡 نصيحة لـ Gmail:\nاستخدم كلمة مرور التطبيق (App Password) وليس كلمة مرور حسابك العادية.",
                            fontSize = 11.sp,
                            color = MangaGold,
                            lineHeight = 16.sp
                        )
                    }

                    OutlinedTextField(
                        value = smtpEmailInput,
                        onValueChange = { smtpEmailInput = it },
                        label = { Text("بريد المُرسل (Gmail)") },
                        placeholder = { Text("your_email@gmail.com") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    OutlinedTextField(
                        value = smtpPassInput,
                        onValueChange = { smtpPassInput = it },
                        label = { Text("كلمة مرور التطبيق (App Password)") },
                        placeholder = { Text("xxxx xxxx xxxx xxxx") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = smtpHostInput,
                            onValueChange = { smtpHostInput = it },
                            label = { Text("السيرفر (SMTP Host)") },
                            singleLine = true,
                            modifier = Modifier.weight(2f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MangaRedPrimary,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )

                        OutlinedTextField(
                            value = smtpPortInput,
                            onValueChange = { smtpPortInput = it },
                            label = { Text("المنفذ") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MangaRedPrimary,
                                unfocusedBorderColor = DarkBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val port = smtpPortInput.toIntOrNull() ?: 465
                        EmailSender.saveSmtpSettings(
                            context = context,
                            host = smtpHostInput,
                            port = port,
                            senderEmail = smtpEmailInput,
                            senderPass = smtpPassInput
                        )
                        showSmtpDialog = false
                        Toast.makeText(context, "تم حفظ إعدادات SMTP بنجاح!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                ) {
                    Text("حفظ الإعدادات")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSmtpDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .statusBarsPadding()
            .testTag("auth_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Top Bar Back Button if needed
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBackClick != null) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("auth_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = Color.White
                        )
                    }
                }
                Spacer(modifier = Modifier.weight(1f))

                // SMTP Config button
                IconButton(onClick = { showSmtpDialog = true }) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "إعدادات البريد",
                        tint = if (EmailSender.isSmtpConfigured(context)) Color(0xFF4CAF50) else TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // App Logo & Welcome Banner
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(MangaRedPrimary.copy(alpha = 0.15f))
                    .border(1.5.dp, MangaRedPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = MangaRedPrimary,
                    modifier = Modifier.size(42.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "SpeedManga",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = when (currentMode) {
                    AuthMode.LOGIN -> "مرحباً بك مجدداً! سجل دخولك لمتابعة قراءة المانجا"
                    AuthMode.REGISTER -> "أنشئ حسابك الجديد واستلم رمز التفعيل على بريدك الإلكتروني"
                    AuthMode.MAGIC_LINK -> "الدخول السريع باستخدام رابط البريد الإلكتروني بدون كلمة سر (Firebase Link)"
                    AuthMode.VERIFY_CODE -> "تأكيد الحساب بواسطة كود التفعيل المستلم في البريد"
                },
                fontSize = 13.sp,
                color = TextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (currentMode != AuthMode.VERIFY_CODE) {
                // Google Sign-In Button
                Button(
                    onClick = {
                        focusManager.clearFocus()
                        isLoading = true
                        errorMessage = ""
                        statusMessage = ""
                        coroutineScope.launch {
                            val result = googleAuthManager.signInWithGoogle(context)
                            isLoading = false
                            result.onSuccess { user ->
                                Toast.makeText(context, "تم تسجيل الدخول بواسطة Google بنجاح! أهلاً بك ${user.name} 🎉", Toast.LENGTH_SHORT).show()
                                onAuthSuccess(user)
                            }.onFailure { err ->
                                errorMessage = err.message ?: "فشلت عملية تسجيل الدخول باستخدام Google"
                            }
                        }
                    },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("auth_google_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFDDDDDD))
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.Black, strokeWidth = 2.5.dp)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "G",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = Color(0xFF4285F4)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "تسجيل الدخول باستخدام Google",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = Color(0xFF3C4043)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // OR Divider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(DarkBorder)
                    )
                    Text(
                        text = "أو باستخدام البريد الإلكتروني",
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(1.dp)
                            .background(DarkBorder)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tab Switcher between Login, Register, Magic Link
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurface,
                    border = BorderStroke(1.dp, DarkBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (currentMode == AuthMode.LOGIN) MangaRedPrimary else Color.Transparent)
                                .clickable {
                                    currentMode = AuthMode.LOGIN
                                    errorMessage = ""
                                    statusMessage = ""
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "تسجيل الدخول",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (currentMode == AuthMode.LOGIN) Color.White else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (currentMode == AuthMode.REGISTER) MangaRedPrimary else Color.Transparent)
                                .clickable {
                                    currentMode = AuthMode.REGISTER
                                    errorMessage = ""
                                    statusMessage = ""
                                }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "إنشاء حساب جديد",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = if (currentMode == AuthMode.REGISTER) Color.White else TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }

            // Error message banner if any
            if (errorMessage.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF3E1218))
                        .border(1.dp, Color(0xFFFF5252).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = errorMessage,
                        color = Color(0xFFFF8A8A),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Status message banner if any
            if (statusMessage.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF132E1B))
                        .border(1.dp, Color(0xFF4CAF50).copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = statusMessage,
                        color = Color(0xFF81C784),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Form Content based on AuthMode
            when (currentMode) {
                AuthMode.LOGIN -> {
                    // Email Field
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = {
                            emailInput = it
                            errorMessage = ""
                        },
                        label = { Text("البريد الإلكتروني") },
                        placeholder = { Text("example@gmail.com") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = MangaRedPrimary)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_email_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            errorMessage = ""
                        },
                        label = { Text("كلمة المرور") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MangaRedPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = TextMuted
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Login Button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            isLoading = true
                            val result = authManager.login(emailInput, passwordInput)
                            isLoading = false
                            result.onSuccess { user ->
                                Toast.makeText(context, "أهلاً بك مجدداً ${user.name} 👋", Toast.LENGTH_SHORT).show()
                                onAuthSuccess(user)
                            }.onFailure { err ->
                                errorMessage = err.message ?: "حدث خطأ في تسجيل الدخول"
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("auth_login_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
                        } else {
                            Text("تسجيل الدخول", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            if (emailInput.isBlank() || !emailInput.contains("@")) {
                                errorMessage = "يرجى إدخال بريد إلكتروني صحيح لإرسال رابط الدخول"
                                return@OutlinedButton
                            }
                            isLoading = true
                            errorMessage = ""
                            statusMessage = ""
                            coroutineScope.launch {
                                val result = firebaseEmailLinkAuthManager.sendSignInLinkToEmail(
                                    email = emailInput,
                                    continueUrl = "https://speed-manga.web.app"
                                )
                                isLoading = false
                                result.onSuccess {
                                    statusMessage = "تم إرسال رابط الدخول المباشر إلى بريدك ($emailInput) 📩! افتح بريدك المباشر واضغط على الرابط لتسجيل الدخول بنقرة واحدة."
                                }.onFailure { err ->
                                    errorMessage = err.message ?: "فشل إرسال رابط الدخول"
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MangaRedPrimary.copy(alpha = 0.5f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إرسال رابط دخول مباشر للبريد (بدون كلمة سر) 📩", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                AuthMode.REGISTER -> {
                    // Full Name Field
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = {
                            nameInput = it
                            errorMessage = ""
                        },
                        label = { Text("الاسم الكامل / اسم المستخدم") },
                        placeholder = { Text("مثال: أحمد علي") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Person, contentDescription = null, tint = MangaRedPrimary)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_name_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Email Field
                    OutlinedTextField(
                        value = emailInput,
                        onValueChange = {
                            emailInput = it
                            errorMessage = ""
                        },
                        label = { Text("البريد الإلكتروني") },
                        placeholder = { Text("example@gmail.com") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = MangaRedPrimary)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_register_email_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Password Field
                    OutlinedTextField(
                        value = passwordInput,
                        onValueChange = {
                            passwordInput = it
                            errorMessage = ""
                        },
                        label = { Text("كلمة المرور") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MangaRedPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = TextMuted
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Next),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_register_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Confirm Password Field
                    OutlinedTextField(
                        value = confirmPasswordInput,
                        onValueChange = {
                            confirmPasswordInput = it
                            errorMessage = ""
                        },
                        label = { Text("تأكيد كلمة المرور") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MangaRedPrimary)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isConfirmPasswordVisible = !isConfirmPasswordVisible }) {
                                Icon(
                                    imageVector = if (isConfirmPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = TextMuted
                                )
                            }
                        },
                        singleLine = true,
                        visualTransformation = if (isConfirmPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_confirm_password_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Register Button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            if (passwordInput != confirmPasswordInput) {
                                errorMessage = "كلمات المرور غير متطابقة!"
                                return@Button
                            }

                            isLoading = true
                            errorMessage = ""
                            statusMessage = ""

                            val isConfigured = EmailSender.isSmtpConfigured(context)
                            val regResult = authManager.register(nameInput, emailInput, passwordInput, requireEmailVerification = true)

                            regResult.onSuccess { newUser ->
                                coroutineScope.launch {
                                    if (isConfigured) {
                                        val emailRes = EmailSender.sendVerificationEmail(
                                            context = context,
                                            recipientEmail = newUser.email,
                                            userName = newUser.name,
                                            verificationCode = newUser.verificationCode
                                        )
                                        isLoading = false
                                        emailRes.onSuccess {
                                            statusMessage = "تم إرسال كود التفعيل المكون من 6 أرقام إلى بريدك الإلكتروني (${newUser.email}) بنجاح 📩"
                                            currentMode = AuthMode.VERIFY_CODE
                                        }.onFailure { err ->
                                            errorMessage = "فشل إرسال البريد الإلكتروني: ${err.message}. يمكنك محاولة إدخال الكود أو ضبط إعدادات SMTP."
                                            currentMode = AuthMode.VERIFY_CODE
                                        }
                                    } else {
                                        isLoading = false
                                        statusMessage = "تم إنشاء الحساب! رمز التفعيل الخاص بك هو: ${newUser.verificationCode} (يمكنك ربط Gmail لرسائل حقيقية)"
                                        currentMode = AuthMode.VERIFY_CODE
                                    }
                                }
                            }.onFailure { err ->
                                isLoading = false
                                errorMessage = err.message ?: "فشل إنشاء الحساب"
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("auth_register_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text("جاري إرسال البريد الإلكتروني...", fontSize = 14.sp)
                            }
                        } else {
                            Text("إنشاء حساب وإرسال كود التفعيل 📩", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            focusManager.clearFocus()
                            if (emailInput.isBlank() || !emailInput.contains("@")) {
                                errorMessage = "يرجى إدخال بريد إلكتروني صحيح لإرسال رابط التسجيل"
                                return@OutlinedButton
                            }
                            isLoading = true
                            errorMessage = ""
                            statusMessage = ""
                            coroutineScope.launch {
                                val result = firebaseEmailLinkAuthManager.sendSignInLinkToEmail(
                                    email = emailInput,
                                    continueUrl = "https://speed-manga.web.app"
                                )
                                isLoading = false
                                result.onSuccess {
                                    statusMessage = "تم إرسال رابط تفعيل الحساب المباشر إلى بريدك ($emailInput) 📩! يرجى فتح البريد والضغط على الرابط لتأكيد الحساب والدخول."
                                }.onFailure { err ->
                                    errorMessage = err.message ?: "فشل إرسال رابط التفعيل"
                                }
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MangaRedPrimary.copy(alpha = 0.5f))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Email, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("أو إرسال رابط تفعيل مباشر إلى البريد الإلكتروني 📩", fontSize = 12.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                AuthMode.MAGIC_LINK -> {
                    // Fallback to Login
                    LaunchedEffect(Unit) {
                        currentMode = AuthMode.LOGIN
                    }
                }

                AuthMode.VERIFY_CODE -> {
                    // Card explaining code sent to email
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, MangaGold.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        colors = CardDefaults.cardColors(containerColor = DarkSurface)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MarkEmailRead,
                                    contentDescription = null,
                                    tint = MangaGold,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "تم إرسال كود التفعيل إلى بريدك",
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    fontSize = 15.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = emailInput,
                                fontWeight = FontWeight.Bold,
                                color = MangaGold,
                                fontSize = 14.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "يرجى تفقد صندوق الوارد (Inbox) أو مجلد البريد غير المرغوب فيه (Spam) لإدخال الكود المكون من 6 أرقام.",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // 6-digit Code Input Field
                    OutlinedTextField(
                        value = verificationCodeInput,
                        onValueChange = {
                            if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                                verificationCodeInput = it
                                errorMessage = ""
                            }
                        },
                        label = { Text("أدخل كود التفعيل (6 أرقام)") },
                        placeholder = { Text("123456") },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MangaRedPrimary)
                        },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focusManager.clearFocus() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("auth_verification_code_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MangaRedPrimary,
                            unfocusedBorderColor = DarkBorder,
                            focusedLabelColor = MangaRedPrimary,
                            unfocusedLabelColor = TextMuted,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Confirm Code Button
                    Button(
                        onClick = {
                            focusManager.clearFocus()
                            if (verificationCodeInput.length != 6) {
                                errorMessage = "يرجى إدخال الكود المكون من 6 أرقام كاملاً"
                                return@Button
                            }
                            isLoading = true
                            val result = authManager.verifyEmail(emailInput, verificationCodeInput)
                            isLoading = false
                            result.onSuccess { verifiedUser ->
                                Toast.makeText(context, "تم تفعيل حسابك بنجاح! مرحباً ${verifiedUser.name} 🎉", Toast.LENGTH_LONG).show()
                                onAuthSuccess(verifiedUser)
                            }.onFailure { err ->
                                errorMessage = err.message ?: "كود التفعيل غير صحيح"
                            }
                        },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("auth_verify_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("تأكيد الكود وتفعيل الحساب", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Resend Code & Switch Email buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                coroutineScope.launch {
                                    val res = authManager.resendVerificationCode(emailInput)
                                    res.onSuccess { code ->
                                        resendTimer = 60
                                        if (EmailSender.isSmtpConfigured(context)) {
                                            EmailSender.sendVerificationEmail(context, emailInput, nameInput, code)
                                            Toast.makeText(context, "تم إعادة إرسال الكود إلى بريدك 📩", Toast.LENGTH_SHORT).show()
                                        } else {
                                            statusMessage = "رمز التفعيل الجديد الخاص بك هو: $code"
                                        }
                                    }
                                }
                            },
                            enabled = resendTimer == 0,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (resendTimer == 0) MangaRedPrimary else DarkBorder)
                        ) {
                            Text(
                                text = if (resendTimer > 0) "إعادة الإرسال ($resendTimer ث)" else "إعادة إرسال الكود",
                                fontSize = 12.sp,
                                color = if (resendTimer == 0) MangaRedPrimary else TextMuted
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                currentMode = AuthMode.REGISTER
                                errorMessage = ""
                                statusMessage = ""
                            },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DarkBorder)
                        ) {
                            Text(text = "تعديل البريد", fontSize = 12.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}
