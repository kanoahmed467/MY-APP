package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.MangaItem
import com.example.ui.components.AppTopBar
import com.example.ui.components.MangaCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextSecondary

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.snapshotFlow

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ExploreScreen(
    mangas: List<MangaItem>,
    searchResults: List<MangaItem> = emptyList(),
    searchQuery: String,
    selectedGenre: String?,
    isOnline: Boolean = true,
    isLoadingHome: Boolean = false,
    isSearching: Boolean = false,
    isLoadingMore: Boolean = false,
    isListView: Boolean = false,
    isSearchMode: Boolean = false,
    onQueryChange: (String) -> Unit,
    onGenreSelect: (String) -> Unit,
    onLoadNextPage: () -> Unit = {},
    onMangaClick: (MangaItem) -> Unit,
    onOpenDrawer: () -> Unit = {},
    onToggleViewMode: () -> Unit = {},
    onOpenSearch: () -> Unit = {},
    onCloseSearch: () -> Unit = {},
    onRefresh: () -> Unit = {}
) {
    val genres = listOf("الكل", "أفضل المانجات", "أكشن", "مانهوا", "إيسيكاي", "مغامرة", "خيال", "كوميديا", "دراما", "فنون قتالية")
    val gridState = rememberLazyGridState()
    val scrollState = rememberScrollState()

    val filteredList = mangas

    // Prefetch next page smoothly 6 items before hitting bottom
    val shouldLoadNextPage by androidx.compose.runtime.remember(gridState, filteredList.size, searchQuery) {
        androidx.compose.runtime.derivedStateOf {
            val total = filteredList.size
            val visible = gridState.layoutInfo.visibleItemsInfo.size
            val firstIndex = gridState.firstVisibleItemIndex
            total > 0 && (firstIndex + visible) >= total - 6 && searchQuery.isBlank()
        }
    }

    LaunchedEffect(shouldLoadNextPage) {
        if (shouldLoadNextPage) {
            onLoadNextPage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Red Top Header Bar
        AppTopBar(
            title = if (isSearchMode) "" else (if (selectedGenre.isNullOrBlank() || selectedGenre == "الكل") "لائحة المانجا" else selectedGenre),
            isListView = isListView,
            isSearchMode = isSearchMode,
            searchQuery = searchQuery,
            onOpenDrawer = onOpenDrawer,
            onToggleViewMode = onToggleViewMode,
            onOpenSearch = onOpenSearch,
            onCloseSearch = onCloseSearch,
            onSearchQueryChange = onQueryChange
        )

        // Offline Banner Alert
        if (!isOnline) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MangaGold.copy(alpha = 0.15f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.WifiOff,
                    contentDescription = null,
                    tint = MangaGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "يرجى الاتصال بالإنترنت لتصفح التحديثات المباشرة. يمكنك قراءة الفصول المحملة.",
                    fontSize = 12.sp,
                    color = MangaGold,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        val pullRefreshState = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState()
        PullToRefreshBox(
            isRefreshing = isLoadingHome,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize(),
            state = pullRefreshState,
            indicator = {
                com.example.ui.components.AnimePullToRefreshIndicator(
                    state = pullRefreshState,
                    isRefreshing = isLoadingHome,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        ) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(if (isListView) 1 else 3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 8.dp, bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                // Genre Filter Chips Row (Flat Row with horizontalScroll)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(scrollState)
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    genres.forEach { genre ->
                        val isSelected = (selectedGenre == genre) || (selectedGenre == null && genre == "الكل")
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (isSelected) MangaRedPrimary else DarkSurface)
                                .clickable { onGenreSelect(genre) }
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                                .testTag("explore_genre_chip_$genre")
                        ) {
                            Text(
                                text = genre,
                                fontSize = 12.sp,
                                color = if (isSelected) Color.White else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            if ((isLoadingHome || isSearching) && filteredList.isEmpty()) {
                items(
                    count = 9,
                    key = { "skeleton_$it" },
                    contentType = { "skeleton" }
                ) {
                    if (isListView) {
                        com.example.ui.components.MangaListCardSkeleton()
                    } else {
                        com.example.ui.components.MangaGridCardSkeleton()
                    }
                }
            } else if (filteredList.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isSearching) "جاري البحث المباشر..." else "لم نجد أي مانجا تطابق نتائج البحث",
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                items(
                    items = filteredList,
                    key = { it.id },
                    contentType = { "manga_card" }
                ) { item ->
                    MangaCard(
                        manga = item,
                        onClick = onMangaClick,
                        isListView = isListView
                    )
                }

                if (isLoadingMore) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = MangaRedPrimary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }
        }
      }
    }
}
