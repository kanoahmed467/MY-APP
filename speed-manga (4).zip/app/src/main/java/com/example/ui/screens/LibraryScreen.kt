package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.DownloadedChapterEntity
import com.example.data.local.FavoriteMangaEntity
import com.example.data.local.ReadingHistoryEntity
import com.example.data.models.LibraryCategory
import com.example.data.models.MangaItem
import com.example.ui.components.MangaCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LibraryScreen(
    favorites: List<FavoriteMangaEntity>,
    history: List<ReadingHistoryEntity>,
    downloadedChapters: List<DownloadedChapterEntity> = emptyList(),
    allMangas: List<MangaItem>,
    selectedCategory: LibraryCategory,
    onCategoryChange: (LibraryCategory) -> Unit,
    onMangaClick: (MangaItem) -> Unit,
    onRemoveFavorite: (String) -> Unit,
    onBackClick: () -> Unit = {},
    onOpenDownloadedChapter: (DownloadedChapterEntity) -> Unit = {},
    onDeleteDownloadedChapter: (String, String) -> Unit = { _, _ -> }
) {
    val filteredFavorites by remember(favorites, selectedCategory) {
        derivedStateOf {
            when (selectedCategory) {
                LibraryCategory.ALL -> favorites
                LibraryCategory.FAVORITE -> favorites.filter { it.category == LibraryCategory.FAVORITE.name || it.category == "FAVORITE" }
                LibraryCategory.READING -> favorites.filter { it.category == LibraryCategory.READING.name || it.category == "READING" }
                LibraryCategory.PLAN_TO_READ -> favorites.filter { it.category == LibraryCategory.PLAN_TO_READ.name || it.category == "PLAN_TO_READ" }
                LibraryCategory.COMPLETED -> favorites.filter { it.category == LibraryCategory.COMPLETED.name || it.category == "COMPLETED" }
                LibraryCategory.HISTORY -> emptyList()
                LibraryCategory.DOWNLOADED -> emptyList()
            }
        }
    }

    val isHistoryMode = selectedCategory == LibraryCategory.HISTORY
    val isDownloadedMode = selectedCategory == LibraryCategory.DOWNLOADED

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(top = 8.dp)
            .testTag("library_screen")
    ) {
        // App Header with Back Arrow Navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackClick,
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkSurface)
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "رجوع",
                    tint = TextPrimary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "قائمتي والمكتبة",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 20.sp
                )
                Text(
                    text = if (isHistoryMode) "سجل القراءة (${history.size})" else if (isDownloadedMode) "الفصول المحملة (${downloadedChapters.size})" else "إجمالي المكتبة (${favorites.size})",
                    fontSize = 12.sp,
                    color = MangaRedPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Library Category Filter Chips
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(LibraryCategory.values()) { category ->
                val isSelected = selectedCategory == category

                val count = when (category) {
                    LibraryCategory.ALL -> favorites.size
                    LibraryCategory.DOWNLOADED -> downloadedChapters.size
                    LibraryCategory.FAVORITE -> favorites.count { it.category == LibraryCategory.FAVORITE.name || it.category == "FAVORITE" }
                    LibraryCategory.READING -> favorites.count { it.category == LibraryCategory.READING.name || it.category == "READING" }
                    LibraryCategory.PLAN_TO_READ -> favorites.count { it.category == LibraryCategory.PLAN_TO_READ.name || it.category == "PLAN_TO_READ" }
                    LibraryCategory.COMPLETED -> favorites.count { it.category == LibraryCategory.COMPLETED.name || it.category == "COMPLETED" }
                    LibraryCategory.HISTORY -> history.size
                }

                val icon: ImageVector = when (category) {
                    LibraryCategory.ALL -> Icons.Default.Bookmark
                    LibraryCategory.DOWNLOADED -> Icons.Default.DownloadDone
                    LibraryCategory.FAVORITE -> Icons.Default.Favorite
                    LibraryCategory.READING -> Icons.Default.PlayCircle
                    LibraryCategory.PLAN_TO_READ -> Icons.AutoMirrored.Filled.MenuBook
                    LibraryCategory.COMPLETED -> Icons.Default.CheckCircle
                    LibraryCategory.HISTORY -> Icons.Default.History
                }

                FilterChip(
                    selected = isSelected,
                    onClick = { onCategoryChange(category) },
                    label = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = if (isSelected) Color.White else MangaRedPrimary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${category.displayName} ($count)",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = DarkSurface,
                        labelColor = TextPrimary,
                        selectedContainerColor = MangaRedPrimary,
                        selectedLabelColor = Color.White
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = DarkBorder,
                        selectedBorderColor = MangaRedPrimary,
                        enabled = true,
                        selected = isSelected
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Main List Content
        if (isDownloadedMode) {
            if (downloadedChapters.isEmpty()) {
                EmptyLibraryState(
                    icon = Icons.Default.DownloadDone,
                    title = "لا توجد فصول محملة",
                    subtitle = "قم بتحميل الفصول لقراءتها دون الحاجة للاتصال بالإنترنت."
                )
            } else {
                val downloadedMangas = remember(downloadedChapters) { downloadedChapters.groupBy { it.mangaId } }
                val downloadedMangaItems = remember(downloadedMangas, allMangas) {
                    downloadedMangas.map { (mangaId, chapters) ->
                        val first = chapters.first()
                        val matched = allMangas.find { it.id == mangaId }
                        matched?.copy(latestChapter = "${chapters.size} فصل محمل") ?: MangaItem(
                            id = mangaId,
                            title = first.mangaTitle,
                            titleArabic = first.mangaTitle,
                            coverUrl = first.coverUrl,
                            latestChapter = "${chapters.size} فصل محمل",
                            rating = 7.5f,
                            status = "مستمرة",
                            totalChapters = chapters.size
                        )
                    }
                }

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 80.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(downloadedMangaItems, key = { it.id }, contentType = { "manga_card" }) { manga ->
                        MangaCard(
                            modifier = Modifier.animateItem(),
                            manga = manga,
                            isListView = false,
                            onClick = onMangaClick
                        )
                    }
                }
            }
        } else if (isHistoryMode) {
            if (history.isEmpty()) {
                EmptyLibraryState(
                    icon = Icons.Default.History,
                    title = "سجل القراءة فارغ",
                    subtitle = "ستظهر الأقسام والفصول التي تقرأها هنا لمتابعتها لاحقاً."
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 80.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(history, key = { it.mangaId }) { hist ->
                        val matchedManga = remember(allMangas, hist) {
                            allMangas.find { it.id == hist.mangaId } ?: MangaItem(
                                id = hist.mangaId,
                                title = hist.mangaTitle,
                                titleArabic = hist.mangaTitle,
                                coverUrl = hist.coverUrl
                            )
                        }

                        val interactionSource = remember { MutableInteractionSource() }
                        val isPressed by interactionSource.collectIsPressedAsState()
                        val scale by animateFloatAsState(
                            targetValue = if (isPressed) 0.97f else 1f,
                            label = "hist_scale"
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    scaleX = scale
                                    scaleY = scale
                                }
                                .clip(RoundedCornerShape(14.dp))
                                .background(DarkSurface)
                                .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
                                .clickable(
                                    interactionSource = interactionSource,
                                    indication = null
                                ) { onMangaClick(matchedManga) }
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = hist.coverUrl,
                                    contentDescription = hist.mangaTitle,
                                    modifier = Modifier
                                        .size(52.dp, 74.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = hist.mangaTitle,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        fontSize = 15.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = hist.chapterTitle,
                                        fontSize = 12.sp,
                                        color = MangaGold,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val progress = if (hist.totalPages > 0) (hist.lastPageIndex + 1).toFloat() / hist.totalPages else 0f
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(CircleShape),
                                        color = MangaRedPrimary,
                                        trackColor = DarkBorder
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "الصفحة ${hist.lastPageIndex + 1} من ${hist.totalPages}",
                                        fontSize = 11.sp,
                                        color = TextMuted
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (filteredFavorites.isEmpty()) {
                EmptyLibraryState(
                    icon = Icons.Default.Bookmark,
                    title = "لا توجد أعمال في '${selectedCategory.displayName}'",
                    subtitle = "أضف أعمالك إلى هذه القائمة من صفحة معلومات المانجا."
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 80.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredFavorites, key = { it.mangaId }, contentType = { "manga_card" }) { fav ->
                        val matchedManga = remember(allMangas, fav) {
                            allMangas.find { it.id == fav.mangaId } ?: MangaItem(
                                id = fav.mangaId,
                                title = fav.title,
                                titleArabic = fav.titleArabic,
                                coverUrl = fav.coverUrl,
                                rating = fav.rating,
                                totalChapters = fav.totalChapters,
                                status = fav.status
                            )
                        }
                        Box(modifier = Modifier.animateItem()) {
                            MangaCard(
                                manga = matchedManga,
                                isListView = false,
                                onClick = onMangaClick
                            )
                            IconButton(
                                onClick = { onRemoveFavorite(fav.mangaId) },
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(4.dp)
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.75f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف من القائمة",
                                    tint = MangaRedPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyLibraryState(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(DarkSurface)
                    .border(1.dp, DarkBorder, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(34.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}
