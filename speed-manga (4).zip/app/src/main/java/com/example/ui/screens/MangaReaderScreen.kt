package com.example.ui.screens

import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroidSize
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.ViewDay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.models.ChapterItem
import com.example.data.network.MadaraScraper
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.ReaderSettings
import kotlinx.coroutines.launch

@Composable
fun MangaReaderScreen(
    mangaTitle: String,
    chapter: ChapterItem,
    allChapters: List<ChapterItem>,
    readerSettings: ReaderSettings = ReaderSettings(),
    onUpdateSettings: (ReaderSettings) -> Unit = {},
    isLoadingReader: Boolean,
    onCloseReader: () -> Unit,
    onSelectChapter: (ChapterItem) -> Unit,
    onPageChanged: (Int) -> Unit,
    onOpenCloudflare: () -> Unit = {},
    onRetry: () -> Unit = {}
) {
    var showControls by remember { mutableStateOf(true) }
    var showChapterSelector by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    
    val pages = chapter.pages
    val lazyListState = rememberLazyListState()

    val configuration = androidx.compose.ui.platform.LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val displayPages = remember(pages, isLandscape, readerSettings.pairAdjacentLandscape) {
        if (isLandscape && readerSettings.pairAdjacentLandscape && pages.isNotEmpty()) {
            val pairs = mutableListOf<List<String>>()
            var i = 0
            while (i < pages.size) {
                if (i + 1 < pages.size) {
                    pairs.add(listOf(pages[i], pages[i+1]))
                    i += 2
                } else {
                    pairs.add(listOf(pages[i]))
                    i += 1
                }
            }
            pairs
        } else {
            pages.map { listOf(it) }
        }
    }

    val pagerState = rememberPagerState(pageCount = { displayPages.size.coerceAtLeast(1) })
    var pagerScrollEnabled by remember { mutableStateOf(true) }

    val isWebtoonMode = readerSettings.readingMode == "WEBTOON"
    val isVerticalPaged = readerSettings.readingMode == "VERTICAL_PAGED"
    val isRtlMode = readerSettings.readingMode == "RTL"
    val isLtrMode = readerSettings.readingMode == "LTR"

    val currentPg = if (pages.isEmpty()) 0 else {
        if (isWebtoonMode) {
            lazyListState.firstVisibleItemIndex + 1
        } else {
            val idx = pagerState.currentPage.coerceIn(0, displayPages.size - 1)
            val prevSinglePages = displayPages.take(idx).sumOf { it.size }
            prevSinglePages + displayPages[idx].size
        }
    }

    // Unified Immersive Mode, Keep Screen On, and Custom Brightness Management
    androidx.compose.runtime.DisposableEffect(
        readerSettings.fullscreen,
        readerSettings.keepScreenOn,
        readerSettings.customBrightness,
        readerSettings.brightnessLevel
    ) {
        val window = (context as? android.app.Activity)?.window
        if (window != null) {
            try {
                // 1. Fullscreen/Immersive Mode Call with Fallback Support
                val insetsController = WindowCompat.getInsetsController(window, view)
                if (readerSettings.fullscreen) {
                    insetsController.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                    insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    insetsController.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                }

                // 2. Keep Screen On Management
                if (readerSettings.keepScreenOn) {
                    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }

                // 3. Custom Brightness Manager
                val lp = window.attributes
                if (readerSettings.customBrightness) {
                    lp.screenBrightness = readerSettings.brightnessLevel.coerceIn(0.1f, 1.0f)
                } else {
                    lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                }
                window.attributes = lp
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        onDispose {
            // Safe cleanup and state restoration on disposal (exiting reader or changing screen)
            val w = (context as? android.app.Activity)?.window
            if (w != null) {
                try {
                    val insetsController = WindowCompat.getInsetsController(w, view)
                    insetsController.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                    w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    
                    val lp = w.attributes
                    lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                    w.attributes = lp
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    // Focus system for physical buttons and keyboard mapping
    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    // Reset pager scroll lock on page change
    LaunchedEffect(pagerState.currentPage) {
        pagerScrollEnabled = true
    }

    // Page updates sync
    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.firstVisibleItemIndex }.collect { index ->
            if (isWebtoonMode && pages.isNotEmpty()) onPageChanged(index)
        }
    }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { index ->
            if (!isWebtoonMode && pages.isNotEmpty()) {
                val idx = index.coerceIn(0, displayPages.size - 1)
                val prevSinglePages = displayPages.take(idx).sumOf { it.size }
                onPageChanged(prevSinglePages)
            }
        }
    }

    val contentScale = when (readerSettings.pageScaling) {
        "FIT_WIDTH" -> ContentScale.FillWidth
        "FIT_HEIGHT" -> ContentScale.FillHeight
        "ORIGINAL" -> ContentScale.None
        else -> ContentScale.Fit
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionRight -> {
                            scope.launch {
                                if (!isWebtoonMode) {
                                    val target = if (isRtlMode) pagerState.currentPage - 1 else pagerState.currentPage + 1
                                    if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                }
                            }
                            true
                        }
                        Key.DirectionLeft -> {
                            scope.launch {
                                if (!isWebtoonMode) {
                                    val target = if (isRtlMode) pagerState.currentPage + 1 else pagerState.currentPage - 1
                                    if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                }
                            }
                            true
                        }
                        Key.Spacebar, Key.PageDown, Key.DirectionDown -> {
                            if (readerSettings.keyboardShortcuts) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val nextItem = (lazyListState.firstVisibleItemIndex + 1).coerceAtMost(pages.size - 1)
                                        lazyListState.animateScrollToItem(nextItem)
                                    } else {
                                        val target = if (isRtlMode) pagerState.currentPage - 1 else pagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.PageUp, Key.DirectionUp -> {
                            if (readerSettings.keyboardShortcuts) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val prevItem = (lazyListState.firstVisibleItemIndex - 1).coerceAtLeast(0)
                                        lazyListState.animateScrollToItem(prevItem)
                                    } else {
                                        val target = if (isRtlMode) pagerState.currentPage + 1 else pagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.VolumeUp -> {
                            if (readerSettings.volumeKeyNav) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val prevItem = (lazyListState.firstVisibleItemIndex - 1).coerceAtLeast(0)
                                        lazyListState.animateScrollToItem(prevItem)
                                    } else {
                                        val target = pagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.VolumeDown -> {
                            if (readerSettings.volumeKeyNav) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val nextItem = (lazyListState.firstVisibleItemIndex + 1).coerceAtMost(pages.size - 1)
                                        lazyListState.animateScrollToItem(nextItem)
                                    } else {
                                        val target = pagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        else -> false
                    }
                } else false
            }
            .testTag("reader_screen")
    ) {
        // Reader Content Area
        if (isLoadingReader) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground.copy(alpha = 0.95f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(
                        color = MangaRedPrimary,
                        strokeWidth = 4.dp,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "جاري جلب واستخراج صور الفصل من mangalik.net...",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "يتم الاتصال بموقع مانجا ليك للحصول على جودة الصور الأصلية",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else if (pages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = MangaRedPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "تعذر تحميل صور هذا الفصل",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "اضغط على زر إعادة المحاولة لجلب صفحات الفصل مرة أخرى تلقائياً.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onRetry,
                            colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إعادة المحاولة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        } else if (isWebtoonMode) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
                    .pointerInput(readerSettings.tapToNavigate) {
                        detectTapGestures(
                            onTap = { offset ->
                                val screenWidth = size.width.toFloat()
                                val x = offset.x
                                val leftBoundary = screenWidth / 3f
                                val rightBoundary = (screenWidth / 3f) * 2f
                                
                                if (readerSettings.tapToNavigate) {
                                    if (x < leftBoundary) {
                                        scope.launch {
                                            if (lazyListState.firstVisibleItemIndex > 0) {
                                                lazyListState.animateScrollToItem(lazyListState.firstVisibleItemIndex - 1)
                                            }
                                        }
                                    } else if (x > rightBoundary) {
                                        scope.launch {
                                            if (lazyListState.firstVisibleItemIndex < pages.size - 1) {
                                                lazyListState.animateScrollToItem(lazyListState.firstVisibleItemIndex + 1)
                                            }
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                } else {
                                    showControls = !showControls
                                }
                            }
                        )
                    }
            ) {
                itemsIndexed(
                    items = pages,
                    key = { index, pageUrl -> "$index-$pageUrl" },
                    contentType = { _, _ -> "reader_page" }
                ) { index, pageUrl ->
                    var retryCount by remember { mutableStateOf(0) }
                    var isWideImage by remember { mutableStateOf(false) }
                    val finalPageUrl = remember(pageUrl, retryCount) {
                        if (retryCount > 0 && pageUrl.startsWith("http")) {
                            if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                        } else {
                            pageUrl
                        }
                    }
                    val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                        ImageRequest.Builder(context)
                            .data(finalPageUrl)
                            .addHeader("User-Agent", MadaraScraper.userAgent)
                            .addHeader("Referer", "https://mangalik.net/")
                            .apply {
                                if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                    addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                }
                            }
                            .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .precision(coil.size.Precision.INEXACT)
                            .crossfade(false)
                            .build()
                    }

                    val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                        androidx.compose.ui.graphics.FilterQuality.High
                    } else {
                        androidx.compose.ui.graphics.FilterQuality.Medium
                    }

                    val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                        androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                            androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                -1f,  0f,  0f,  0f,  1f,
                                 0f, -1f,  0f,  0f,  1f,
                                 0f,  0f, -1f,  0f,  1f,
                                 0f,  0f,  0f,  1f,  0f
                            ))
                        )
                    } else null

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 350.dp)
                            .background(DarkBackground),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                // Right half of split spread (for RTL)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(300.dp)
                                        .clipToBounds()
                                ) {
                                    SubcomposeAsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة ${index + 1} يمين",
                                        modifier = Modifier
                                            .fillMaxWidth(2f)
                                            .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                        contentScale = ContentScale.FillWidth,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                // Left half of split spread
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(300.dp)
                                        .clipToBounds()
                                ) {
                                    SubcomposeAsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة ${index + 1} يسار",
                                        modifier = Modifier
                                            .fillMaxWidth(2f)
                                            .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                        contentScale = ContentScale.FillWidth,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt
                                    )
                                }
                            }
                        } else {
                            SubcomposeAsyncImage(
                                model = imageRequest,
                                contentDescription = "صفحة ${index + 1}",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .graphicsLayer(
                                        scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                        scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                    ),
                                contentScale = contentScale,
                                filterQuality = filterQual,
                                colorFilter = colorFilt,
                                onSuccess = { state ->
                                    val drawable = state.result.drawable
                                    if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                        isWideImage = true
                                    }
                                },
                                loading = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(350.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            color = MangaRedPrimary,
                                            strokeWidth = 3.dp,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }
                                },
                                error = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(350.dp)
                                            .clickable { retryCount++ },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = null,
                                                tint = MangaRedPrimary,
                                                modifier = Modifier.size(40.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "تعذر تحميل صفحة ${index + 1}، اضغط لإعادة المحاولة",
                                                fontSize = 13.sp,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        } else if (isVerticalPaged) {
            VerticalPager(
                state = pagerState,
                beyondViewportPageCount = 2,
                userScrollEnabled = pagerScrollEnabled,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
            ) { pageIndex ->
                val pageUrls = displayPages[pageIndex]
                var scale by remember { mutableFloatStateOf(1f) }
                var offsetX by remember { mutableFloatStateOf(0f) }
                var offsetY by remember { mutableFloatStateOf(0f) }
                var containerWidth by remember { mutableStateOf(1000f) }
                var containerHeight by remember { mutableStateOf(1500f) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { size ->
                            containerWidth = size.width.toFloat()
                            containerHeight = size.height.toFloat()
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = { pressOffset ->
                                    if (scale > 1.1f) {
                                        scale = 1f
                                        offsetX = 0f
                                        offsetY = 0f
                                        pagerScrollEnabled = true
                                    } else {
                                        scale = 2.5f
                                        pagerScrollEnabled = false
                                        val targetOffsetX = (containerWidth / 2f - pressOffset.x) * (2.5f - 1f)
                                        val targetOffsetY = (containerHeight / 2f - pressOffset.y) * (2.5f - 1f)
                                        val maxOffX = ((2.5f - 1f) * containerWidth) / 2f
                                        val maxOffY = ((2.5f - 1f) * containerHeight) / 2f
                                        offsetX = targetOffsetX.coerceIn(-maxOffX, maxOffX)
                                        offsetY = targetOffsetY.coerceIn(-maxOffY, maxOffY)
                                    }
                                },
                                onTap = { offset ->
                                    val screenWidth = containerWidth
                                    val x = offset.x
                                    val leftBoundary = screenWidth / 3f
                                    val rightBoundary = (screenWidth / 3f) * 2f
                                    
                                    if (readerSettings.tapToNavigate) {
                                        if (x < leftBoundary) {
                                            scope.launch {
                                                if (pagerState.currentPage > 0) {
                                                    pagerState.animateScrollToPage(pagerState.currentPage - 1)
                                                }
                                            }
                                        } else if (x > rightBoundary) {
                                            scope.launch {
                                                if (pagerState.currentPage < displayPages.size - 1) {
                                                    pagerState.animateScrollToPage(pagerState.currentPage + 1)
                                                }
                                            }
                                        } else {
                                            showControls = !showControls
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                }
                            )
                        }
                        .pointerInput(scale) {
                            awaitEachGesture {
                                var zoom = 1f
                                var pan = Offset.Zero
                                var pastTouchSlop = false
                                val touchSlop = viewConfiguration.touchSlop

                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val event = awaitPointerEvent()
                                    val canceled = event.changes.any { it.isConsumed }
                                    if (!canceled) {
                                        val pointerCount = event.changes.size
                                        val zoomChange = event.calculateZoom()
                                        val panChange = event.calculatePan()

                                        if (!pastTouchSlop) {
                                            zoom *= zoomChange
                                            pan += panChange
                                            val centroidSize = event.calculateCentroidSize(useCurrent = false)
                                            val zoomMotion = Math.abs(1 - zoom) * centroidSize
                                            val panMotion = pan.getDistance()

                                            if (zoomMotion > touchSlop || panMotion > touchSlop) {
                                                pastTouchSlop = true
                                            }
                                        }

                                        if (pastTouchSlop) {
                                            val isZooming = pointerCount > 1
                                            val newScale = (scale * zoomChange).coerceIn(1f, 4f)
                                            scale = newScale
                                            pagerScrollEnabled = scale <= 1.05f

                                            if (scale > 1.05f) {
                                                val maxOffsetX = ((scale - 1f) * containerWidth) / 2f
                                                val maxOffsetY = ((scale - 1f) * containerHeight) / 2f
                                                offsetX = (offsetX + panChange.x).coerceIn(-maxOffsetX, maxOffsetX)
                                                offsetY = (offsetY + panChange.y).coerceIn(-maxOffsetY, maxOffsetY)
                                            } else {
                                                offsetX = 0f
                                                offsetY = 0f
                                            }

                                            if (isZooming || scale > 1.05f) {
                                                event.changes.forEach { change ->
                                                    if (change.pressed) {
                                                        change.consume()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            ),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pageUrls.forEachIndexed { subIndex, pageUrl ->
                            var retryCount by remember { mutableStateOf(0) }
                            var isWideImage by remember { mutableStateOf(false) }
                            val finalPageUrl = remember(pageUrl, retryCount) {
                                if (retryCount > 0 && pageUrl.startsWith("http")) {
                                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                } else {
                                    pageUrl
                                }
                            }
                            val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                ImageRequest.Builder(context)
                                    .data(finalPageUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .precision(coil.size.Precision.INEXACT)
                                    .crossfade(false)
                                    .build()
                            }

                            val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                androidx.compose.ui.graphics.FilterQuality.High
                            } else {
                                androidx.compose.ui.graphics.FilterQuality.Medium
                            }

                            val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                    androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                        -1f,  0f,  0f,  0f,  1f,
                                         0f, -1f,  0f,  0f,  1f,
                                         0f,  0f, -1f,  0f,  1f,
                                         0f,  0f,  0f,  1f,  0f
                                    ))
                                )
                            } else null

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            SubcomposeAsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            SubcomposeAsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                    }
                                } else {
                                    SubcomposeAsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة $pageIndex-$subIndex",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt,
                                        onSuccess = { state ->
                                            val drawable = state.result.drawable
                                            if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                                isWideImage = true
                                            }
                                        },
                                        loading = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    color = MangaRedPrimary,
                                                    strokeWidth = 3.dp,
                                                    modifier = Modifier.size(40.dp)
                                                )
                                            }
                                        },
                                        error = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground)
                                                    .clickable { retryCount++ },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Icon(
                                                        imageVector = Icons.Default.Refresh,
                                                        contentDescription = null,
                                                        tint = MangaRedPrimary,
                                                        modifier = Modifier.size(40.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Text(
                                                        text = "تعذر تحميل الصفحة، اضغط لإعادة المحاولة",
                                                        fontSize = 13.sp,
                                                        color = TextPrimary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Horizontal Single/Double Page Mode (RTL or LTR) with Pinch-to-Zoom
            HorizontalPager(
                state = pagerState,
                reverseLayout = isRtlMode,
                beyondViewportPageCount = 2,
                userScrollEnabled = pagerScrollEnabled,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
            ) { pageIndex ->
                val pageUrls = displayPages[pageIndex]
                var scale by remember { mutableFloatStateOf(1f) }
                var offsetX by remember { mutableFloatStateOf(0f) }
                var offsetY by remember { mutableFloatStateOf(0f) }
                var containerWidth by remember { mutableStateOf(1000f) }
                var containerHeight by remember { mutableStateOf(1500f) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { size ->
                            containerWidth = size.width.toFloat()
                            containerHeight = size.height.toFloat()
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onDoubleTap = { pressOffset ->
                                    if (scale > 1.1f) {
                                        scale = 1f
                                        offsetX = 0f
                                        offsetY = 0f
                                        pagerScrollEnabled = true
                                    } else {
                                        scale = 2.5f
                                        pagerScrollEnabled = false
                                        val targetOffsetX = (containerWidth / 2f - pressOffset.x) * (2.5f - 1f)
                                        val targetOffsetY = (containerHeight / 2f - pressOffset.y) * (2.5f - 1f)
                                        val maxOffX = ((2.5f - 1f) * containerWidth) / 2f
                                        val maxOffY = ((2.5f - 1f) * containerHeight) / 2f
                                        offsetX = targetOffsetX.coerceIn(-maxOffX, maxOffX)
                                        offsetY = targetOffsetY.coerceIn(-maxOffY, maxOffY)
                                    }
                                },
                                onTap = { offset ->
                                    val screenWidth = containerWidth
                                    val x = offset.x
                                    val leftBoundary = screenWidth / 3f
                                    val rightBoundary = (screenWidth / 3f) * 2f
                                    
                                    if (readerSettings.tapToNavigate) {
                                        if (x < leftBoundary) {
                                            scope.launch {
                                                val target = if (isRtlMode) pagerState.currentPage + 1 else pagerState.currentPage - 1
                                                if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                            }
                                        } else if (x > rightBoundary) {
                                            scope.launch {
                                                val target = if (isRtlMode) pagerState.currentPage - 1 else pagerState.currentPage + 1
                                                if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                            }
                                        } else {
                                            showControls = !showControls
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                }
                            )
                        }
                        .pointerInput(scale) {
                            awaitEachGesture {
                                var zoom = 1f
                                var pan = Offset.Zero
                                var pastTouchSlop = false
                                val touchSlop = viewConfiguration.touchSlop

                                awaitFirstDown(requireUnconsumed = false)
                                do {
                                    val event = awaitPointerEvent()
                                    val canceled = event.changes.any { it.isConsumed }
                                    if (!canceled) {
                                        val pointerCount = event.changes.size
                                        val zoomChange = event.calculateZoom()
                                        val panChange = event.calculatePan()

                                        if (!pastTouchSlop) {
                                            zoom *= zoomChange
                                            pan += panChange
                                            val centroidSize = event.calculateCentroidSize(useCurrent = false)
                                            val zoomMotion = Math.abs(1 - zoom) * centroidSize
                                            val panMotion = pan.getDistance()

                                            if (zoomMotion > touchSlop || panMotion > touchSlop) {
                                                pastTouchSlop = true
                                            }
                                        }

                                        if (pastTouchSlop) {
                                            val isZooming = pointerCount > 1
                                            val newScale = (scale * zoomChange).coerceIn(1f, 4f)
                                            scale = newScale
                                            pagerScrollEnabled = scale <= 1.05f

                                            if (scale > 1.05f) {
                                                val maxOffsetX = ((scale - 1f) * containerWidth) / 2f
                                                val maxOffsetY = ((scale - 1f) * containerHeight) / 2f
                                                offsetX = (offsetX + panChange.x).coerceIn(-maxOffsetX, maxOffsetX)
                                                offsetY = (offsetY + panChange.y).coerceIn(-maxOffsetY, maxOffsetY)
                                            } else {
                                                offsetX = 0f
                                                offsetY = 0f
                                            }

                                            if (isZooming || scale > 1.05f) {
                                                event.changes.forEach { change ->
                                                    if (change.pressed) {
                                                        change.consume()
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            ),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pageUrls.forEachIndexed { subIndex, pageUrl ->
                            var retryCount by remember { mutableStateOf(0) }
                            var isWideImage by remember { mutableStateOf(false) }
                            val finalPageUrl = remember(pageUrl, retryCount) {
                                if (retryCount > 0 && pageUrl.startsWith("http")) {
                                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                } else {
                                    pageUrl
                                }
                            }
                            val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                ImageRequest.Builder(context)
                                    .data(finalPageUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .precision(coil.size.Precision.INEXACT)
                                    .crossfade(false)
                                    .build()
                            }

                            val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                androidx.compose.ui.graphics.FilterQuality.High
                            } else {
                                androidx.compose.ui.graphics.FilterQuality.Medium
                            }

                            val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                    androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                        -1f,  0f,  0f,  0f,  1f,
                                         0f, -1f,  0f,  0f,  1f,
                                         0f,  0f, -1f,  0f,  1f,
                                         0f,  0f,  0f,  1f,  0f
                                    ))
                                )
                            } else null

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            SubcomposeAsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            SubcomposeAsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                    }
                                } else {
                                    SubcomposeAsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة $pageIndex-$subIndex",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt,
                                        onSuccess = { state ->
                                            val drawable = state.result.drawable
                                            if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                                isWideImage = true
                                            }
                                        },
                                        loading = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    color = MangaRedPrimary,
                                                    strokeWidth = 3.dp,
                                                    modifier = Modifier.size(40.dp)
                                                )
                                            }
                                        },
                                        error = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground)
                                                    .clickable { retryCount++ },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Icon(
                                                        imageVector = Icons.Default.Refresh,
                                                        contentDescription = null,
                                                        tint = MangaRedPrimary,
                                                        modifier = Modifier.size(40.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Text(
                                                        text = "تعذر تحميل الصفحة، اضغط لإعادة المحاولة",
                                                        fontSize = 13.sp,
                                                        color = TextPrimary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Reading Tint Mode Overlay (Warm Sepia only; Inverted is handled on the image level)
        if (readerSettings.tintMode == "SEPIA" && !isLoadingReader) {
            val tintColor = Color(0x2E8C6E3B) // Warm sepia overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(tintColor)
            )
        }

        // Page Number Indicator Overlay
        if (readerSettings.showPageNumber && pages.isNotEmpty() && !isLoadingReader) {
            val align = when (readerSettings.pageNumberPlacement) {
                "BOTTOM_RIGHT" -> Alignment.BottomEnd
                "TOP_CENTER" -> Alignment.TopCenter
                else -> Alignment.BottomCenter
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 24.dp, vertical = if (showControls) 86.dp else 24.dp),
                contentAlignment = align
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = readerSettings.pageNumberOpacity))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "$currentPg / ${pages.size}",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Reading Progress Bar Overlay
        if (readerSettings.showProgressBar && pages.isNotEmpty() && !isLoadingReader) {
            val progress = currentPg.toFloat() / pages.size.coerceAtLeast(1)
            val align = if (readerSettings.progressBarPlacement == "TOP") Alignment.TopCenter else Alignment.BottomCenter
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = align
            ) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MangaRedPrimary,
                    trackColor = Color.Transparent
                )
            }
        }

        // Top Control Bar Overlay
        if (showControls) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .background(Color.Black.copy(alpha = 0.88f))
                    .statusBarsPadding()
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCloseReader,
                    modifier = Modifier.testTag("close_reader")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق القارئ",
                        tint = Color.White
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = mangaTitle,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 14.sp
                    )
                    Text(
                        text = chapter.title,
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            // Cycle through modes: WEBTOON -> RTL -> LTR -> VERTICAL_PAGED
                            val nextMode = when (readerSettings.readingMode) {
                                "WEBTOON" -> "RTL"
                                "RTL" -> "LTR"
                                "LTR" -> "VERTICAL_PAGED"
                                else -> "WEBTOON"
                            }
                            onUpdateSettings(readerSettings.copy(readingMode = nextMode))
                        },
                        modifier = Modifier.testTag("toggle_reading_mode")
                    ) {
                        Icon(
                            imageVector = if (isWebtoonMode) Icons.Default.ViewDay else Icons.Default.ViewCarousel,
                            contentDescription = "تغيير نمط القراءة",
                            tint = MangaRedPrimary
                        )
                    }
                }
            }
            // Bottom Control Bar Overlay
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(Color.Black.copy(alpha = 0.88f))
                    .navigationBarsPadding()
                    .padding(14.dp)
            ) {
                Text(
                    text = "صفحة $currentPg من ${pages.size}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val currentIndex = allChapters.indexOfFirst { it.id == chapter.id }
                    val prevChapter = if (currentIndex > 0) allChapters.getOrNull(currentIndex - 1) else null
                    val nextChapter = if (currentIndex < allChapters.size - 1) allChapters.getOrNull(currentIndex + 1) else null
                    IconButton(
                        onClick = { nextChapter?.let { onSelectChapter(it) } },
                        enabled = nextChapter != null
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "الفصل السابق",
                            tint = if (nextChapter != null) MangaRedPrimary else Color.Gray
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(DarkSurface)
                            .clickable { showChapterSelector = true }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.List, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اختيار فصل آخر", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    IconButton(
                        onClick = { prevChapter?.let { onSelectChapter(it) } },
                        enabled = prevChapter != null
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "الفصل التالي",
                            tint = if (prevChapter != null) MangaRedPrimary else Color.Gray
                        )
                    }
                }
            }
        }
        // Chapter Selection Dialog
        if (showChapterSelector) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showChapterSelector = false }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "اختر الفصل",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        androidx.compose.foundation.lazy.LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            itemsIndexed(allChapters) { _, chItem ->
                                val isCurrent = chItem.id == chapter.id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isCurrent) MangaRedPrimary.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable {
                                            onSelectChapter(chItem)
                                            showChapterSelector = false
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = chItem.title,
                                        color = if (isCurrent) MangaRedPrimary else TextPrimary,
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { showChapterSelector = false },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إلغاء", color = TextPrimary)
                        }
                    }
                }
            }
        }
    }
}
