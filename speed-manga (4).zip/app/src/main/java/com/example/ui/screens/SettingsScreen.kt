package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.UserAccount
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.TelegramManager
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    favoritesCount: Int,
    historyCount: Int,
    isCloudflareVerified: Boolean,
    currentUser: UserAccount? = null,
    onLogout: () -> Unit = {},
    onOpenAuth: () -> Unit = {},
    onUpdateName: (String) -> Unit = {},
    onOpenCloudflare: () -> Unit,
    readerSettings: com.example.utils.ReaderSettings = com.example.utils.ReaderSettings(),
    onUpdateSettings: (com.example.utils.ReaderSettings) -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val telegramManager = remember { TelegramManager.getInstance(context) }

    var cacheSizeText by remember { mutableStateOf(com.example.utils.CacheManager.getFormattedCacheSize(context)) }

    var botTokenText by remember { mutableStateOf(telegramManager.botToken) }
    var channelIdText by remember { mutableStateOf(telegramManager.channelId) }
    var isAutoUpload by remember { mutableStateOf(telegramManager.isAutoUploadEnabled) }
    var isUploadPdf by remember { mutableStateOf(telegramManager.uploadAsPdf) }
    var isUploadCbz by remember { mutableStateOf(telegramManager.uploadAsCbz) }
    var isTestingConnection by remember { mutableStateOf(false) }
    var lastStatusText by remember { mutableStateOf(telegramManager.lastUploadStatus) }

    var showEditNameDialog by remember { mutableStateOf(false) }
    var editNameText by remember { mutableStateOf(currentUser?.name ?: "") }
    var activeSubTab by remember { mutableStateOf(0) } // 0 = General Settings, 1 = Reader Settings

    if (showEditNameDialog) {
        AlertDialog(
            onDismissRequest = { showEditNameDialog = false },
            title = { Text("تعديل الاسم", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editNameText,
                    onValueChange = { editNameText = it },
                    label = { Text("الاسم الجديد") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MangaRedPrimary,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editNameText.isNotBlank()) {
                            onUpdateName(editNameText)
                            Toast.makeText(context, "تم تحديث الاسم بنجاح", Toast.LENGTH_SHORT).show()
                        }
                        showEditNameDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showEditNameDialog = false }) {
                    Text("إلغاء", color = TextSecondary)
                }
            },
            containerColor = DarkSurface
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("settings_screen")
    ) {
        Text(
            text = "الإعدادات العامة وتفضيلات القراءة",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Custom Nested Tab Selector Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
                .background(DarkSurface, RoundedCornerShape(12.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(12.dp))
                .padding(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (activeSubTab == 0) MangaRedPrimary else Color.Transparent)
                    .clickable { activeSubTab = 0 }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "الإعدادات العامة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (activeSubTab == 0) Color.White else TextSecondary
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (activeSubTab == 1) MangaRedPrimary else Color.Transparent)
                    .clickable { activeSubTab = 1 }
                    .padding(vertical = 12.dp)
                    .testTag("settings_reader_tab"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "إعدادات القارئ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (activeSubTab == 1) Color.White else TextSecondary
                )
            }
        }

        if (activeSubTab == 0) {
            // Profile Avatar Header Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(MangaRedPrimary.copy(alpha = 0.2f))
                            .border(1.5.dp, MangaRedPrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = currentUser?.name?.take(1)?.uppercase() ?: "؟",
                            color = MangaRedPrimary,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentUser?.name ?: "مستخدم زائر",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimary
                            )
                            if (currentUser?.isVerified == true) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "حساب مفعل",
                                    tint = Color(0xFF4CAF50),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = currentUser?.email ?: "سجل حسابك لحفظ تفضيلاتك وتزامن القراءة",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )

                        if (currentUser?.isVerified == true) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "✓ حسابك نشط ومفعل بالبريد الإلكتروني",
                                fontSize = 11.sp,
                                color = Color(0xFF4CAF50),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (currentUser != null) {
                        OutlinedButton(
                            onClick = {
                                editNameText = currentUser.name
                                showEditNameDialog = true
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, DarkBorder)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تعديل الاسم", color = TextSecondary, fontSize = 12.sp)
                        }

                        Button(
                            onClick = onLogout,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C1E23))
                        ) {
                            Icon(imageVector = Icons.Default.ExitToApp, contentDescription = null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تسجيل الخروج", color = Color(0xFFFF6B6B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onOpenAuth,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                        ) {
                            Icon(imageVector = Icons.Default.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تسجيل الدخول / إنشاء حساب جديد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Stats Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(imageVector = Icons.Default.Bookmark, contentDescription = null, tint = MangaRedPrimary)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "$favoritesCount", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Text(text = "في قائمتي", fontSize = 11.sp, color = TextSecondary)
                }
            }

            Card(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, DarkBorder, RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = MangaGold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "$historyCount", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Text(text = "فصول مقروءة", fontSize = 11.sp, color = TextSecondary)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Telegram Channel Integration Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, MangaRedPrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = null,
                        tint = MangaRedPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "رفع الفصول تلقائياً إلى قناة التليجرام",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "عند تحميل أي فصل، سيتم تحويل صفحات الفصل ورفعها كملف PDF تلقائياً إلى قناتك على التليجرام.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = channelIdText,
                    onValueChange = {
                        channelIdText = it
                        telegramManager.channelId = it
                    },
                    label = { Text("معرّف القناة (Channel ID)") },
                    placeholder = { Text("-1003627092623") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MangaRedPrimary,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = MangaRedPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = botTokenText,
                    onValueChange = {
                        botTokenText = it
                        telegramManager.botToken = it
                    },
                    label = { Text("توكن البوت (Telegram Bot Token)") },
                    placeholder = { Text("مثال: 123456789:ABCdefGhIJK...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MangaRedPrimary,
                        unfocusedBorderColor = DarkBorder,
                        focusedLabelColor = MangaRedPrimary,
                        unfocusedLabelColor = TextMuted,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "تفعيل الرفع التلقائي", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "رفع الفصل إلى القناة فور انتهاء التحميل", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = isAutoUpload,
                        onCheckedChange = {
                            isAutoUpload = it
                            telegramManager.isAutoUploadEnabled = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "رفع كملف PDF", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "تجميع صفحات الفصل في مستند PDF رفيع المستوى", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = isUploadPdf,
                        onCheckedChange = {
                            isUploadPdf = it
                            telegramManager.uploadAsPdf = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "رفع كملف أرشيف CBZ (بديل)", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "تجميع صفحات الفصل في ملف CBZ بدلاً من PDF", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = isUploadCbz,
                        onCheckedChange = {
                            isUploadCbz = it
                            telegramManager.uploadAsCbz = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            if (botTokenText.isBlank()) {
                                Toast.makeText(context, "يرجى إدخال توكن البوت أولاً", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isTestingConnection = true
                            coroutineScope.launch {
                                val res = telegramManager.testConnection(botTokenText, channelIdText)
                                isTestingConnection = false
                                res.onSuccess {
                                    Toast.makeText(context, it, Toast.LENGTH_LONG).show()
                                    lastStatusText = "✅ $it"
                                }.onFailure {
                                    Toast.makeText(context, it.message ?: "فشل الاتصال", Toast.LENGTH_LONG).show()
                                    lastStatusText = "❌ ${it.message}"
                                }
                            }
                        },
                        enabled = !isTestingConnection,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isTestingConnection) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("اختبار الاتصال بالقناة", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                if (lastStatusText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkBackground, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = lastStatusText,
                            fontSize = 11.sp,
                            color = if (lastStatusText.startsWith("✅")) Color(0xFF4CAF50) else Color(0xFFFF5252),
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Security / Protection Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = MangaRedPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "تجاوز حماية mangalik.net",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isCloudflareVerified)
                        "الحماية متجاوزة بنجاح ✓. يمكنك تصفح جميع فصول الموقع بدون مشاكل."
                    else
                        "يتطلب موقع mangalik تجاوز حماية Cloudflare يدويًا مرة واحدة.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = onOpenCloudflare,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_bypass_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("فتح نافذة تجاوز الحماية اليدوية", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Cache Management Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.SdStorage, contentDescription = null, tint = MangaGold)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "التخزين المؤقت والذاكرة (الكاش)",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "حجم الذاكرة المؤقتة المستهلكة حالياً:",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "تم تقييد كاش صور الأغلفة تلقائياً بـ 30 ميجابايت بدلاً من 500 ميجابايت لمنع امتلاء ذاكرة الهاتف.",
                            fontSize = 11.sp,
                            color = TextMuted,
                            lineHeight = 16.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = cacheSizeText,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MangaGold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val success = com.example.utils.CacheManager.clearAppCache(context)
                        if (success) {
                            cacheSizeText = com.example.utils.CacheManager.getFormattedCacheSize(context)
                            Toast.makeText(context, "تم مسح الذاكرة المؤقتة وتوفير المساحة بنجاح! 🧹", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "حدث خطأ أثناء مسح الذاكرة المؤقتة", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_clear_cache_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C1E23)),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MangaRedPrimary.copy(alpha = 0.5f))
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("مسح الذاكرة المؤقتة فوراً (Clear Cache) 🧹", color = MangaRedPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }
    }

    if (activeSubTab == 1) {
        // --- SECTION A: Reading Modes & Direction ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "طبيعة العرض وطريقة القراءة",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Options
                val modes = listOf(
                    Triple("WEBTOON", "تمرير عمودي مستمر (ويب تون)", "عرض شريطي متصل ومثالي للمانهوا والويب تون"),
                    Triple("RTL", "من اليمين إلى اليسار (RTL - مانجا)", "طريقة القراءة التقليدية للمانجا اليابانية"),
                    Triple("LTR", "من اليسار إلى اليمين (LTR - كوميكس)", "مناسب للكوميكس والمانها الصينية/الكورية"),
                    Triple("VERTICAL_PAGED", "صفحات عمودية (صفحة صفحة)", "عرض صفحة واحدة مع سحب رأسي منفصل")
                )

                modes.forEach { (modeCode, title, desc) ->
                    val isSelected = readerSettings.readingMode == modeCode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onUpdateSettings(readerSettings.copy(readingMode = modeCode)) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { onUpdateSettings(readerSettings.copy(readingMode = modeCode)) },
                            colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary, unselectedColor = TextSecondary)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = title, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = if (isSelected) MangaRedPrimary else TextPrimary, fontSize = 13.sp)
                            Text(text = desc, fontSize = 11.sp, color = TextMuted)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- SECTION B: Display & Screen Behavior ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Fullscreen, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "عرض الشاشة ووضع القارئ",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Fullscreen Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "وضع ملء الشاشة (Fullscreen)", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "إخفاء شريط الإشعارات العلوي وأشرطة النظام أثناء القراءة", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.fullscreen,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(fullscreen = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Keep Screen On Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "إبقاء الشاشة مضاءة (Screen Awake)", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "منع قفل أو إطفاء الشاشة تلقائياً أثناء قراءة الفصول", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.keepScreenOn,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(keepScreenOn = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Page Number Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "مؤشر أرقام الصفحات", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "عرض عداد أرقام الصفحات الحالي فوق الصور (مثال: 12 / 45)", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.showPageNumber,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(showPageNumber = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                if (readerSettings.showPageNumber) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
                        Text(text = "موضع العداد:", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("BOTTOM_CENTER" to "وسط الأسفل", "BOTTOM_RIGHT" to "يمين الأسفل", "TOP_CENTER" to "وسط الأعلى").forEach { (place, label) ->
                                val active = readerSettings.pageNumberPlacement == place
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                        .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                        .clickable { onUpdateSettings(readerSettings.copy(pageNumberPlacement = place)) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "شفافية عداد الصفحات: ", fontSize = 11.sp, color = TextSecondary)
                            Text(text = "${(readerSettings.pageNumberOpacity * 100).toInt()}%", fontSize = 11.sp, color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = readerSettings.pageNumberOpacity,
                            onValueChange = { onUpdateSettings(readerSettings.copy(pageNumberOpacity = it)) },
                            valueRange = 0.1f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = MangaRedPrimary, activeTrackColor = MangaRedPrimary, inactiveTrackColor = DarkBorder)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Reading Progress Bar Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "شريط تقدم القراءة", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "عرض خط تقدم خفيف وثابت في أطراف الشاشة", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.showProgressBar,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(showProgressBar = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                if (readerSettings.showProgressBar) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
                        Text(text = "موضع شريط التقدم:", fontSize = 12.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("TOP" to "أعلى الشاشة", "BOTTOM" to "أسفل الشاشة").forEach { (place, label) ->
                                val active = readerSettings.progressBarPlacement == place
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                        .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                        .clickable { onUpdateSettings(readerSettings.copy(progressBarPlacement = place)) }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- SECTION C: Image Rendering, Dimensions & Webtoon Optimizations ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Crop, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "أبعاد وإصلاح الصور",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Crop Margins Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "قص الحواف التلقائي (Webtoon Crop)", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "إزالة الحواف البيضاء والسوداء الزائدة لخياطة الصور بشكل سلس", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.cropMargins,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(cropMargins = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Adjustable Side Padding
                Column {
                    Text(text = "الهوامش الجانبية (Side Padding):", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                    Text(text = "تعديل حواشٍ جانبية لمنع تمدد الصور المشوه على الشاشات العريضة", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0 to "بدون (0px)", 8 to "خفيفة (8px)", 16 to "عريضة (16px)").forEach { (pad, label) ->
                            val active = readerSettings.sidePadding == pad
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                    .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                    .clickable { onUpdateSettings(readerSettings.copy(sidePadding = pad)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Page Scaling Modes
                Column {
                    Text(text = "نمط تمدد ومقياس الصفحة (Page Scaling):", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                    Text(text = "تحديد نسبة أبعاد الصورة في مساحة القارئ", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("FIT_WIDTH" to "ملائمة العرض", "FIT_HEIGHT" to "ملائمة الارتفاع", "ORIGINAL" to "الحجم الأصلي").forEach { (scale, label) ->
                            val active = readerSettings.pageScaling == scale
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                    .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                    .clickable { onUpdateSettings(readerSettings.copy(pageScaling = scale)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Smooth Transitions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "تنقل سلس ومسرع بالعتاد", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "حركة انتقالية انسيابية ومسرّعة عتادياً بين الصفحات", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.smoothTransitions,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(smoothTransitions = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Image Filtering Quality Mode
                Column {
                    Text(text = "جودة ترشيح وفلترة الصور (Downscaling):", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                    Text(text = "خوارزمية الفلترة لمنع بكسلة وتقطيع الصور عالية الدقة", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("BILINEAR" to "ثنائي الخطوط (Bilinear)", "BICUBIC" to "ثنائي التكعيب (Bicubic)").forEach { (filter, label) ->
                            val active = readerSettings.imageFiltering == filter
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                    .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                    .clickable { onUpdateSettings(readerSettings.copy(imageFiltering = filter)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- SECTION D: Navigation & Control Options ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Keyboard, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "طرق التنقل والتحكم",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tap-to-Navigate
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "النقر للتنقل (Tap-to-Navigate)", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "الضغط على يمين/يسار الشاشة للتنقل والوسط لإظهار القوائم", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.tapToNavigate,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(tapToNavigate = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Volume Keys Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "أزرار الصوت لقلب الصفحات", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "استخدام أزرار الصوت المادية بالجهاز لقلب الصفحات والتمرير", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.volumeKeyNav,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(volumeKeyNav = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Keyboard Shortcuts
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "اختصارات لوحة المفاتيح", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "تفعيل الأسهم ومفتاح المسافة للتنقل السريع على الأجهزة اللوحية والحواسب", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.keyboardShortcuts,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(keyboardShortcuts = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- SECTION E: Additional Reader Enhancements ---
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "إضافات مخصصة ومتقدمة",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Custom brightness
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "سطوع مخصص ومستقل للقارئ", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "تجاوز وإلغاء سطوع النظام واستخدام سطوع ذكي خاص بالقارئ", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.customBrightness,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(customBrightness = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                if (readerSettings.customBrightness) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Column(modifier = Modifier.padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.BrightnessMedium, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "مستوى السطوع المخصص: ", fontSize = 11.sp, color = TextSecondary)
                            Text(text = "${(readerSettings.brightnessLevel * 100).toInt()}%", fontSize = 11.sp, color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = readerSettings.brightnessLevel,
                            onValueChange = { onUpdateSettings(readerSettings.copy(brightnessLevel = it)) },
                            valueRange = 0.1f..1.0f,
                            colors = SliderDefaults.colors(thumbColor = MangaRedPrimary, activeTrackColor = MangaRedPrimary, inactiveTrackColor = DarkBorder)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Tint Modes / Filters
                Column {
                    Text(text = "وضع تصفية وتأثير ألوان القراءة (Tint Modes):", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                    Text(text = "تأثير مرشحات الإضاءة لحماية العين من الإرهاق", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("STANDARD" to "طبيعي", "SEPIA" to "دافئ / سيبيا", "INVERTED" to "عكس الألوان (ليلي)").forEach { (mode, label) ->
                            val active = readerSettings.tintMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (active) MangaRedPrimary.copy(alpha = 0.2f) else DarkBackground)
                                    .border(1.dp, if (active) MangaRedPrimary else DarkBorder, RoundedCornerShape(8.dp))
                                    .clickable { onUpdateSettings(readerSettings.copy(tintMode = mode)) }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (active) MangaRedPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Split Double-Page Spreads
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "تقسيم الصفحات المزدوجة تلقائياً", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "التعرف على الصفحات العريضة المزدوجة وتقسيمها لصفحتين على الهاتف", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.doublePageSpread,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(doublePageSpread = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Landscape Adjacent Pairing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "دمج الصفحات المتجاورة أفقياً", fontWeight = FontWeight.Bold, color = TextPrimary, fontSize = 13.sp)
                        Text(text = "عرض صفحتين متجاورتين معاً عند تدوير شاشة الهاتف أفقياً", fontSize = 11.sp, color = TextMuted)
                    }
                    Switch(
                        checked = readerSettings.pairAdjacentLandscape,
                        onCheckedChange = { onUpdateSettings(readerSettings.copy(pairAdjacentLandscape = it)) },
                        colors = SwitchDefaults.colors(checkedThumbColor = MangaRedPrimary, checkedTrackColor = MangaRedPrimary.copy(alpha = 0.3f))
                    )
                }
            }
        }
    }

    Spacer(modifier = Modifier.height(100.dp))
}
}
