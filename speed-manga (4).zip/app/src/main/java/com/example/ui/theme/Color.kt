package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MangaSlayer Vibrant Red Palette
val MangaRedPrimary = Color(0xFFE53935) // Iconic Red Header Accent
val MangaRedLight = Color(0xFFEF5350)   // Bright Light Red
val MangaRedDark = Color(0xFFC62828)    // Deep Red Header

val MangaGold = Color(0xFFF59E0B)       // Sleek Gold / Rating Star

val DarkBackground = Color(0xFF121212)  // Clean Dark Canvas
val DarkSurface = Color(0xFF1E1E24)     // Crisp Surface Card
val DarkSurfaceVariant = Color(0xFF2A2A32)// Surface Variant
val DarkBorder = Color(0xFF33333E)      // Subtle Border

val LightBackground = Color(0xFFF3F4F6) // Crisp Light Canvas
val LightSurface = Color(0xFFFFFFFF)    // Crisp White Card
val LightBorder = Color(0xFFE5E7EB)     // Light Border

val TextPrimary = Color(0xFFF8FAFC)     // High-contrast crisp white
val TextSecondary = Color(0xFF94A3B8)   // Sleek secondary text
val TextMuted = Color(0xFF64748B)       // Muted slate text

val TextDarkPrimary = Color(0xFF111827) // High contrast text on white cards
val TextDarkSecondary = Color(0xFF6B7280)

val CardGradientStart = Color(0xCC121212)
val CardGradientEnd = Color(0xFF1E1E24)
