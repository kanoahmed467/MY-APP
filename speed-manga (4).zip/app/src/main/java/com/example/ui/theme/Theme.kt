package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val SpeedMangaDarkColorScheme = darkColorScheme(
    primary = MangaRedPrimary,
    onPrimary = TextPrimary,
    primaryContainer = MangaRedDark,
    onPrimaryContainer = TextPrimary,
    secondary = MangaRedLight,
    onSecondary = TextPrimary,
    tertiary = MangaGold,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder
)

@Composable
fun SpeedMangaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    // Speed Manga is a dark-theme luxury Manga Slayer inspired experience by default
    val colorScheme = SpeedMangaDarkColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
