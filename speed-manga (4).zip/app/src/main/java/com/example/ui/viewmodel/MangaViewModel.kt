package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.example.data.local.FavoriteMangaEntity
import com.example.data.local.ReadingHistoryEntity
import com.example.data.models.ChapterItem
import com.example.data.models.LibraryCategory
import com.example.data.models.MangaItem
import com.example.data.models.UserComment
import com.example.data.network.CloudflareBypasser
import com.example.data.network.MadaraScraper
import com.example.data.paging.MangaPagingSource
import com.example.data.repository.MangaRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainTab(val titleArabic: String) {
    HOME("آخر التحديثات"),
    EXPLORE("استكشاف"),
    FAVORITES("المفضلة"),
    LIBRARY("قائمتي"),
    DOWNLOADED_MANGA("المانجات المحملة"),
    DOWNLOAD_QUEUE("قائمة التنزيل"),
    CLOUDFLARE_BYPASS("حماية mangalik"),
    PROFILE("الإعدادات"),
    AUTH("تسجيل الدخول")
}

class MangaViewModel(application: Application) : AndroidViewModel(application) {
    val repository = MangaRepository(application)
    val authManager = com.example.utils.AuthManager.getInstance(application)
    val currentUser: StateFlow<com.example.data.models.UserAccount?> = authManager.currentUser

    private var prefetchJob: Job? = null
    private var lastPrefetchedChapterId: String? = null

    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    private val readerPrefs = com.example.utils.ReaderPreferences(application)
    private val _readerSettings = MutableStateFlow(readerPrefs.getSettings())
    val readerSettings: StateFlow<com.example.utils.ReaderSettings> = _readerSettings.asStateFlow()

    fun updateReaderSettings(settings: com.example.utils.ReaderSettings) {
        viewModelScope.launch {
            readerPrefs.updateSettings(settings)
            _readerSettings.value = settings
        }
    }

    // Manga catalog (Live + Cached)
    private val _mangas = MutableStateFlow<List<MangaItem>>(repository.getMangas())
    val mangas: StateFlow<List<MangaItem>> = _mangas.asStateFlow()

    // Dedicated Latest Updates catalog for Home Screen
    private val _latestUpdates = MutableStateFlow<List<MangaItem>>(repository.getMangas())
    val latestUpdates: StateFlow<List<MangaItem>> = _latestUpdates.asStateFlow()

    // Internet connection state flow
    val isOnline: StateFlow<Boolean> = com.example.utils.NetworkUtils.observeNetworkState(application)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), com.example.utils.NetworkUtils.isOnline(application))

    // Paging 3 Flows for smooth infinite scrolling
    val mangaPagingFlow: Flow<PagingData<MangaItem>> = Pager(
        config = PagingConfig(
            pageSize = 20,
            prefetchDistance = 5,
            enablePlaceholders = false
        )
    ) {
        MangaPagingSource { page ->
            MadaraScraper.fetchMangaListPage(page)
        }
    }.flow.cachedIn(viewModelScope)

    val latestUpdatesPagingFlow: Flow<PagingData<MangaItem>> = Pager(
        config = PagingConfig(
            pageSize = 20,
            prefetchDistance = 5,
            enablePlaceholders = false
        )
    ) {
        MangaPagingSource { page ->
            MadaraScraper.fetchLatestUpdatesPage(page)
        }
    }.flow.cachedIn(viewModelScope)

    val isDownloadsPaused: StateFlow<Boolean> = repository.isDownloadsPaused

    fun togglePauseDownloads() {
        repository.togglePauseDownloads()
    }

    fun cancelDownload(mangaId: String, chapterId: String) {
        repository.cancelDownload(mangaId, chapterId)
    }

    fun clearDownloadQueue() {
        repository.clearAllDownloadsQueue()
    }

    private val _isLoadingHome = MutableStateFlow(false)
    val isLoadingHome: StateFlow<Boolean> = _isLoadingHome.asStateFlow()

    // Selected Manga details
    private val _selectedManga = MutableStateFlow<MangaItem?>(null)
    val selectedManga: StateFlow<MangaItem?> = _selectedManga.asStateFlow()

    private val _isLoadingDetails = MutableStateFlow(false)
    val isLoadingDetails: StateFlow<Boolean> = _isLoadingDetails.asStateFlow()

    private val _currentChapters = MutableStateFlow<List<ChapterItem>>(emptyList())
    val currentChapters: StateFlow<List<ChapterItem>> = _currentChapters.asStateFlow()

    // Chapter Reader
    private val _activeChapter = MutableStateFlow<ChapterItem?>(null)
    val activeChapter: StateFlow<ChapterItem?> = _activeChapter.asStateFlow()

    private val _isLoadingReader = MutableStateFlow(false)
    val isLoadingReader: StateFlow<Boolean> = _isLoadingReader.asStateFlow()

    private val _chapterPageIndex = MutableStateFlow(0)
    val chapterPageIndex: StateFlow<Int> = _chapterPageIndex.asStateFlow()

    private val _isWebtoonMode = MutableStateFlow(true)
    val isWebtoonMode: StateFlow<Boolean> = _isWebtoonMode.asStateFlow()

    // Independent search state for HomeScreen
    private val _homeSearchQuery = MutableStateFlow("")
    val homeSearchQuery: StateFlow<String> = _homeSearchQuery.asStateFlow()

    private val _homeSearchResults = MutableStateFlow<List<MangaItem>>(emptyList())
    val homeSearchResults: StateFlow<List<MangaItem>> = _homeSearchResults.asStateFlow()

    private val _homeIsSearching = MutableStateFlow(false)
    val homeIsSearching: StateFlow<Boolean> = _homeIsSearching.asStateFlow()

    private val _homeIsSearchMode = MutableStateFlow(false)
    val homeIsSearchMode: StateFlow<Boolean> = _homeIsSearchMode.asStateFlow()

    // Independent search state for ExploreScreen
    private val _exploreSearchQuery = MutableStateFlow("")
    val exploreSearchQuery: StateFlow<String> = _exploreSearchQuery.asStateFlow()

    private val _exploreSearchResults = MutableStateFlow<List<MangaItem>>(emptyList())
    val exploreSearchResults: StateFlow<List<MangaItem>> = _exploreSearchResults.asStateFlow()

    private val _exploreIsSearching = MutableStateFlow(false)
    val exploreIsSearching: StateFlow<Boolean> = _exploreIsSearching.asStateFlow()

    private val _exploreIsSearchMode = MutableStateFlow(false)
    val exploreIsSearchMode: StateFlow<Boolean> = _exploreIsSearchMode.asStateFlow()

    private val _selectedGenre = MutableStateFlow<String?>("الكل")
    val selectedGenre: StateFlow<String?> = _selectedGenre.asStateFlow()

    val homeFilteredMangas: StateFlow<List<MangaItem>> = kotlinx.coroutines.flow.combine(
        latestUpdates, homeSearchResults, homeSearchQuery, selectedGenre
    ) { latest, results, query, genre ->
        val cleanQuery = query.trim()
        val baseList = if (cleanQuery.isNotBlank()) {
            val localMatches = latest.filter { m ->
                m.title.contains(cleanQuery, ignoreCase = true) ||
                m.titleArabic.contains(cleanQuery, ignoreCase = true) ||
                m.id.contains(cleanQuery, ignoreCase = true)
            }
            (results + localMatches).distinctBy { it.siteUrl.ifEmpty { it.id } }
        } else {
            latest
        }

        val filteredByGenre = if (genre == null || genre.trim().isEmpty() || genre.trim() == "الكل") {
            baseList
        } else {
            baseList.filter { manga ->
                manga.genres.contains(genre)
            }
        }

        filteredByGenre.filter { manga ->
            val isValidTitle = manga.title != "الأحدث" && !manga.title.contains("الأحدث") && manga.title != "قائمة المانجا"
            isValidTitle
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val exploreFilteredMangas: StateFlow<List<MangaItem>> = kotlinx.coroutines.flow.combine(
        mangas, exploreSearchResults, exploreSearchQuery, selectedGenre
    ) { mangaList, results, query, genre ->
        val cleanQuery = query.trim()
        val baseList = if (cleanQuery.isNotBlank()) {
            val localMatches = mangaList.filter { manga ->
                manga.titleArabic.contains(cleanQuery, ignoreCase = true) ||
                manga.title.contains(cleanQuery, ignoreCase = true) ||
                manga.author.contains(cleanQuery, ignoreCase = true) ||
                manga.id.contains(cleanQuery, ignoreCase = true)
            }
            (results + localMatches).distinctBy { it.siteUrl.ifEmpty { it.id } }
        } else {
            mangaList
        }

        val filteredByGenre = if (genre == null || genre.trim().isEmpty() || genre.trim() == "الكل") {
            baseList
        } else {
            baseList.filter { manga ->
                manga.genres.contains(genre)
            }
        }

        filteredByGenre.filter { manga ->
            val isValidTitle = manga.title != "الأحدث" && !manga.title.contains("الأحدث") && manga.title != "قائمة المانجا"
            isValidTitle
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedLibraryCategory = MutableStateFlow(LibraryCategory.FAVORITE)
    val selectedLibraryCategory: StateFlow<LibraryCategory> = _selectedLibraryCategory.asStateFlow()

    // Cloudflare state
    private val _isCloudflareVerified = MutableStateFlow(true)
    val isCloudflareVerified: StateFlow<Boolean> = _isCloudflareVerified.asStateFlow()

    private val _showBypassDialog = MutableStateFlow(false)
    val showBypassDialog: StateFlow<Boolean> = _showBypassDialog.asStateFlow()

    // Favorite status of selected manga
    private val _isCurrentMangaFavorite = MutableStateFlow(false)
    val isCurrentMangaFavorite: StateFlow<Boolean> = _isCurrentMangaFavorite.asStateFlow()

    // Room flows
    val favoritesList: StateFlow<List<FavoriteMangaEntity>> = repository.allFavorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val readingHistoryList: StateFlow<List<ReadingHistoryEntity>> = repository.readingHistory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadedChaptersList: StateFlow<List<com.example.data.local.DownloadedChapterEntity>> = repository.downloadedChapters
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadProgressMap: StateFlow<Map<String, Float>> = repository.downloadProgress

    fun downloadChapter(manga: MangaItem, chapter: ChapterItem, quality: com.example.data.models.DownloadQuality = com.example.data.models.DownloadQuality.MEDIUM) {
        repository.enqueueDownloadChapter(manga, chapter, quality)
    }

    fun downloadAllChapters(manga: MangaItem, chapters: List<ChapterItem>, quality: com.example.data.models.DownloadQuality = com.example.data.models.DownloadQuality.MEDIUM) {
        repository.enqueueDownloadAllChapters(manga, chapters, quality)
    }

    fun deleteDownloadedChapter(mangaId: String, chapterId: String) {
        viewModelScope.launch {
            repository.deleteDownloadedChapter(mangaId, chapterId)
        }
    }

    fun openDownloadedChapter(downloaded: com.example.data.local.DownloadedChapterEntity) {
        val pagesList = downloaded.localPagePathsJson.split(",").filter { it.isNotBlank() }
        val chapterItem = ChapterItem(
            id = downloaded.chapterId,
            mangaId = downloaded.mangaId,
            chapterNumber = 1.0f,
            title = downloaded.chapterTitle,
            releaseDate = "محمّل بدون إنترنت",
            pages = pagesList
        )
        val mangaItem = _mangas.value.find { it.id == downloaded.mangaId } ?: MangaItem(
            id = downloaded.mangaId,
            title = downloaded.mangaTitle,
            titleArabic = downloaded.mangaTitle,
            coverUrl = downloaded.coverUrl
        )

        _selectedManga.value = mangaItem
        _activeChapter.value = chapterItem
        _chapterPageIndex.value = 0
    }

    private val _comments = MutableStateFlow<List<UserComment>>(emptyList())
    val comments: StateFlow<List<UserComment>> = _comments.asStateFlow()

    private var latestUpdatesPageLoaded = 1
    private var mangaListPageLoaded = 1
    private var hasReachedEndLatest = false
    private var hasReachedEndMangas = false

    private val _isLoadingMore = MutableStateFlow(false)
    val isLoadingMore: StateFlow<Boolean> = _isLoadingMore.asStateFlow()

    private val _isLoadingMoreLatest = MutableStateFlow(false)
    val isLoadingMoreLatest: StateFlow<Boolean> = _isLoadingMoreLatest.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    init {
        // Load Live Catalog from mangalik.net on start
        loadLiveCatalog()
    }

    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    private var searchJob: Job? = null
    private var homeSearchJob: Job? = null
    private var exploreSearchJob: Job? = null

    fun loadLiveCatalog() {
        viewModelScope.launch {
            _isLoadingHome.value = true
            latestUpdatesPageLoaded = 1
            mangaListPageLoaded = 1
            hasReachedEndLatest = false
            hasReachedEndMangas = false
            try {
                // Concurrently fetch home catalog (latest updates) and manga list in parallel
                val latestDeferred = async(Dispatchers.IO) { MadaraScraper.fetchLatestUpdatesPage(1) }
                val mangaListDeferred = async(Dispatchers.IO) { fetchExplorePage(1) }

                val latestItems = latestDeferred.await()
                val mangaListItems = mangaListDeferred.await()

                if (latestItems.isNotEmpty()) {
                    val distinctLatest = latestItems.distinctBy { it.siteUrl.ifEmpty { it.id } }
                    _latestUpdates.value = distinctLatest
                } else {
                    hasReachedEndLatest = true
                }

                if (mangaListItems.isNotEmpty()) {
                    val distinctMangaList = mangaListItems.distinctBy { it.siteUrl.ifEmpty { it.id } }
                    _mangas.value = distinctMangaList
                    repository.setLiveMangas(distinctMangaList)
                } else {
                    hasReachedEndMangas = true
                }

                val firstManga = latestItems.firstOrNull() ?: mangaListItems.firstOrNull()
                if (_selectedManga.value == null && firstManga != null) {
                    observeFavoriteStatus(firstManga.id)
                    loadComments(firstManga.id)
                }

                // Hide loading spinner immediately
                _isLoadingHome.value = false
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed to load live catalog", e)
            } finally {
                _isLoadingHome.value = false
            }
        }
    }

    fun loadNextLatestUpdatesPage() {
        if (_isLoadingMoreLatest.value || _isLoadingHome.value || hasReachedEndLatest) return
        viewModelScope.launch {
            _isLoadingMoreLatest.value = true
            try {
                val nextPage = latestUpdatesPageLoaded + 1
                val nextItems = withContext(Dispatchers.IO) { MadaraScraper.fetchLatestUpdatesPage(nextPage) }
                if (nextItems.isNotEmpty()) {
                    latestUpdatesPageLoaded = nextPage
                    val updatedList = withContext(Dispatchers.Default) {
                        (_latestUpdates.value + nextItems).distinctBy { it.siteUrl.ifEmpty { it.id } }
                    }
                    _latestUpdates.value = updatedList
                } else {
                    hasReachedEndLatest = true
                }
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed to load latest updates page $latestUpdatesPageLoaded", e)
                hasReachedEndLatest = true // Prevent infinite scroll requests on failure
            } finally {
                _isLoadingMoreLatest.value = false
            }
        }
    }

    fun loadNextPage() {
        if (_isLoadingMore.value || _isLoadingHome.value || hasReachedEndMangas) return
        viewModelScope.launch {
            _isLoadingMore.value = true
            try {
                val nextPage = mangaListPageLoaded + 1
                val nextItems = withContext(Dispatchers.IO) { fetchExplorePage(nextPage) }
                if (nextItems.isNotEmpty()) {
                    mangaListPageLoaded = nextPage
                    val updatedList = withContext(Dispatchers.Default) {
                        (_mangas.value + nextItems).distinctBy { it.siteUrl.ifEmpty { it.id } }
                    }
                    _mangas.value = updatedList
                    repository.setLiveMangas(updatedList)
                } else {
                    hasReachedEndMangas = true
                }
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed to load manga list page $mangaListPageLoaded", e)
                hasReachedEndMangas = true // Prevent infinite scroll requests on failure
            } finally {
                _isLoadingMore.value = false
            }
        }
    }

    fun setHomeSearchQuery(query: String) {
        _homeSearchQuery.value = query
        homeSearchJob?.cancel()

        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            _homeSearchResults.value = emptyList()
            _homeIsSearching.value = false
            return
        }

        if (cleanQuery.length >= 2) {
            homeSearchJob = viewModelScope.launch {
                delay(300) // Debounce typing input to prevent UI stutter
                _homeIsSearching.value = true
                try {
                    // Smart AJAX search with Madara wp-admin/admin-ajax.php
                    val results = MadaraScraper.searchMangaAjax(cleanQuery)
                    _homeSearchResults.value = results
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e("MangaViewModel", "Home Live AJAX search failed for $cleanQuery", e)
                } finally {
                    _homeIsSearching.value = false
                }
            }
        }
    }

    fun setHomeSearchMode(enabled: Boolean) {
        _homeIsSearchMode.value = enabled
        if (!enabled) {
            setHomeSearchQuery("")
        }
    }

    fun setExploreSearchQuery(query: String) {
        _exploreSearchQuery.value = query
        exploreSearchJob?.cancel()

        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) {
            _exploreSearchResults.value = emptyList()
            _exploreIsSearching.value = false
            return
        }

        if (cleanQuery.length >= 2) {
            exploreSearchJob = viewModelScope.launch {
                delay(300) // Debounce typing input to prevent UI stutter
                _exploreIsSearching.value = true
                try {
                    // Smart AJAX search with Madara wp-admin/admin-ajax.php
                    val results = MadaraScraper.searchMangaAjax(cleanQuery)
                    _exploreSearchResults.value = results
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.e("MangaViewModel", "Explore Live AJAX search failed for $cleanQuery", e)
                } finally {
                    _exploreIsSearching.value = false
                }
            }
        }
    }

    fun setExploreSearchMode(enabled: Boolean) {
        _exploreIsSearchMode.value = enabled
        if (!enabled) {
            setExploreSearchQuery("")
        }
    }

    fun openMangaDetails(manga: MangaItem) {
        _selectedManga.value = manga
        _currentChapters.value = repository.getChaptersForManga(manga.id)
        observeFavoriteStatus(manga.id)
        loadComments(manga.id)

        // Parse Live Madara Details if URL exists or can be built
        val targetUrl = when {
            manga.siteUrl.isNotBlank() -> manga.siteUrl
            manga.id.startsWith("http") -> manga.id
            manga.id.contains("/") -> "https://mangalik.net/${manga.id.trim('/')}/"
            else -> "https://mangalik.net/manga/${manga.id}/"
        }

        viewModelScope.launch {
            _isLoadingDetails.value = true
            try {
                val liveDetails = MadaraScraper.fetchMangaDetails(targetUrl)
                if (liveDetails != null) {
                    val (updatedItem, parsedChapters, _) = liveDetails
                    _selectedManga.value = updatedItem.copy(
                        id = manga.id,
                        isFeatured = manga.isFeatured,
                        siteUrl = targetUrl
                    )
                    if (parsedChapters.isNotEmpty()) {
                        _currentChapters.value = parsedChapters
                    }
                }
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed live details parse for $targetUrl", e)
            } finally {
                _isLoadingDetails.value = false
            }
        }
    }

    fun closeMangaDetails() {
        _selectedManga.value = null
        _currentChapters.value = emptyList()
    }

    fun openChapter(chapter: ChapterItem) {
        _chapterPageIndex.value = 0
        val manga = _selectedManga.value

        viewModelScope.launch {
            _isLoadingReader.value = true
            try {
                // Check if chapter is downloaded locally, and if so, load local pages directly!
                val dbDownloaded = repository.getDownloadedChapterDirectly(chapter.id)
                if (dbDownloaded != null) {
                    val pagesList = dbDownloaded.localPagePathsJson.split(",").filter { it.isNotBlank() }
                    val localChapter = chapter.copy(pages = pagesList, url = "")
                    _activeChapter.value = localChapter
                    if (manga != null) {
                        repository.saveReadingProgress(
                            mangaId = manga.id,
                            mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                            coverUrl = manga.coverUrl,
                            chapterId = localChapter.id,
                            chapterTitle = localChapter.title,
                            pageIndex = 0,
                            totalPages = localChapter.pages.size.coerceAtLeast(1)
                        )
                    }
                    _isLoadingReader.value = false
                    return@launch
                }

                _activeChapter.value = chapter

                // Determine primary chapter URL
                val primaryUrl = chapter.url.ifBlank {
                    if (chapter.id.startsWith("http")) chapter.id else ""
                }

                // Check instant in-memory cache first
                val memoryCached = MadaraScraper.getCachedChapterPages(primaryUrl) ?: MadaraScraper.getCachedChapterPages(chapter.id)
                if (!memoryCached.isNullOrEmpty()) {
                    Log.d("MangaViewModel", "Opening chapter instantly from memory cache: ${chapter.title}")
                    val cachedChapter = chapter.copy(pages = memoryCached, url = primaryUrl)
                    _activeChapter.value = cachedChapter
                    _isLoadingReader.value = false
                    if (manga != null) {
                        repository.saveReadingProgress(
                            mangaId = manga.id,
                            mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                            coverUrl = manga.coverUrl,
                            chapterId = cachedChapter.id,
                            chapterTitle = cachedChapter.title,
                            pageIndex = 0,
                            totalPages = cachedChapter.pages.size.coerceAtLeast(1)
                        )
                    }
                    _isLoadingReader.value = false
                    return@launch
                }

                val candidateUrls = mutableListOf<String>()
                if (primaryUrl.isNotBlank()) {
                    candidateUrls.add(primaryUrl)
                }
                if (manga != null && manga.siteUrl.isNotBlank()) {
                    val baseSite = manga.siteUrl.trimEnd('/')
                    val cleanId = chapter.id.trim('/')
                    candidateUrls.add("$baseSite/$cleanId/")
                    
                    val num = chapter.chapterNumber.toInt()
                    if (num > 0) {
                        candidateUrls.add("$baseSite/chapter-$num/")
                    }
                }

                var bestPages = emptyList<String>()
                var successfulUrl = ""

                // Try top candidates sequentially without spamming extra URLs
                for (urlCandidate in candidateUrls.distinct().take(2)) {
                    if (urlCandidate.isBlank()) continue
                    val pages = MadaraScraper.fetchChapterImages(urlCandidate)
                    if (pages.isNotEmpty()) {
                        bestPages = pages
                        successfulUrl = urlCandidate
                        break
                    }
                }

                if (bestPages.isEmpty()) {
                    Log.d("MangaViewModel", "OkHttp returned no pages, using Headless WebView fallback for Cloudflare...")
                    val targetUrl = candidateUrls.firstOrNull { it.isNotBlank() } ?: chapter.url
                    if (targetUrl.isNotBlank()) {
                        bestPages = CloudflareBypasser.scrapeChapterWithHeadlessWebViewSuspend(getApplication<Application>(), targetUrl)
                        if (bestPages.isNotEmpty()) {
                            successfulUrl = targetUrl
                        }
                    }
                }

                if (bestPages.isNotEmpty()) {
                    _activeChapter.value = chapter.copy(pages = bestPages, url = successfulUrl)
                    MadaraScraper.cacheChapterPages(chapter.id, bestPages)
                    MadaraScraper.cacheChapterPages(chapter.url, bestPages)
                    if (successfulUrl.isNotBlank()) MadaraScraper.cacheChapterPages(successfulUrl, bestPages)
                } else {
                    Log.w("MangaViewModel", "No pages found for chapter ${chapter.title} across candidates: $candidateUrls")
                }
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed to load/scrape chapter", e)
            } finally {
                _isLoadingReader.value = false
            }

            if (manga != null) {
                val activeCh = _activeChapter.value ?: chapter
                repository.saveReadingProgress(
                    mangaId = manga.id,
                    mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                    coverUrl = manga.coverUrl,
                    chapterId = activeCh.id,
                    chapterTitle = activeCh.title,
                    pageIndex = 0,
                    totalPages = activeCh.pages.size.coerceAtLeast(1)
                )
            }
        }
    }

    fun retryCurrentChapter() {
        val ch = _activeChapter.value
        if (ch != null) {
            openChapter(ch)
        }
    }

    private fun prefetchNextChapter(currentChapter: ChapterItem) {
        if (lastPrefetchedChapterId == currentChapter.id) {
            return // Already prefetched or prefetching the next of this chapter sequence!
        }
        lastPrefetchedChapterId = currentChapter.id

        // Cancel any pending prefetch task to prevent request spam
        prefetchJob?.cancel()
        prefetchJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val chapters = _currentChapters.value
                if (chapters.isEmpty()) return@launch

                val currentIndex = chapters.indexOfFirst { it.id == currentChapter.id || it.url == currentChapter.url }
                if (currentIndex == -1) return@launch

                // Look for next chapter in sequence
                val nextChapter = chapters.find { it.chapterNumber == currentChapter.chapterNumber + 1 }
                    ?: if (currentIndex > 0) chapters[currentIndex - 1] else null

                if (nextChapter != null && nextChapter.url.isNotBlank()) {
                    val cached = MadaraScraper.getCachedChapterPages(nextChapter.url) ?: MadaraScraper.getCachedChapterPages(nextChapter.id)
                    if (cached.isNullOrEmpty()) {
                        Log.d("MangaViewModel", "Background pre-fetching next chapter instantly: ${nextChapter.title}")
                        val pages = MadaraScraper.fetchChapterImages(nextChapter.url)
                        if (pages.isNotEmpty()) {
                            MadaraScraper.cacheChapterPages(nextChapter.url, pages)
                            MadaraScraper.cacheChapterPages(nextChapter.id, pages)
                            // Warm up Coil cache for the first 3 images
                            val imageLoader = coil.Coil.imageLoader(getApplication())
                            pages.take(3).forEach { imgUrl ->
                                val req = coil.request.ImageRequest.Builder(getApplication())
                                    .data(imgUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .build()
                                imageLoader.enqueue(req)
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.d("MangaViewModel", "Background chapter pre-fetch skipped: ${e.message}")
            }
        }
    }

    fun closeReader() {
        _activeChapter.value = null
    }

    fun updatePageIndex(index: Int) {
        _chapterPageIndex.value = index
        val chapter = _activeChapter.value ?: return
        val manga = _selectedManga.value ?: return
        
        // Trigger prefetching of the next chapter instantly with 0 delay once active reading is confirmed (index >= 1)
        if (index >= 1) {
            prefetchNextChapter(chapter)
        }

        viewModelScope.launch {
            repository.saveReadingProgress(
                mangaId = manga.id,
                mangaTitle = manga.titleArabic,
                coverUrl = manga.coverUrl,
                chapterId = chapter.id,
                chapterTitle = chapter.title,
                pageIndex = index,
                totalPages = chapter.pages.size.coerceAtLeast(1)
            )
        }
    }

    fun toggleWebtoonMode() {
        _isWebtoonMode.value = !_isWebtoonMode.value
    }

    // Genre to URL Slug Mapping
    private fun getGenreSlug(genre: String): String {
        return when (genre) {
            "أكشن" -> "اكشن"
            "إدارة المناطق" -> "إدارة-المناطق"
            "إنتقام" -> "إنتقام"
            "إيسيكاي" -> "إيسيكاي"
            "إثارة" -> "اثاره"
            "مغامرة" -> "مغامرة"
            "خيال" -> "خيال"
            "كوميديا" -> "كوميديا"
            "دراما" -> "دراما"
            "فنون قتالية" -> "فنون-قتاليه"
            "مانهوا" -> "مانهوا"
            "نظام" -> "نظام"
            "رومانسي" -> "رومانسى"
            "شوجو" -> "شوجو"
            "شونين" -> "شونين"
            "زمكاني" -> "زمكانى"
            "فوق الطبيعة" -> "فوق-الطبيعه"
            "تجسيد" -> "تجسيد"
            else -> genre.replace(" ", "-")
        }
    }

    private suspend fun fetchExplorePage(page: Int): List<MangaItem> {
        val genre = _selectedGenre.value
        return if (genre == "الكل" || genre.isNullOrBlank()) {
            MadaraScraper.fetchMangaListPage(page)
        } else if (genre == "أفضل المانجات" || genre == "الأفضل") {
            MadaraScraper.fetchTrendingMangaPage(page)
        } else {
            val slug = getGenreSlug(genre)
            MadaraScraper.fetchMangaByGenrePage(slug, page)
        }
    }

    fun setGenreFilter(genre: String?) {
        val newGenre = genre ?: "الكل"
        if (_selectedGenre.value == newGenre) return
        _selectedGenre.value = newGenre
        
        viewModelScope.launch {
            _isLoadingHome.value = true
            mangaListPageLoaded = 1
            hasReachedEndMangas = false
            try {
                val items = withContext(Dispatchers.IO) { fetchExplorePage(1) }
                if (items.isNotEmpty()) {
                    val distinct = items.distinctBy { it.siteUrl.ifEmpty { it.id } }
                    _mangas.value = distinct
                } else {
                    _mangas.value = emptyList()
                }
            } catch (e: Exception) {
                Log.e("MangaViewModel", "Failed to load genre", e)
            } finally {
                _isLoadingHome.value = false
            }
        }
    }

    fun setLibraryCategory(category: LibraryCategory) {
        _selectedLibraryCategory.value = category
    }

    private var favoriteObserveJob: Job? = null

    fun toggleFavorite(manga: MangaItem, category: LibraryCategory = LibraryCategory.FAVORITE) {
        _isCurrentMangaFavorite.value = !_isCurrentMangaFavorite.value
        viewModelScope.launch {
            repository.toggleFavorite(manga, category)
        }
    }

    fun removeFromFavorites(mangaId: String) {
        _isCurrentMangaFavorite.value = false
        viewModelScope.launch {
            repository.removeFavorite(mangaId)
        }
    }

    private fun observeFavoriteStatus(mangaId: String) {
        favoriteObserveJob?.cancel()
        favoriteObserveJob = viewModelScope.launch {
            repository.isFavorite(mangaId).collect { isFav ->
                _isCurrentMangaFavorite.value = isFav
            }
        }
    }

    private fun loadComments(mangaId: String) {
        viewModelScope.launch {
            repository.getComments(mangaId).collect { commentList ->
                _comments.value = commentList
            }
        }
    }

    fun postComment(mangaId: String, userName: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            repository.addComment(mangaId, userName, text)
        }
    }

    fun toggleCommentLike(commentId: String, currentLikes: Int, isLiked: Boolean) {
        viewModelScope.launch {
            repository.toggleCommentLike(commentId, currentLikes, isLiked)
        }
    }

    fun setCloudflareVerified(verified: Boolean, cookies: String = "", userAgent: String = "") {
        _isCloudflareVerified.value = verified
        repository.isCloudflareBypassed = verified
        if (cookies.isNotBlank()) {
            MadaraScraper.cloudflareCookies = cookies
            repository.cloudflareCookies = cookies
        }
        if (userAgent.isNotBlank()) {
            MadaraScraper.userAgent = userAgent
        }
        // Refresh catalog with new cookies
        loadLiveCatalog()
    }

    fun setShowBypassDialog(show: Boolean) {
        _showBypassDialog.value = show
    }
}
