package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.models.UserAccount
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class AuthManager private constructor(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("speedmanga_auth_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<UserAccount?>(null)
    val currentUser: StateFlow<UserAccount?> = _currentUser.asStateFlow()

    init {
        loadUsersAndSession()
    }

    private fun loadUsersAndSession() {
        val allUsers = getAllUsers()
        val currentId = prefs.getString(KEY_CURRENT_USER_ID, null)

        if (currentId != null) {
            val found = allUsers.find { it.id == currentId }
            _currentUser.value = found
        } else if (allUsers.isEmpty()) {
            // Seed a default demo user so user can also log in if they want, or register new
            val demoUser = UserAccount(
                id = "demo_user_1",
                name = "أحمد القارئ",
                email = "ahmed@speedmanga.com",
                passwordHash = "123456",
                isVerified = true,
                verificationCode = "123456"
            )
            saveUser(demoUser)
            _currentUser.value = demoUser
            prefs.edit().putString(KEY_CURRENT_USER_ID, demoUser.id).apply()
        } else {
            _currentUser.value = allUsers.firstOrNull()
            _currentUser.value?.let { user ->
                prefs.edit().putString(KEY_CURRENT_USER_ID, user.id).apply()
            }
        }
    }

    fun getAllUsers(): List<UserAccount> {
        val jsonString = prefs.getString(KEY_ALL_USERS, "[]") ?: "[]"
        val list = mutableListOf<UserAccount>()
        try {
            val jsonArray = JSONArray(jsonString)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    UserAccount(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        name = obj.optString("name", "مستخدم"),
                        email = obj.optString("email", ""),
                        passwordHash = obj.optString("passwordHash", ""),
                        isVerified = obj.optBoolean("isVerified", false),
                        verificationCode = obj.optString("verificationCode", "123456"),
                        avatarUrl = obj.optString("avatarUrl", ""),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun saveUsersList(users: List<UserAccount>) {
        val jsonArray = JSONArray()
        users.forEach { user ->
            val obj = JSONObject().apply {
                put("id", user.id)
                put("name", user.name)
                put("email", user.email)
                put("passwordHash", user.passwordHash)
                put("isVerified", user.isVerified)
                put("verificationCode", user.verificationCode)
                put("avatarUrl", user.avatarUrl)
                put("createdAt", user.createdAt)
            }
            jsonArray.put(obj)
        }
        prefs.edit().putString(KEY_ALL_USERS, jsonArray.toString()).apply()
    }

    private fun saveUser(user: UserAccount) {
        val users = getAllUsers().toMutableList()
        val index = users.indexOfFirst { it.id == user.id || it.email.equals(user.email, ignoreCase = true) }
        if (index >= 0) {
            users[index] = user
        } else {
            users.add(user)
        }
        saveUsersList(users)
    }

    fun register(name: String, email: String, password: String, requireEmailVerification: Boolean = false): Result<UserAccount> {
        val cleanName = name.trim()
        val cleanEmail = email.trim().lowercase()
        val cleanPass = password.trim()

        if (cleanName.isEmpty()) return Result.failure(Exception("يرجى إدخال الاسم الكامل"))
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return Result.failure(Exception("يرجى إدخال بريد إلكتروني صحيح"))
        }
        if (cleanPass.length < 6) {
            return Result.failure(Exception("كلمة المرور يجب أن تكون 6 أحرف على الأقل"))
        }

        val users = getAllUsers()
        if (users.any { it.email.equals(cleanEmail, ignoreCase = true) }) {
            return Result.failure(Exception("هذا البريد الإلكتروني مسجل بالفعل! يمكنك تسجيل الدخول."))
        }

        val code = (100000..999999).random().toString()
        val newUser = UserAccount(
            name = cleanName,
            email = cleanEmail,
            passwordHash = cleanPass,
            isVerified = !requireEmailVerification,
            verificationCode = code
        )

        saveUser(newUser)
        _currentUser.value = newUser
        prefs.edit().putString(KEY_CURRENT_USER_ID, newUser.id).apply()

        return Result.success(newUser)
    }

    fun loginOrRegisterFirebaseUser(userAccount: UserAccount) {
        val existingUsers = getAllUsers()
        val existing = existingUsers.find { it.email.equals(userAccount.email, ignoreCase = true) }
        val updatedUser = if (existing != null) {
            existing.copy(isVerified = true)
        } else {
            userAccount.copy(isVerified = true)
        }
        saveUser(updatedUser)
        _currentUser.value = updatedUser
        prefs.edit().putString(KEY_CURRENT_USER_ID, updatedUser.id).apply()
    }

    fun resendVerificationCode(email: String): Result<String> {
        val cleanEmail = email.trim().lowercase()
        val users = getAllUsers()
        val user = users.find { it.email.equals(cleanEmail, ignoreCase = true) }
            ?: return Result.failure(Exception("المستخدم غير موجود"))

        val newCode = (100000..999999).random().toString()
        val updated = user.copy(verificationCode = newCode)
        saveUser(updated)

        if (_currentUser.value?.email.equals(cleanEmail, ignoreCase = true)) {
            _currentUser.value = updated
        }

        return Result.success(newCode)
    }

    fun verifyEmail(email: String, code: String): Result<UserAccount> {
        val cleanEmail = email.trim().lowercase()
        val cleanCode = code.trim()

        val users = getAllUsers()
        val user = users.find { it.email.equals(cleanEmail, ignoreCase = true) }
            ?: return Result.failure(Exception("المستخدم غير موجود"))

        if (user.verificationCode != cleanCode) {
            return Result.failure(Exception("كود التفعيل غير صحيح! يرجى التأكد من الكود المكون من 6 أرقام."))
        }

        val verifiedUser = user.copy(isVerified = true)
        saveUser(verifiedUser)
        _currentUser.value = verifiedUser
        prefs.edit().putString(KEY_CURRENT_USER_ID, verifiedUser.id).apply()

        return Result.success(verifiedUser)
    }

    fun login(email: String, password: String): Result<UserAccount> {
        val cleanEmail = email.trim().lowercase()
        val cleanPass = password.trim()

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(cleanEmail).matches()) {
            return Result.failure(Exception("يرجى إدخال بريد إلكتروني صحيح"))
        }

        val users = getAllUsers()
        val user = users.find { it.email.equals(cleanEmail, ignoreCase = true) }
            ?: return Result.failure(Exception("البريد الإلكتروني غير مسجل! اضغط على إنشاء حساب جديد"))

        if (user.passwordHash != cleanPass) {
            return Result.failure(Exception("كلمة المرور غير صحيحة"))
        }

        _currentUser.value = user
        prefs.edit().putString(KEY_CURRENT_USER_ID, user.id).apply()

        return Result.success(user)
    }

    fun logout() {
        _currentUser.value = null
        prefs.edit().remove(KEY_CURRENT_USER_ID).apply()
    }

    fun updateName(newName: String): Boolean {
        val current = _currentUser.value ?: return false
        val clean = newName.trim()
        if (clean.isEmpty()) return false

        val updated = current.copy(name = clean)
        saveUser(updated)
        _currentUser.value = updated
        return true
    }

    companion object {
        private const val KEY_CURRENT_USER_ID = "current_user_id"
        private const val KEY_ALL_USERS = "all_registered_users"

        @Volatile
        private var INSTANCE: AuthManager? = null

        fun getInstance(context: Context): AuthManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: AuthManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
