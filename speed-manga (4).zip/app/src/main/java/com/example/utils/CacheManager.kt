package com.example.utils

import android.content.Context
import android.util.Log
import coil.Coil
import java.io.File

object CacheManager {

    /**
     * Calculates total cache size in bytes (cacheDir + externalCacheDir)
     */
    fun getCacheSizeBytes(context: Context): Long {
        var size = 0L
        try {
            context.cacheDir?.let { size += getFolderSize(it) }
            context.externalCacheDir?.let { size += getFolderSize(it) }
        } catch (e: Exception) {
            Log.e("CacheManager", "Error calculating cache size", e)
        }
        return size
    }

    /**
     * Formats cache size to human readable string (e.g., "12.4 MB")
     */
    fun getFormattedCacheSize(context: Context): String {
        val bytes = getCacheSizeBytes(context)
        return when {
            bytes >= 1024 * 1024 * 1024 -> String.format("%.2f غيغابايت", bytes.toDouble() / (1024 * 1024 * 1024))
            bytes >= 1024 * 1024 -> String.format("%.1f ميجابايت", bytes.toDouble() / (1024 * 1024))
            bytes >= 1024 -> String.format("%.0f كيلوبايت", bytes.toDouble() / 1024)
            else -> "$bytes بايت"
        }
    }

    /**
     * Clears all cache directories (Coil memory + disk cache and cacheDir)
     */
    fun clearAppCache(context: Context): Boolean {
        return try {
            // 1. Clear Coil Memory & Disk Caches
            val imageLoader = Coil.imageLoader(context)
            imageLoader.memoryCache?.clear()
            imageLoader.diskCache?.clear()

            // 2. Clear cacheDir
            context.cacheDir?.let { deleteDirContents(it) }

            // 3. Clear externalCacheDir
            context.externalCacheDir?.let { deleteDirContents(it) }

            true
        } catch (e: Exception) {
            Log.e("CacheManager", "Error clearing cache", e)
            false
        }
    }

    /**
     * Auto-trims cache on startup if cache size exceeds 50 MB
     */
    fun autoTrimIfNeeded(context: Context, maxMB: Int = 40) {
        try {
            val maxBytes = maxMB * 1024 * 1024L
            val currentSize = getCacheSizeBytes(context)
            if (currentSize > maxBytes) {
                Log.d("CacheManager", "Auto trimming cache from $currentSize bytes")
                clearAppCache(context)
            }
        } catch (e: Exception) {
            Log.e("CacheManager", "Error during autoTrimIfNeeded", e)
        }
    }

    private fun getFolderSize(file: File): Long {
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        var size = 0L
        val children = file.listFiles() ?: return 0L
        for (child in children) {
            size += getFolderSize(child)
        }
        return size
    }

    private fun deleteDirContents(dir: File): Boolean {
        if (dir.exists() && dir.isDirectory) {
            val children = dir.listFiles() ?: return true
            for (child in children) {
                if (child.isDirectory) {
                    deleteDirContents(child)
                }
                child.delete()
            }
        }
        return true
    }
}
