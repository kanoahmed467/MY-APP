package com.example.utils

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Properties
import javax.mail.Authenticator
import javax.mail.Message
import javax.mail.PasswordAuthentication
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

object EmailSender {
    private const val PREFS_NAME = "email_smtp_settings"
    private const val KEY_SMTP_HOST = "smtp_host"
    private const val KEY_SMTP_PORT = "smtp_port"
    private const val KEY_SENDER_EMAIL = "sender_email"
    private const val KEY_SENDER_PASS = "sender_pass"
    private const val KEY_SENDER_NAME = "sender_name"

    fun getSmtpHost(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SMTP_HOST, "smtp.gmail.com") ?: "smtp.gmail.com"

    fun getSmtpPort(context: Context): Int =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getInt(KEY_SMTP_PORT, 465)

    fun getSenderEmail(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SENDER_EMAIL, "") ?: ""

    fun getSenderPass(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SENDER_PASS, "") ?: ""

    fun getSenderName(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SENDER_NAME, "SpeedManga") ?: "SpeedManga"

    fun isSmtpConfigured(context: Context): Boolean {
        return getSenderEmail(context).isNotBlank() && getSenderPass(context).isNotBlank()
    }

    fun saveSmtpSettings(
        context: Context,
        host: String,
        port: Int,
        senderEmail: String,
        senderPass: String,
        senderName: String = "SpeedManga"
    ) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putString(KEY_SMTP_HOST, host.trim())
            .putInt(KEY_SMTP_PORT, port)
            .putString(KEY_SENDER_EMAIL, senderEmail.trim())
            .putString(KEY_SENDER_PASS, senderPass.trim())
            .putString(KEY_SENDER_NAME, senderName.trim())
            .apply()
    }

    suspend fun sendVerificationEmail(
        context: Context,
        recipientEmail: String,
        userName: String,
        verificationCode: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val host = getSmtpHost(context)
            val port = getSmtpPort(context)
            val senderEmail = getSenderEmail(context)
            val senderPass = getSenderPass(context)
            val senderName = getSenderName(context)

            if (senderEmail.isBlank() || senderPass.isBlank()) {
                return@withContext Result.failure(
                    Exception("لم يتم ضبط بيانات حساب إرسال البريد (SMTP) بعد. يرجى إدخال البريد الإلكتروني وكلمة مرور التطبيق في إعدادات التطبيق.")
                )
            }

            val props = Properties().apply {
                put("mail.smtp.host", host)
                put("mail.smtp.socketFactory.port", port.toString())
                put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory")
                put("mail.smtp.auth", "true")
                put("mail.smtp.port", port.toString())
                put("mail.smtp.ssl.enable", "true")
                put("mail.smtp.timeout", "10000")
                put("mail.smtp.connectiontimeout", "10000")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(senderEmail, senderPass)
                }
            })

            val mimeMessage = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, senderName))
                addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                subject = "رمز تفعيل حسابك في تطبيق $senderName: $verificationCode"

                val htmlContent = """
                    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; text-align: right; direction: rtl; padding: 24px; background-color: #121212; color: #ffffff; border-radius: 14px; max-width: 500px; margin: 0 auto; border: 1px solid #2A2A2A;">
                        <h2 style="color: #FF2B4A; margin-top: 0;">SpeedManga 📖</h2>
                        <p style="font-size: 16px; color: #e0e0e0; margin-bottom: 12px;">أهلاً بك يا <b>$userName</b> 👋</p>
                        <p style="font-size: 14px; color: #b0b0b0; line-height: 1.6;">شكراً لتسجيلك في تطبيق SpeedManga! رمز التفعيل الخاص بك لتأكيد وحماية بريدك الإلكتروني هو:</p>
                        <div style="text-align: center; margin: 28px 0;">
                            <span style="display: inline-block; background-color: #2D1418; color: #FF2B4A; border: 2px solid #FF2B4A; padding: 14px 32px; font-size: 32px; font-weight: bold; letter-spacing: 8px; border-radius: 12px;">
                                $verificationCode
                            </span>
                        </div>
                        <p style="font-size: 12px; color: #888888; margin-top: 20px;">إذا لم تكن أنت من قام بالتسجيل، يرجى تجاهل هذا البريد.</p>
                    </div>
                """.trimIndent()

                setContent(htmlContent, "text/html; charset=utf-8")
            }

            Transport.send(mimeMessage)
            Log.d("EmailSender", "Real verification email sent successfully to $recipientEmail")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("EmailSender", "Failed to send email: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun sendWelcomeEmail(
        context: Context,
        recipientEmail: String,
        userName: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val host = getSmtpHost(context)
            val port = getSmtpPort(context)
            val senderEmail = getSenderEmail(context)
            val senderPass = getSenderPass(context)
            val senderName = getSenderName(context)

            if (senderEmail.isBlank() || senderPass.isBlank()) {
                return@withContext Result.failure(Exception("SMTP غير مضبوط"))
            }

            val props = Properties().apply {
                put("mail.smtp.host", host)
                put("mail.smtp.socketFactory.port", port.toString())
                put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory")
                put("mail.smtp.auth", "true")
                put("mail.smtp.port", port.toString())
                put("mail.smtp.ssl.enable", "true")
            }

            val session = Session.getInstance(props, object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication {
                    return PasswordAuthentication(senderEmail, senderPass)
                }
            })

            val mimeMessage = MimeMessage(session).apply {
                setFrom(InternetAddress(senderEmail, senderName))
                addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                subject = "مرحباً بك في تطبيق SpeedManga! 📚"

                val htmlContent = """
                    <div style="font-family: Arial, sans-serif; text-align: right; direction: rtl; padding: 24px; background-color: #121212; color: #ffffff; border-radius: 14px;">
                        <h2 style="color: #FF2B4A;">أهلاً بك في SpeedManga 🎉</h2>
                        <p style="font-size: 15px; color: #e0e0e0;">عزيزي <b>$userName</b>،</p>
                        <p style="font-size: 14px; color: #cccccc; line-height: 1.6;">تم تفعيل حسابك بنجاح! استمتع بقراءة آلاف المانجات والمانهوا المترجمة بأعلى جودة وبأسرع سيرفرات.</p>
                    </div>
                """.trimIndent()

                setContent(htmlContent, "text/html; charset=utf-8")
            }

            Transport.send(mimeMessage)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
