package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.models.UserAccount
import com.google.firebase.auth.ActionCodeSettings
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class FirebaseEmailLinkAuthManager(private val context: Context, private val authManager: AuthManager) {

    private val prefs: SharedPreferences = context.getSharedPreferences("speedmanga_auth_prefs", Context.MODE_PRIVATE)
    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    companion object {
        const val KEY_EMAIL_FOR_SIGN_IN = "emailForSignIn"
        const val DEFAULT_CONTINUE_URL = "https://speed-manga.web.app"
    }

    /**
     * Save email in local SharedPreferences (or localStorage equivalents)
     */
    fun saveEmailForSignIn(email: String) {
        prefs.edit().putString(KEY_EMAIL_FOR_SIGN_IN, email.trim()).apply()
    }

    /**
     * Get saved email from SharedPreferences
     */
    fun getSavedEmailForSignIn(): String? {
        return prefs.getString(KEY_EMAIL_FOR_SIGN_IN, null)
    }

    /**
     * Clear saved email from SharedPreferences
     */
    fun clearSavedEmailForSignIn() {
        prefs.edit().remove(KEY_EMAIL_FOR_SIGN_IN).apply()
    }

    /**
     * Check if the incoming deep link URL is a Firebase Email Auth Link
     */
    fun isSignInWithEmailLink(link: String?): Boolean {
        if (link.isNullOrBlank()) return false
        return try {
            firebaseAuth.isSignInWithEmailLink(link)
        } catch (e: Exception) {
            Log.e("FirebaseEmailAuth", "Error checking email link: ${e.message}")
            false
        }
    }

    /**
     * Send passwordless sign-in link to email via Firebase
     */
    suspend fun sendSignInLinkToEmail(
        email: String,
        continueUrl: String = DEFAULT_CONTINUE_URL
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        if (cleanEmail.isEmpty() || !cleanEmail.contains("@")) {
            return@withContext Result.failure(Exception("يرجى إدخال بريد إلكتروني صحيح"))
        }

        try {
            val actionCodeSettings = ActionCodeSettings.newBuilder()
                .setUrl(continueUrl)
                .setHandleCodeInApp(true)
                .setAndroidPackageName(
                    context.packageName,
                    true, /* installIfNotAvailable */
                    "21"  /* minimumVersion */
                )
                .build()

            firebaseAuth.sendSignInLinkToEmail(cleanEmail, actionCodeSettings).await()

            // Save email locally as required
            saveEmailForSignIn(cleanEmail)

            Log.d("FirebaseEmailAuth", "Sent sign-in link successfully to $cleanEmail")
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("FirebaseEmailAuth", "Failed to send sign-in link: ${e.message}", e)
            val friendlyMsg = when {
                e.message?.contains("configuration", ignoreCase = true) == true ->
                    "يرجى التأكد من تفعيل خيار (Email link / Passwordless) في وحدة تحكم Firebase."
                e.message?.contains("network", ignoreCase = true) == true ->
                    "خطأ في الاتصال بالشبكة، يرجى المحاولة لاحقاً."
                else -> e.message ?: "فشل إرسال رابط الدخول إلى البريد الإلكتروني."
            }
            Result.failure(Exception(friendlyMsg))
        }
    }

    /**
     * Complete sign in with the email link
     */
    suspend fun signInWithEmailLink(
        email: String,
        emailLink: String
    ): Result<UserAccount> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim()
        if (cleanEmail.isEmpty()) {
            return@withContext Result.failure(Exception("البريد الإلكتروني مطلوب لإكمال عملية الدخول"))
        }

        try {
            val authResult = firebaseAuth.signInWithEmailLink(cleanEmail, emailLink).await()
            val firebaseUser = authResult.user

            // Clear local emailForSignIn on success
            clearSavedEmailForSignIn()

            val userName = firebaseUser?.displayName
                ?.ifBlank { null }
                ?: cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }

            val userAccount = UserAccount(
                id = firebaseUser?.uid ?: java.util.UUID.randomUUID().toString(),
                name = userName,
                email = cleanEmail,
                passwordHash = "",
                isVerified = true,
                verificationCode = ""
            )

            // Register/login in local AuthManager session
            authManager.loginOrRegisterFirebaseUser(userAccount)

            Log.d("FirebaseEmailAuth", "Successfully signed in with email link: ${userAccount.email}")
            Result.success(userAccount)
        } catch (e: Exception) {
            Log.e("FirebaseEmailAuth", "Failed to sign in with link: ${e.message}", e)
            val friendlyMsg = when {
                e.message?.contains("expired", ignoreCase = true) == true ->
                    "انتهت صلاحية رابط الدخول، يرجى طلب رابط جديد."
                e.message?.contains("invalid", ignoreCase = true) == true ->
                    "رابط الدخول غير صالح أو تم استخدامه سابقاً."
                else -> e.message ?: "فشلت عملية تسجيل الدخول باستخدام الرابط."
            }
            Result.failure(Exception(friendlyMsg))
        }
    }
}

private fun String?.isNull_or_blank(): Boolean = this == null || this.trim().isEmpty()
