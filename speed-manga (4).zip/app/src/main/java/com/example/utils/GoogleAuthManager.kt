package com.example.utils

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.example.data.models.UserAccount
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class GoogleAuthManager(
    private val context: Context,
    private val authManager: AuthManager
) {
    private val credentialManager = CredentialManager.create(context)
    private val firebaseAuth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    companion object {
        const val WEB_CLIENT_ID = "232593514880-q1j9670rdlqesloukpsueomsc5f37mel.apps.googleusercontent.com"
    }

    suspend fun signInWithGoogle(activityContext: Context): Result<UserAccount> = withContext(Dispatchers.IO) {
        try {
            val googleIdOption = GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(WEB_CLIENT_ID)
                .setAutoSelectEnabled(false)
                .build()

            val request = GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build()

            val result = credentialManager.getCredential(
                context = activityContext,
                request = request
            )

            val credential = result.credential
            if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                val idToken = googleIdTokenCredential.idToken

                val firebaseCredential = GoogleAuthProvider.getCredential(idToken, null)
                val authResult = firebaseAuth.signInWithCredential(firebaseCredential).await()
                val firebaseUser = authResult.user

                val userAccount = UserAccount(
                    id = firebaseUser?.uid ?: java.util.UUID.randomUUID().toString(),
                    name = firebaseUser?.displayName ?: googleIdTokenCredential.displayName ?: "Google User",
                    email = firebaseUser?.email ?: googleIdTokenCredential.id,
                    passwordHash = "",
                    isVerified = true,
                    verificationCode = ""
                )

                authManager.loginOrRegisterFirebaseUser(userAccount)
                Result.success(userAccount)
            } else {
                Result.failure(Exception("نوع الاعتماد المحصل عليه غير صالح"))
            }
        } catch (e: GetCredentialException) {
            Log.e("GoogleAuthManager", "Credential error: ${e.message}", e)
            val msg = when {
                e.message?.contains("canceled", ignoreCase = true) == true ->
                    "تم إلغاء عملية تسجيل الدخول بواسطة Google"
                e.message?.contains("No credentials available", ignoreCase = true) == true ||
                e.message?.contains("No credential", ignoreCase = true) == true ->
                    "تعذر العثور على حساب Google مسجّل على هذا الجهاز. يرجى إضافة حساب Google من إعدادات النظام أولاً أو تسجيل الدخول عبر البريد الإلكتروني."
                else -> "فشلت عملية تسجيل الدخول بواسطة Google: ${e.message}"
            }
            Result.failure(Exception(msg))
        } catch (e: Exception) {
            Log.e("GoogleAuthManager", "Sign in error: ${e.message}", e)
            Result.failure(Exception(e.message ?: "فشلت عملية تسجيل الدخول بواسطة Google"))
        }
    }
}
