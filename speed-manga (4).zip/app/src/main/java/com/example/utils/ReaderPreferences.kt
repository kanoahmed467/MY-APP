package com.example.utils

import android.content.Context
import android.content.SharedPreferences

data class ReaderSettings(
    val readingMode: String = "WEBTOON", // WEBTOON, RTL, LTR, VERTICAL_PAGED
    val fullscreen: Boolean = false,
    val keepScreenOn: Boolean = true,
    val showPageNumber: Boolean = true,
    val pageNumberOpacity: Float = 0.7f,
    val pageNumberPlacement: String = "BOTTOM_CENTER", // BOTTOM_CENTER, BOTTOM_RIGHT, TOP_CENTER
    val showProgressBar: Boolean = true,
    val progressBarPlacement: String = "BOTTOM", // TOP, BOTTOM
    val cropMargins: Boolean = false,
    val sidePadding: Int = 0, // 0, 8, 16
    val pageScaling: String = "FIT_WIDTH", // FIT_WIDTH, FIT_HEIGHT, ORIGINAL
    val smoothTransitions: Boolean = true,
    val imageFiltering: String = "BILINEAR", // BILINEAR, BICUBIC
    val tapToNavigate: Boolean = true,
    val volumeKeyNav: Boolean = false,
    val keyboardShortcuts: Boolean = true,
    val customBrightness: Boolean = false,
    val brightnessLevel: Float = 1.0f,
    val tintMode: String = "STANDARD", // STANDARD, SEPIA, INVERTED
    val doublePageSpread: Boolean = true,
    val pairAdjacentLandscape: Boolean = true
)

class ReaderPreferences(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    fun getSettings(): ReaderSettings {
        return ReaderSettings(
            readingMode = prefs.getString("reading_mode", "WEBTOON") ?: "WEBTOON",
            fullscreen = prefs.getBoolean("fullscreen", false),
            keepScreenOn = prefs.getBoolean("keep_screen_on", true),
            showPageNumber = prefs.getBoolean("show_page_number", true),
            pageNumberOpacity = prefs.getFloat("page_number_opacity", 0.7f),
            pageNumberPlacement = prefs.getString("page_number_placement", "BOTTOM_CENTER") ?: "BOTTOM_CENTER",
            showProgressBar = prefs.getBoolean("show_progress_bar", true),
            progressBarPlacement = prefs.getString("progress_bar_placement", "BOTTOM") ?: "BOTTOM",
            cropMargins = prefs.getBoolean("crop_margins", false),
            sidePadding = prefs.getInt("side_padding", 0),
            pageScaling = prefs.getString("page_scaling", "FIT_WIDTH") ?: "FIT_WIDTH",
            smoothTransitions = prefs.getBoolean("smooth_transitions", true),
            imageFiltering = prefs.getString("image_filtering", "BILINEAR") ?: "BILINEAR",
            tapToNavigate = prefs.getBoolean("tap_to_navigate", true),
            volumeKeyNav = prefs.getBoolean("volume_key_nav", false),
            keyboardShortcuts = prefs.getBoolean("keyboard_shortcuts", true),
            customBrightness = prefs.getBoolean("custom_brightness", false),
            brightnessLevel = prefs.getFloat("brightness_level", 1.0f),
            tintMode = prefs.getString("tint_mode", "STANDARD") ?: "STANDARD",
            doublePageSpread = prefs.getBoolean("double_page_spread", true),
            pairAdjacentLandscape = prefs.getBoolean("pair_adjacent_landscape", true)
        )
    }

    fun updateSettings(settings: ReaderSettings) {
        prefs.edit().apply {
            putString("reading_mode", settings.readingMode)
            putBoolean("fullscreen", settings.fullscreen)
            putBoolean("keep_screen_on", settings.keepScreenOn)
            putBoolean("show_page_number", settings.showPageNumber)
            putFloat("page_number_opacity", settings.pageNumberOpacity)
            putString("page_number_placement", settings.pageNumberPlacement)
            putBoolean("show_progress_bar", settings.showProgressBar)
            putString("progress_bar_placement", settings.progressBarPlacement)
            putBoolean("crop_margins", settings.cropMargins)
            putInt("side_padding", settings.sidePadding)
            putString("page_scaling", settings.pageScaling)
            putBoolean("smooth_transitions", settings.smoothTransitions)
            putString("image_filtering", settings.imageFiltering)
            putBoolean("tap_to_navigate", settings.tapToNavigate)
            putBoolean("volume_key_nav", settings.volumeKeyNav)
            putBoolean("keyboard_shortcuts", settings.keyboardShortcuts)
            putBoolean("custom_brightness", settings.customBrightness)
            putFloat("brightness_level", settings.brightnessLevel)
            putString("tint_mode", settings.tintMode)
            putBoolean("double_page_spread", settings.doublePageSpread)
            putBoolean("pair_adjacent_landscape", settings.pairAdjacentLandscape)
            apply()
        }
    }
}
