package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class TelegramManager private constructor(context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences("telegram_prefs", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .dns(com.example.data.network.FastDns)
        .connectTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    companion object {
        const val DEFAULT_CHANNEL_ID = "-1003627092623"
        const val DEFAULT_BOT_TOKEN = "8562285390:AAFOmTMdrxyIHb5Te4Rby9nN46j3BqiQTMk"
        const val TAG = "TelegramManager"

        @Volatile
        private var INSTANCE: TelegramManager? = null

        fun getInstance(context: Context): TelegramManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: TelegramManager(context.applicationContext).also { INSTANCE = it }
            }
        }

        fun openTelegramChannel(context: Context, channelUrl: String = "https://t.me/SpeedManga") {
            try {
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(channelUrl))
                intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Could not open Telegram channel", e)
            }
        }
    }

    var botToken: String
        get() = prefs.getString("bot_token", DEFAULT_BOT_TOKEN) ?: DEFAULT_BOT_TOKEN
        set(value) { prefs.edit().putString("bot_token", value.trim()).apply() }

    var channelId: String
        get() = prefs.getString("channel_id", DEFAULT_CHANNEL_ID) ?: DEFAULT_CHANNEL_ID
        set(value) { prefs.edit().putString("channel_id", value.trim()).apply() }

    var isAutoUploadEnabled: Boolean
        get() = prefs.getBoolean("auto_upload", true)
        set(value) { prefs.edit().putBoolean("auto_upload", value).apply() }

    var uploadAsPdf: Boolean
        get() = prefs.getBoolean("upload_as_pdf", true)
        set(value) { prefs.edit().putBoolean("upload_as_pdf", value).apply() }

    var uploadAsCbz: Boolean
        get() = prefs.getBoolean("upload_as_cbz", false)
        set(value) { prefs.edit().putBoolean("upload_as_cbz", value).apply() }

    var uploadCoverPhoto: Boolean
        get() = prefs.getBoolean("upload_cover_photo", true)
        set(value) { prefs.edit().putBoolean("upload_cover_photo", value).apply() }

    var lastUploadStatus: String
        get() = prefs.getString("last_upload_status", "لم يتم إجراء أي عملية رفع بعد") ?: ""
        set(value) { prefs.edit().putString("last_upload_status", value).apply() }

    suspend fun uploadChapter(
        mangaTitle: String,
        chapterTitle: String,
        downloadDir: File,
        coverUrl: String = ""
    ): Result<String> = withContext(Dispatchers.IO) {
        val currentToken = botToken
        val currentChannel = channelId

        if (currentToken.isBlank()) {
            val msg = "خطأ: لم يتم ضبط توكن بوت التليجرام (Bot Token) في الإعدادات."
            lastUploadStatus = msg
            Log.w(TAG, msg)
            return@withContext Result.failure(Exception(msg))
        }

        try {
            val imageFiles = downloadDir.listFiles()?.filter { 
                it.extension.lowercase() in listOf("jpg", "jpeg", "png", "webp") 
            }?.sortedWith(Comparator { f1, f2 ->
                val n1 = Regex("\\d+").find(f1.name)?.value?.toIntOrNull() ?: 0
                val n2 = Regex("\\d+").find(f2.name)?.value?.toIntOrNull() ?: 0
                if (n1 != n2) n1.compareTo(n2) else f1.name.compareTo(f2.name)
            }) ?: emptyList()

            val pagesCount = imageFiles.size
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())

            fun escapeHtml(text: String): String = text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")

            val safeMangaTitle = escapeHtml(mangaTitle)
            val safeChapterTitle = escapeHtml(chapterTitle)

            val captionHtml = """
                <b>📥 تم تحميل فصل جديد في SpeedManga!</b>
                
                <b>📖 المانجا:</b> $safeMangaTitle
                <b>🔖 الفصل:</b> $safeChapterTitle
                <b>📄 عدد الصفحات:</b> $pagesCount
                <b>⏱️ وقت الرفع:</b> $dateStr
                
                #SpeedManga #Manga
            """.trimIndent()

            var uploadSuccess = false
            var resultDetails = ""

            // 1. Try sending as PDF document if enabled and image files exist
            if (uploadAsPdf && imageFiles.isNotEmpty()) {
                val asciiManga = mangaTitle.replace(Regex("[^a-zA-Z0-9]"), "_").take(25).ifEmpty { "Manga" }
                val asciiChapter = chapterTitle.replace(Regex("[^a-zA-Z0-9]"), "_").take(15).ifEmpty { "Chapter" }
                val pdfFileName = "${asciiManga}_Ch_${asciiChapter}.pdf"
                val pdfFile = File(downloadDir.parentFile, pdfFileName)

                try {
                    val pdfDocument = PdfDocument()
                    var addedPages = 0

                    imageFiles.forEach { imgFile ->
                        try {
                            val bitmap = optimizeBitmapForPdf(imgFile, maxWidth = 540)
                            if (bitmap != null) {
                                val bw = bitmap.width
                                val bh = bitmap.height

                                val pageInfo = PdfDocument.PageInfo.Builder(bw, bh, addedPages + 1).create()
                                val page = pdfDocument.startPage(pageInfo)

                                page.canvas.drawBitmap(bitmap, 0f, 0f, null)

                                pdfDocument.finishPage(page)
                                addedPages++
                                bitmap.recycle()
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error adding page ${imgFile.name} to PDF", e)
                        }
                    }

                    if (addedPages > 0) {
                        FileOutputStream(pdfFile).use { out ->
                            pdfDocument.writeTo(out)
                        }
                    }
                    pdfDocument.close()

                    if (pdfFile.exists() && pdfFile.length() > 0) {
                        Log.d(TAG, "PDF created: ${pdfFile.name}, size: ${pdfFile.length() / 1024} KB")

                        var attempt = 0
                        while (attempt < 3 && !uploadSuccess) {
                            attempt++
                            try {
                                val body = MultipartBody.Builder()
                                    .setType(MultipartBody.FORM)
                                    .addFormDataPart("chat_id", currentChannel)
                                    .addFormDataPart("caption", captionHtml)
                                    .addFormDataPart("parse_mode", "HTML")
                                    .addFormDataPart(
                                        "document",
                                        pdfFileName,
                                        RequestBody.create("application/pdf".toMediaTypeOrNull(), pdfFile)
                                    )
                                    .build()

                                val request = Request.Builder()
                                    .url("https://api.telegram.org/bot$currentToken/sendDocument")
                                    .post(body)
                                    .build()

                                client.newCall(request).execute().use { response ->
                                    if (response.isSuccessful) {
                                        uploadSuccess = true
                                        resultDetails = "تم رفع ملف PDF بنجاح إلى القناة ($currentChannel)"
                                    } else {
                                        val errBody = response.body?.string() ?: ""
                                        Log.e(TAG, "Failed sendDocument PDF (attempt $attempt): ${response.code} $errBody")
                                        resultDetails = "فشل الرفع (${response.code}): $errBody"
                                    }
                                }
                            } catch (netEx: Exception) {
                                Log.e(TAG, "Network exception sending PDF (attempt $attempt)", netEx)
                                resultDetails = "خطأ الاتصال: ${netEx.localizedMessage}"
                                kotlinx.coroutines.delay(2000)
                            }
                        }
                    } else {
                        resultDetails = "فشل إنشاء ملف الـ PDF (الملف فارغ)"
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error creating or uploading PDF file", e)
                    resultDetails = "خطأ إنشاء الـ PDF: ${e.localizedMessage}"
                } finally {
                    if (pdfFile.exists()) {
                        pdfFile.delete()
                    }
                }
            }

            // 2. Try sending as CBZ document if PDF was not uploaded/enabled
            if (!uploadSuccess && uploadAsCbz && imageFiles.isNotEmpty()) {
                val asciiManga = mangaTitle.replace(Regex("[^a-zA-Z0-9]"), "_").take(25).ifEmpty { "Manga" }
                val asciiChapter = chapterTitle.replace(Regex("[^a-zA-Z0-9]"), "_").take(15).ifEmpty { "Chapter" }
                val cbzFileName = "${asciiManga}_Ch_${asciiChapter}.cbz"
                val cbzFile = File(downloadDir.parentFile, cbzFileName)

                try {
                    ZipOutputStream(FileOutputStream(cbzFile)).use { zipOut ->
                        imageFiles.forEach { imgFile ->
                            zipOut.putNextEntry(ZipEntry(imgFile.name))
                            imgFile.inputStream().use { input -> input.copyTo(zipOut) }
                            zipOut.closeEntry()
                        }
                    }

                    if (cbzFile.exists() && cbzFile.length() > 0) {
                        val body = MultipartBody.Builder()
                            .setType(MultipartBody.FORM)
                            .addFormDataPart("chat_id", currentChannel)
                            .addFormDataPart("caption", captionHtml)
                            .addFormDataPart("parse_mode", "HTML")
                            .addFormDataPart(
                                "document",
                                cbzFileName,
                                RequestBody.create("application/x-cbz".toMediaTypeOrNull(), cbzFile)
                            )
                            .build()

                        val request = Request.Builder()
                            .url("https://api.telegram.org/bot$currentToken/sendDocument")
                            .post(body)
                            .build()

                        client.newCall(request).execute().use { response ->
                            if (response.isSuccessful) {
                                uploadSuccess = true
                                resultDetails = "تم رفع ملف CBZ بنجاح إلى القناة ($currentChannel)"
                            } else {
                                Log.e(TAG, "Failed sendDocument: ${response.code} ${response.body?.string()}")
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error creating or uploading CBZ file", e)
                } finally {
                    if (cbzFile.exists()) {
                        cbzFile.delete()
                    }
                }
            }

            // 3. Fallback: ONLY if neither PDF nor CBZ option was enabled and cover photo is explicitly enabled
            if (!uploadSuccess && !uploadAsPdf && !uploadAsCbz && uploadCoverPhoto && imageFiles.isNotEmpty()) {
                val firstPage = imageFiles.first()
                val body = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("chat_id", currentChannel)
                    .addFormDataPart("caption", captionHtml)
                    .addFormDataPart("parse_mode", "HTML")
                    .addFormDataPart(
                        "photo",
                        "cover.jpg",
                        RequestBody.create("image/jpeg".toMediaTypeOrNull(), firstPage)
                    )
                    .build()

                val request = Request.Builder()
                    .url("https://api.telegram.org/bot$currentToken/sendPhoto")
                    .post(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        uploadSuccess = true
                        resultDetails = "تم رفع صورة الغلاف مع تفاصيل الفصل إلى القناة ($currentChannel)"
                    } else {
                        Log.e(TAG, "Failed sendPhoto: ${response.code} ${response.body?.string()}")
                    }
                }
            }

            // 4. Fallback: ONLY if user explicitly disabled all file upload modes (PDF, CBZ, and Cover Photo)
            if (!uploadSuccess && !uploadAsPdf && !uploadAsCbz && !uploadCoverPhoto) {
                val body = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("chat_id", currentChannel)
                    .addFormDataPart("text", captionHtml)
                    .addFormDataPart("parse_mode", "HTML")
                    .build()

                val request = Request.Builder()
                    .url("https://api.telegram.org/bot$currentToken/sendMessage")
                    .post(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        uploadSuccess = true
                        resultDetails = "تم إرسال إشعار النص إلى القناة ($currentChannel)"
                    } else {
                        val err = response.body?.string() ?: ""
                        resultDetails = "فشل الإرسال: $err"
                        Log.e(TAG, "Failed sendMessage: ${response.code} $err")
                    }
                }
            }

            if (uploadSuccess) {
                lastUploadStatus = "✅ $resultDetails ($dateStr)"
                Log.d(TAG, "Telegram upload success: $resultDetails")
                Result.success(resultDetails)
            } else {
                val errorMsg = "فشل رفع الفصل إلى التليجرام: $resultDetails"
                lastUploadStatus = "❌ $errorMsg ($dateStr)"
                Result.failure(Exception(errorMsg))
            }
        } catch (e: Exception) {
            val errorMsg = "خطأ في الاتصال بالتليجرام: ${e.localizedMessage}"
            lastUploadStatus = "❌ $errorMsg"
            Log.e(TAG, "Telegram upload error", e)
            Result.failure(e)
        }
    }

    suspend fun testConnection(token: String, channel: String): Result<String> = withContext(Dispatchers.IO) {
        if (token.isBlank()) {
            return@withContext Result.failure(Exception("يرجى إدخال توكن البوت (Bot Token)"))
        }

        try {
            val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            val testMsg = """
                <b>🔔 إشعار اختبار اتصال SpeedManga</b>
                
                تم اختبار الاتصال بالقناة بنجاح!
                <b>القناة:</b> $channel
                <b>التاريخ:</b> $dateStr
            """.trimIndent()

            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", channel)
                .addFormDataPart("text", testMsg)
                .addFormDataPart("parse_mode", "HTML")
                .build()

            val request = Request.Builder()
                .url("https://api.telegram.org/bot$token/sendMessage")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success("تم إرسال رسالة الاختبار بنجاح إلى القناة $channel")
                } else {
                    val err = response.body?.string() ?: ""
                    Result.failure(Exception("خطأ من تليجرام (${response.code}): $err"))
                }
            }
        } catch (e: Exception) {
            Result.failure(Exception("فشل الاتصال: ${e.localizedMessage}"))
        }
    }

    private fun optimizeBitmapForPdf(imgFile: File, maxWidth: Int = 540): Bitmap? {
        return try {
            val boundsOptions = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(imgFile.absolutePath, boundsOptions)
            val origW = boundsOptions.outWidth
            val origH = boundsOptions.outHeight
            if (origW <= 0 || origH <= 0) return null

            var sampleSize = 1
            while (origW / (sampleSize * 2) >= maxWidth) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }

            val decoded = BitmapFactory.decodeFile(imgFile.absolutePath, decodeOptions) ?: return null

            if (decoded.width > maxWidth) {
                val scale = maxWidth.toFloat() / decoded.width.toFloat()
                val finalW = maxWidth
                val finalH = (decoded.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(decoded, finalW, finalH, true)
                if (scaled != decoded) {
                    decoded.recycle()
                }
                scaled
            } else {
                decoded
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to optimize bitmap for PDF", e)
            null
        }
    }
}
