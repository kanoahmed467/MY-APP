package com.example.utils

import android.os.Build
import okhttp3.OkHttpClient
import java.security.KeyStore
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

object TlsCompat {
    fun enableTls12And13(builder: OkHttpClient.Builder): OkHttpClient.Builder {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ has TLS 1.3 enabled by default and works perfectly.
            return builder
        }

        try {
            val trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
            trustManagerFactory.init(null as KeyStore?)
            val trustManagers = trustManagerFactory.trustManagers
            if (trustManagers.isEmpty() || trustManagers[0] !is X509TrustManager) {
                return builder
            }
            val trustManager = trustManagers[0] as X509TrustManager

            // Initialize SSLContext with TLSv1.3 or fall back to TLSv1.2
            val sslContext = try {
                SSLContext.getInstance("TLSv1.3").apply {
                    init(null, arrayOf(trustManager), null)
                }
            } catch (_: Exception) {
                try {
                    SSLContext.getInstance("TLSv1.2").apply {
                        init(null, arrayOf(trustManager), null)
                    }
                } catch (e: Exception) {
                    android.util.Log.e("TlsCompat", "Failed to create SSLContext", e)
                    return builder
                }
            }

            val socketFactory = sslContext.socketFactory
            val compatSocketFactory = object : SSLSocketFactory() {
                private fun enableTlsOnSocket(socket: java.net.Socket?): java.net.Socket? {
                    if (socket != null && socket is SSLSocket) {
                        try {
                            val supportedProtocols = socket.supportedProtocols
                            val enabled = mutableListOf<String>()
                            if (supportedProtocols.contains("TLSv1.3")) enabled.add("TLSv1.3")
                            if (supportedProtocols.contains("TLSv1.2")) enabled.add("TLSv1.2")
                            
                            if (enabled.isNotEmpty()) {
                                socket.enabledProtocols = enabled.toTypedArray()
                            } else {
                                socket.enabledProtocols = arrayOf("TLSv1.2")
                            }
                        } catch (_: Exception) {
                            try {
                                socket.enabledProtocols = arrayOf("TLSv1.2")
                            } catch (_: Exception) {}
                        }
                    }
                    return socket
                }

                override fun getDefaultCipherSuites(): Array<String> = socketFactory.defaultCipherSuites
                override fun getSupportedCipherSuites(): Array<String> = socketFactory.supportedCipherSuites

                override fun createSocket(s: java.net.Socket?, host: String?, port: Int, autoClose: Boolean): java.net.Socket? {
                    return enableTlsOnSocket(socketFactory.createSocket(s, host, port, autoClose))
                }

                override fun createSocket(host: String?, port: Int): java.net.Socket? {
                    return enableTlsOnSocket(socketFactory.createSocket(host, port))
                }

                override fun createSocket(host: String?, port: Int, localHost: java.net.InetAddress?, localPort: Int): java.net.Socket? {
                    return enableTlsOnSocket(socketFactory.createSocket(host, port, localHost, localPort))
                }

                override fun createSocket(address: java.net.InetAddress?, port: Int): java.net.Socket? {
                    return enableTlsOnSocket(socketFactory.createSocket(address, port))
                }

                override fun createSocket(address: java.net.InetAddress?, port: Int, localAddress: java.net.InetAddress?, localPort: Int): java.net.Socket? {
                    return enableTlsOnSocket(socketFactory.createSocket(address, port, localAddress, localPort))
                }
            }

            builder.sslSocketFactory(compatSocketFactory, trustManager)
            
            // Customize ConnectionSpecs to strictly enforce TLS 1.3 and 1.2
            val spec = okhttp3.ConnectionSpec.Builder(okhttp3.ConnectionSpec.MODERN_TLS)
                .tlsVersions(okhttp3.TlsVersion.TLS_1_3, okhttp3.TlsVersion.TLS_1_2)
                .build()
            
            builder.connectionSpecs(listOf(spec, okhttp3.ConnectionSpec.CLEARTEXT))
        } catch (e: Exception) {
            android.util.Log.e("TlsCompat", "Error enabling TLS 1.2/1.3 compatibility", e)
        }
        return builder
    }
}
