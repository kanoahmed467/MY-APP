package com.example

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import coil.ImageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.runBlocking
import androidx.test.core.app.ApplicationProvider
import android.content.Context
import org.junit.Assert.assertNotNull

@RunWith(RobolectricTestRunner::class)
class TestImageCoil {
    @Test
    fun testDownload() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val url = "https://s7solo.mangalik.net/manga/arb4/data/manga_6602ddbe6f4ca/7199c488ac2b4330a01bb654da2c9a43/1.jpg"
        
        val imageLoader = ImageLoader.Builder(context)
            .okHttpClient {
                okhttp3.OkHttpClient.Builder()
                    .addInterceptor { chain ->
                        val origReq = chain.request()
                        val reqBuilder = origReq.newBuilder()
                            .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                            .header("Referer", "https://mangalik.net/")
                        chain.proceed(reqBuilder.build())
                    }
                    .build()
            }
            .build()
            
        val req = ImageRequest.Builder(context)
            .data(url)
            .build()
            
        val result = imageLoader.execute(req)
        println("Result: ${result.javaClass.simpleName}")
        if (result is coil.request.ErrorResult) {
            println("Error: ${result.throwable.message}")
            result.throwable.printStackTrace()
        }
        assertNotNull(result.drawable)
    }
}
