package com.example

import kotlinx.coroutines.runBlocking
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import com.example.data.network.MadaraScraper

@RunWith(RobolectricTestRunner::class)
class TestScraper {
    @Test
    fun testScrape() = runBlocking {
        val results = MadaraScraper.searchMangas("Become The Adopted Daughter")
        if (results.isNotEmpty()) {
            val manga = results.first()
            println("Found: ${manga.title} - ${manga.siteUrl}")
            val details = MadaraScraper.fetchMangaDetails(manga.siteUrl)
            val chapters = details?.second
            if (!chapters.isNullOrEmpty()) {
                val firstChapter = chapters.last()
                println("Chapter: ${firstChapter.title} - ${firstChapter.url}")
                val images = MadaraScraper.fetchChapterImages(firstChapter.url)
                println("Images: \n" + images.joinToString("\n"))
            } else {
                println("No chapters found.")
            }
        } else {
            println("No results found.")
        }
    }
}
