import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

fun main() {
    val url = "https://s7solo.mangalik.net/manga/arb4/data/manga_6602ddbe6f4ca/7199c488ac2b4330a01bb654da2c9a43/1.jpg"
    val client = OkHttpClient.Builder().build()
    
    val req = Request.Builder()
        .url(url)
        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        .header("Referer", "https://mangalik.net/")
        .build()
        
    val response = client.newCall(req).execute()
    println("Response code: ${response.code}")
    if (response.isSuccessful) {
        println("Success: ${response.body?.contentLength()} bytes")
    } else {
        println("Error: ${response.body?.string()}")
    }
}
