import kotlinx.coroutines.runBlocking
import com.example.data.network.MadaraScraper

fun main() = runBlocking {
    val results = MadaraScraper.searchMangas("Become The Adopted Daughter")
    if (results.isNotEmpty()) {
        val manga = results.first()
        println("Found: ${manga.title} - ${manga.url}")
        val details = MadaraScraper.fetchMangaDetails(manga.url)
        val chapters = details?.second
        if (!chapters.isNullOrEmpty()) {
            val firstChapter = chapters.last() // usually chapter 1
            println("Chapter: ${firstChapter.title} - ${firstChapter.url}")
            val images = MadaraScraper.fetchChapterImages(firstChapter.url)
            println("Images: $images")
        }
    }
}
