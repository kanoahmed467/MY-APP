import re
import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    code = f.read()

# We need to find all `AsyncImage(` and their `modifier = Modifier...` arguments, and inject `.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))`
# Since modifiers are usually chained like `Modifier.fillMaxSize()`, we can replace `modifier = Modifier` with `modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))` but ONLY for `AsyncImage` calls.
# Let's do it manually since there are only a few.

def inject_background(text):
    start = 0
    while True:
        idx = text.find("AsyncImage(", start)
        if idx == -1:
            break
            
        mod_idx = text.find("modifier = Modifier", idx)
        if mod_idx == -1 or mod_idx > text.find(")", idx):
            # No modifier found in this AsyncImage, or it's past the end (unlikely but safe check)
            start = idx + 10
            continue
            
        # Insert background right after Modifier
        insert_str = ".background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))"
        text = text[:mod_idx + 19] + insert_str + text[mod_idx + 19:]
        start = mod_idx + len(insert_str) + 10
    return text

code = inject_background(code)

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(code)

