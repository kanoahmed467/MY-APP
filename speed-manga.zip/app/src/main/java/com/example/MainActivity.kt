package com.example

import android.os.Bundle
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.models.LibraryCategory
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import com.example.ui.components.AppNavigationDrawerContent
import com.example.ui.components.CloudflareBypassDialog
import com.example.ui.components.SpeedMangaBottomNav
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DownloadedMangaScreen
import com.example.ui.screens.DownloadQueueScreen
import com.example.ui.screens.ExploreScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LibraryScreen
import com.example.ui.screens.MangaDetailsScreen
import com.example.ui.screens.MangaReaderScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SpeedMangaTheme
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MangaViewModel
import kotlinx.coroutines.launch

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.FirebaseEmailLinkAuthManager
import androidx.lifecycle.lifecycleScope

class MainActivity : ComponentActivity() {
    private val viewModel: MangaViewModel by viewModels()
    private val incomingLinkState = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        incomingLinkState.value = intent.dataString
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incomingLinkState.value = intent?.dataString
        enableEdgeToEdge()

        try {
            val defaultUa = android.webkit.WebSettings.getDefaultUserAgent(this)
            if (!defaultUa.isNullOrBlank()) {
                com.example.data.network.MadaraScraper.userAgent = defaultUa
            }
            com.example.data.network.MadaraScraper.appContext = applicationContext
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Failed to retrieve default user agent", e)
        }

        // Force maximum display refresh rate (90Hz / 120Hz / 144Hz) for ultra-smooth Compose scrolling
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.post {
                val display = window.decorView.display
                val maxMode = display?.supportedModes?.maxByOrNull { it.refreshRate }
                maxMode?.let { mode ->
                    val params = window.attributes
                    params.preferredDisplayModeId = mode.modeId
                    window.attributes = params
                }
            }
        }

        // Check low-RAM device status to optimize memory allocation
        val activityManager = getSystemService(android.content.Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        val isLowRamDevice = activityManager?.isLowRamDevice == true
        // Keep memory cache small to prevent GC thrashing and lag over time
        val memoryCachePercent = if (isLowRamDevice) 0.15 else 0.35

        // Configure custom high-performance Coil ImageLoader with 50MB Disk Cache
        val imageLoader = coil.ImageLoader.Builder(this)
            .okHttpClient(SpeedMangaApp.sharedOkHttpClient)
            .diskCachePolicy(coil.request.CachePolicy.ENABLED)
            .memoryCachePolicy(coil.request.CachePolicy.ENABLED)
            .crossfade(false)
            .build()
        coil.Coil.setImageLoader(imageLoader)

        // Automatically clean oversized cache asynchronously after main UI paint
        window.decorView.post {
            lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                com.example.utils.CacheManager.autoTrimIfNeeded(applicationContext, 1024)
            }
        }

        setContent {
            val readerSettings by viewModel.readerSettings.collectAsStateWithLifecycle()
            SpeedMangaTheme(darkTheme = readerSettings.isDarkMode) {
                @OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
                androidx.compose.runtime.CompositionLocalProvider(
                    androidx.compose.foundation.LocalOverscrollConfiguration provides null,
                    androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val permissionLauncher = rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.RequestPermission()
                    ) { }

                    LaunchedEffect(Unit) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                            permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }

                    LaunchedEffect(Unit) {
                        com.example.data.network.MadaraScraper.weakConnectionEvent.collect {
                            android.widget.Toast.makeText(applicationContext, "ضعف في الاتصال بالإنترنت", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                }

                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()

                val firebaseEmailLinkAuthManager = remember { FirebaseEmailLinkAuthManager(this@MainActivity, viewModel.authManager) }
                val rawLinkState by incomingLinkState.collectAsStateWithLifecycle()

                var pendingEmailLink by remember { mutableStateOf<String?>(null) }
                var showEmailConfirmDialog by remember { mutableStateOf(false) }
                var emailInputForLink by remember { mutableStateOf("") }
                var isAuthenticatingLink by remember { mutableStateOf(false) }

                LaunchedEffect(rawLinkState) {
                    val link = rawLinkState
                    if (!link.isNullOrBlank() && firebaseEmailLinkAuthManager.isSignInWithEmailLink(link)) {
                        pendingEmailLink = link
                        val savedEmail = firebaseEmailLinkAuthManager.getSavedEmailForSignIn()
                        if (!savedEmail.isNullOrBlank()) {
                            isAuthenticatingLink = true
                            val result = firebaseEmailLinkAuthManager.signInWithEmailLink(savedEmail, link)
                            isAuthenticatingLink = false
                            result.onSuccess { user ->
                                android.widget.Toast.makeText(
                                    this@MainActivity,
                                    "تم تسجيل الدخول بنجاح عبر رابط الإيميل! أهلاً بك ${user.name} 🎉",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                                viewModel.selectTab(MainTab.PROFILE)
                            }.onFailure { err ->
                                android.widget.Toast.makeText(
                                    this@MainActivity,
                                    "فشل تسجيل الدخول بالرابط: ${err.message}",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            }
                            pendingEmailLink = null
                        } else {
                            showEmailConfirmDialog = true
                        }
                    }
                }

                if (showEmailConfirmDialog && pendingEmailLink != null) {
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = {
                            showEmailConfirmDialog = false
                            pendingEmailLink = null
                        },
                        title = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                androidx.compose.material3.Icon(
                                    imageVector = Icons.Default.Email,
                                    contentDescription = null,
                                    tint = MangaRedPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تأكيد بريد تسجيل الدخول",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            }
                        },
                        text = {
                            androidx.compose.foundation.layout.Column(
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "تم فتح رابط تسجيل الدخول (Firebase Link). لتأكيد هويتك، يرجى إدخال البريد الإلكتروني الذي طلبت عليه الرابط:",
                                    fontSize = 13.sp,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )

                                androidx.compose.material3.OutlinedTextField(
                                    value = emailInputForLink,
                                    onValueChange = { emailInputForLink = it },
                                    label = { Text("البريد الإلكتروني") },
                                    placeholder = { Text("user@example.com") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = MangaRedPrimary,
                                        unfocusedBorderColor = DarkBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    )
                                )
                            }
                        },
                        confirmButton = {
                            androidx.compose.material3.Button(
                                onClick = {
                                    val cleanEmail = emailInputForLink.trim()
                                    val currentLink = pendingEmailLink ?: return@Button
                                    if (cleanEmail.isEmpty() || !cleanEmail.contains("@")) {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "يرجى إدخال بريد إلكتروني صحيح",
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                        return@Button
                                    }

                                    lifecycleScope.launch {
                                        isAuthenticatingLink = true
                                        val result = firebaseEmailLinkAuthManager.signInWithEmailLink(cleanEmail, currentLink)
                                        isAuthenticatingLink = false
                                        showEmailConfirmDialog = false
                                        pendingEmailLink = null

                                        result.onSuccess { user ->
                                            android.widget.Toast.makeText(
                                                this@MainActivity,
                                                "تم تسجيل الدخول بنجاح! أهلاً بك ${user.name} 🎉",
                                                android.widget.Toast.LENGTH_LONG
                                            ).show()
                                            viewModel.selectTab(MainTab.PROFILE)
                                        }.onFailure { err ->
                                            android.widget.Toast.makeText(
                                                this@MainActivity,
                                                "خطأ أثناء تسجيل الدخول: ${err.message}",
                                                android.widget.Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    }
                                },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                    containerColor = MangaRedPrimary
                                )
                            ) {
                                Text("تأكيد وتسجيل الدخول")
                            }
                        },
                        dismissButton = {
                            androidx.compose.material3.OutlinedButton(onClick = {
                                showEmailConfirmDialog = false
                                pendingEmailLink = null
                            }) {
                                Text("إلغاء", color = TextSecondary)
                            }
                        },
                        containerColor = DarkSurface
                    )
                }

                var isListView by remember { mutableStateOf(false) }
                var showSplash by remember { mutableStateOf(true) }

                LaunchedEffect(Unit) {
                    kotlinx.coroutines.delay(1200)
                    showSplash = false
                    // Silent bypass Cloudflare on startup to get fresh cookies and correct user agent
                    com.example.data.network.CloudflareBypasser.runSilentBypass(applicationContext) { success, cookies, ua ->
                        if (success) {
                            viewModel.setCloudflareVerified(true, cookies = cookies, userAgent = ua)
                        }
                    }
                }

                val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
                val readerSettings by viewModel.readerSettings.collectAsStateWithLifecycle()
                val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
                val selectedManga by viewModel.selectedManga.collectAsStateWithLifecycle()
                val activeChapter by viewModel.activeChapter.collectAsStateWithLifecycle()
                val isWebtoonMode by viewModel.isWebtoonMode.collectAsStateWithLifecycle()
                val selectedGenre by viewModel.selectedGenre.collectAsStateWithLifecycle()
                val selectedLibraryCat by viewModel.selectedLibraryCategory.collectAsStateWithLifecycle()
                val isCloudflareVerified by viewModel.isCloudflareVerified.collectAsStateWithLifecycle()
                val showBypassDialog by viewModel.showBypassDialog.collectAsStateWithLifecycle()
                val isFavorite by viewModel.isCurrentMangaFavorite.collectAsStateWithLifecycle()

                val mangas by viewModel.exploreFilteredMangas.collectAsStateWithLifecycle()
                val latestUpdates by viewModel.homeFilteredMangas.collectAsStateWithLifecycle()
                val rawMangas by viewModel.mangas.collectAsStateWithLifecycle()
                val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
                val isDownloadsPaused by viewModel.isDownloadsPaused.collectAsStateWithLifecycle()
                val currentChapters by viewModel.currentChapters.collectAsStateWithLifecycle()
                val isLoadingHome by viewModel.isLoadingHome.collectAsStateWithLifecycle()
                val isLoadingDetails by viewModel.isLoadingDetails.collectAsStateWithLifecycle()
                val isLoadingReader by viewModel.isLoadingReader.collectAsStateWithLifecycle()
                val isLoadingMore by viewModel.isLoadingMore.collectAsStateWithLifecycle()
                val isLoadingMoreLatest by viewModel.isLoadingMoreLatest.collectAsStateWithLifecycle()

                // Separate Search states collected from ViewModel
                val homeSearchQuery by viewModel.homeSearchQuery.collectAsStateWithLifecycle()
                val homeSearchResults by viewModel.homeSearchResults.collectAsStateWithLifecycle()
                val homeIsSearching by viewModel.homeIsSearching.collectAsStateWithLifecycle()
                val homeIsSearchMode by viewModel.homeIsSearchMode.collectAsStateWithLifecycle()

                val exploreSearchQuery by viewModel.exploreSearchQuery.collectAsStateWithLifecycle()
                val exploreSearchResults by viewModel.exploreSearchResults.collectAsStateWithLifecycle()
                val exploreIsSearching by viewModel.exploreIsSearching.collectAsStateWithLifecycle()
                val exploreIsSearchMode by viewModel.exploreIsSearchMode.collectAsStateWithLifecycle()

                val activeSearchMode = if (currentTab == MainTab.HOME) homeIsSearchMode else if (currentTab == MainTab.EXPLORE) exploreIsSearchMode else false

                val favorites by viewModel.favoritesList.collectAsStateWithLifecycle()
                val history by viewModel.readingHistoryList.collectAsStateWithLifecycle()
                val downloadedChapters by viewModel.downloadedChaptersList.collectAsStateWithLifecycle()
                val downloadProgressMap by viewModel.downloadProgressMap.collectAsStateWithLifecycle()
                val comments by viewModel.comments.collectAsStateWithLifecycle()

                val validMangas = rawMangas.filter {
                    it.title.trim() != "قائمة المانجا" &&
                    it.id.lowercase() != "manga" &&
                    it.siteUrl != "https://mangalik.net/manga/" &&
                    it.siteUrl != "https://mangalik.net/manga"
                }
                val featuredManga = validMangas.firstOrNull { it.isFeatured } ?: validMangas.firstOrNull()

                // Back Navigation Logic
                BackHandler(enabled = drawerState.isOpen || activeSearchMode || activeChapter != null || selectedManga != null || showBypassDialog || currentTab != MainTab.HOME) {
                    when {
                        drawerState.isOpen -> scope.launch { drawerState.close() }
                        activeSearchMode -> {
                            if (currentTab == MainTab.HOME) viewModel.setHomeSearchMode(false)
                            else if (currentTab == MainTab.EXPLORE) viewModel.setExploreSearchMode(false)
                        }
                        activeChapter != null -> viewModel.closeReader()
                        selectedManga != null -> viewModel.closeMangaDetails()
                        showBypassDialog -> viewModel.setShowBypassDialog(false)
                        currentTab != MainTab.HOME -> viewModel.selectTab(MainTab.HOME)
                    }
                }

                // Cloudflare Dialog Popup
                if (showBypassDialog || currentTab == MainTab.CLOUDFLARE_BYPASS) {
                    CloudflareBypassDialog(
                        siteUrl = "https://mangalik.net/",
                        onDismiss = {
                            viewModel.setShowBypassDialog(false)
                            if (currentTab == MainTab.CLOUDFLARE_BYPASS) viewModel.selectTab(MainTab.HOME)
                        },
                        onBypassSuccess = { cookies, ua ->
                            viewModel.setCloudflareVerified(true, cookies = cookies, userAgent = ua)
                            viewModel.setShowBypassDialog(false)
                            if (currentTab == MainTab.CLOUDFLARE_BYPASS) viewModel.selectTab(MainTab.HOME)
                        }
                    )
                }

                // View Router
                val currentScreen = when {
                    activeChapter != null -> "READER"
                    selectedManga != null -> "DETAILS"
                    else -> "MAIN"
                }

                androidx.compose.animation.AnimatedContent(
                    targetState = currentScreen,
                    label = "screen_transition",
                    transitionSpec = {
                        val rankOf = { s: String ->
                            when (s) {
                                "MAIN" -> 0
                                "DETAILS" -> 1
                                "READER" -> 2
                                else -> 0
                            }
                        }
                        val isForward = rankOf(targetState) > rankOf(initialState)
                        if (isForward) {
                            (androidx.compose.animation.slideInHorizontally(
                                initialOffsetX = { fullWidth -> fullWidth },
                                animationSpec = androidx.compose.animation.core.tween(300, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                            ) + androidx.compose.animation.fadeIn(
                                animationSpec = androidx.compose.animation.core.tween(250)
                            )) togetherWith (
                                androidx.compose.animation.slideOutHorizontally(
                                    targetOffsetX = { fullWidth -> -fullWidth / 4 },
                                    animationSpec = androidx.compose.animation.core.tween(300, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                                ) + androidx.compose.animation.fadeOut(
                                    animationSpec = androidx.compose.animation.core.tween(200)
                                )
                            )
                        } else {
                            (androidx.compose.animation.slideInHorizontally(
                                initialOffsetX = { fullWidth -> -fullWidth / 4 },
                                animationSpec = androidx.compose.animation.core.tween(280, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                            ) + androidx.compose.animation.fadeIn(
                                animationSpec = androidx.compose.animation.core.tween(250)
                            )) togetherWith (
                                androidx.compose.animation.slideOutHorizontally(
                                    targetOffsetX = { fullWidth -> fullWidth },
                                    animationSpec = androidx.compose.animation.core.tween(280, easing = androidx.compose.animation.core.FastOutSlowInEasing)
                                ) + androidx.compose.animation.fadeOut(
                                    animationSpec = androidx.compose.animation.core.tween(200)
                                )
                            )
                        }
                    }
                ) { screen ->
                    when (screen) {
                        "READER" -> {
                            val chapter = activeChapter ?: return@AnimatedContent
                            val manga = selectedManga ?: mangas.first()
                            val chaptersList = if (currentChapters.isNotEmpty()) currentChapters else viewModel.repository.getChaptersForManga(manga.id)

                            MangaReaderScreen(
                                mangaTitle = manga.titleArabic,
                                chapter = chapter,
                                allChapters = chaptersList,
                                readerSettings = readerSettings,
                                onUpdateSettings = { viewModel.updateReaderSettings(it) },
                                isLoadingReader = isLoadingReader,
                                onCloseReader = { viewModel.closeReader() },
                                onSelectChapter = { newCh -> viewModel.openChapter(newCh) },
                                onPageChanged = { pageIdx -> viewModel.updatePageIndex(pageIdx) },
                                onOpenCloudflare = { viewModel.setShowBypassDialog(true) },
                                onRetry = { viewModel.openChapter(chapter) }
                            )
                        }
                        
                        "DETAILS" -> {
                            val manga = selectedManga ?: return@AnimatedContent
                            val chaptersList = if (currentChapters.isNotEmpty()) currentChapters else viewModel.repository.getChaptersForManga(manga.id)
                            val isDownloadedView = currentTab == MainTab.DOWNLOADED_MANGA || (selectedLibraryCat == LibraryCategory.DOWNLOADED && currentTab == MainTab.LIBRARY)

                            MangaDetailsScreen(
                                manga = manga,
                                chapters = chaptersList,
                                comments = comments,
                                isFavorite = isFavorite,
                                isLoadingDetails = isLoadingDetails,
                                isDownloadedMode = isDownloadedView,
                                downloadedChapters = downloadedChapters,
                                downloadProgressMap = downloadProgressMap,
                                defaultDownloadQuality = readerSettings.downloadQuality,
                                onBackClick = { viewModel.closeMangaDetails() },
                                onChapterClick = { ch -> viewModel.openChapter(ch) },
                                onDownloadChapter = { ch, quality -> viewModel.downloadChapter(manga, ch, quality) },
                                onDownloadAllChapters = { chaptersToDownload, quality -> viewModel.downloadAllChapters(manga, chaptersToDownload, quality) },
                                onDeleteDownloadedChapter = { mId, chId -> viewModel.deleteDownloadedChapter(mId, chId) },
                                onOpenDownloadedChapter = { downloaded -> viewModel.openDownloadedChapter(downloaded) },
                                onToggleFavorite = { m, cat -> viewModel.toggleFavorite(m, cat) },
                                onPostComment = { user, text -> viewModel.postComment(manga.id, user, text) },
                                onLikeComment = { commentId, likes, isLiked -> viewModel.toggleCommentLike(commentId, likes, isLiked) },
                                onOpenCloudflare = { viewModel.setShowBypassDialog(true) }
                            )
                        }
                        
                        "MAIN" -> {
                            // Remembered stable callbacks to completely avoid recomposition overhead on list scroll!
                            val stableOnGenreSelected = remember { { genre: String -> viewModel.setGenreFilter(genre) } }
                            val stableOnMangaClick = remember { { m: com.example.data.models.MangaItem -> viewModel.openMangaDetails(m) } }
                            val stableOnOpenDrawer = remember { { scope.launch { drawerState.open() }; Unit } }
                            val stableOnToggleViewMode = remember { { isListView = !isListView } }
                            val stableOnOpenSearch = remember { { viewModel.setHomeSearchMode(true) } }
                            val stableOnCloseSearch = remember { { viewModel.setHomeSearchMode(false) } }
                            val stableOnSearchQueryChange = remember { { q: String -> viewModel.setHomeSearchQuery(q) } }
                            val stableOnLoadNextPage = remember { { viewModel.loadNextLatestUpdatesPage() } }
                            val stableOnRefresh = remember { { viewModel.loadLiveCatalog() } }

                            val stableOnQueryChangeExplore = remember { { q: String -> viewModel.setExploreSearchQuery(q) } }
                            val stableOnGenreSelectExplore = remember { { g: String -> viewModel.setGenreFilter(g) } }
                            val stableOnLoadNextPageExplore = remember { { viewModel.loadNextPage() } }
                            val stableOnOpenSearchExplore = remember { { viewModel.setExploreSearchMode(true) } }
                            val stableOnCloseSearchExplore = remember { { viewModel.setExploreSearchMode(false) } }
                            val stableOnRefreshExplore = remember { { viewModel.loadLiveCatalog() } }

                            val stableOnBackClickHome = remember { { viewModel.selectTab(MainTab.HOME) } }
                            val stableOnCategoryChangeLibrary = remember { { cat: LibraryCategory -> viewModel.setLibraryCategory(cat) } }
                            val stableOnRemoveFavoriteLibrary = remember {
                                { id: String ->
                                    viewModel.removeFromFavorites(id)
                                }
                            }
                            val stableOnOpenDownloadedChapterLibrary = remember { { downloaded: com.example.data.local.DownloadedChapterEntity -> viewModel.openDownloadedChapter(downloaded) } }
                            val stableOnDeleteDownloadedChapterLibrary = remember { { mId: String, chId: String -> viewModel.deleteDownloadedChapter(mId, chId) } }

                            val stableOnToggleViewModeDownload = remember { { isListView = !isListView } }
                            val stableOnOpenSearchDownload = remember {
                                {
                                    viewModel.selectTab(MainTab.EXPLORE)
                                    viewModel.setExploreSearchMode(true)
                                }
                            }

                            val stableOnTogglePauseQueue = remember { { viewModel.togglePauseDownloads() } }
                            val stableOnCancelDownloadQueue = remember { { mId: String, chId: String -> viewModel.cancelDownload(mId, chId) } }
                            val stableOnBackClickQueue = remember { { viewModel.selectTab(MainTab.HOME) } }
                            val stableOnClearQueueQueue = remember { { viewModel.clearDownloadQueue() } }

                            val stableOnSelectTabDrawer = remember {
                                { tab: MainTab ->
                                    viewModel.selectTab(tab)
                                    viewModel.setHomeSearchMode(false)
                                    viewModel.setExploreSearchMode(false)
                                }
                            }
                            val stableOnSelectLibraryCategoryDrawer = remember { { cat: LibraryCategory -> viewModel.setLibraryCategory(cat) } }
                            val stableOnCloseDrawerDrawer = remember { { scope.launch { drawerState.close() }; Unit } }

                            val stableOnSelectGenreDrawer = remember { { genre: String -> viewModel.setGenreFilter(genre) } }

                            ModalNavigationDrawer(
                                drawerState = drawerState,
                                drawerContent = {
                                    AppNavigationDrawerContent(
                                        currentTab = currentTab,
                                        currentUser = currentUser,
                                        onSelectTab = stableOnSelectTabDrawer,
                                        onSelectLibraryCategory = stableOnSelectLibraryCategoryDrawer,
                                        onSelectGenre = stableOnSelectGenreDrawer,
                                        onCloseDrawer = stableOnCloseDrawerDrawer
                                    )
                                }
                            ) {
                            Scaffold(
                                modifier = Modifier.fillMaxSize(),
                                contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0)
                            ) { innerPadding ->
                                Box(modifier = Modifier.padding(innerPadding)) {
                                    androidx.compose.animation.AnimatedContent(
                                        targetState = currentTab,
                                        label = "tab_anim",
                                        transitionSpec = {
                                            (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(300)) + 
                                            androidx.compose.animation.scaleIn(initialScale = 0.98f, animationSpec = androidx.compose.animation.core.tween(300))) togetherWith 
                                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(300))
                                        }
                                    ) { targetTab ->
                                        when (targetTab) {
                                            MainTab.HOME -> HomeScreen(
                                            latestUpdates = latestUpdates,
                                            searchResults = homeSearchResults,
                                            selectedGenre = selectedGenre,
                                            isOnline = isOnline,
                                            isLoadingHome = isLoadingHome,
                                            isLoadingMore = isLoadingMoreLatest,
                                            isSearching = homeIsSearching,
                                            isListView = isListView,
                                            searchQuery = homeSearchQuery,
                                            isSearchMode = homeIsSearchMode,
                                            onGenreSelected = stableOnGenreSelected,
                                            onMangaClick = stableOnMangaClick,
                                            onOpenDrawer = stableOnOpenDrawer,
                                            onToggleViewMode = stableOnToggleViewMode,
                                            onOpenSearch = stableOnOpenSearch,
                                            onCloseSearch = stableOnCloseSearch,
                                            onSearchQueryChange = stableOnSearchQueryChange,
                                            onLoadNextPage = stableOnLoadNextPage,
                                            onRefresh = stableOnRefresh
                                        )

                                        MainTab.EXPLORE -> ExploreScreen(
                                            mangas = mangas,
                                            searchResults = exploreSearchResults,
                                            searchQuery = exploreSearchQuery,
                                            selectedGenre = selectedGenre,
                                            isOnline = isOnline,
                                            isLoadingHome = isLoadingHome,
                                            isSearching = exploreIsSearching,
                                            isLoadingMore = isLoadingMore,
                                            isListView = isListView,
                                            isSearchMode = exploreIsSearchMode,
                                            onQueryChange = stableOnQueryChangeExplore,
                                            onGenreSelect = stableOnGenreSelectExplore,
                                            onLoadNextPage = stableOnLoadNextPageExplore,
                                            onMangaClick = stableOnMangaClick,
                                            onOpenDrawer = stableOnOpenDrawer,
                                            onToggleViewMode = stableOnToggleViewMode,
                                            onOpenSearch = stableOnOpenSearchExplore,
                                            onCloseSearch = stableOnCloseSearchExplore,
                                            onRefresh = stableOnRefreshExplore
                                        )

                                        MainTab.FAVORITES -> FavoritesScreen(
                                            favorites = favorites,
                                            allMangas = mangas,
                                            onMangaClick = stableOnMangaClick,
                                            onRemoveFavorite = stableOnRemoveFavoriteLibrary,
                                            onBackClick = stableOnBackClickHome
                                        )

                                        MainTab.LIBRARY -> LibraryScreen(
                                            favorites = favorites,
                                            history = history,
                                            downloadedChapters = downloadedChapters,
                                            allMangas = mangas,
                                            selectedCategory = selectedLibraryCat,
                                            onCategoryChange = stableOnCategoryChangeLibrary,
                                            onMangaClick = stableOnMangaClick,
                                            onRemoveFavorite = stableOnRemoveFavoriteLibrary,
                                            onBackClick = stableOnBackClickHome,
                                            onOpenDownloadedChapter = stableOnOpenDownloadedChapterLibrary,
                                            onDeleteDownloadedChapter = stableOnDeleteDownloadedChapterLibrary
                                        )

                                        MainTab.DOWNLOADED_MANGA -> DownloadedMangaScreen(
                                            downloadedChapters = downloadedChapters,
                                            allMangas = mangas,
                                            isListView = isListView,
                                            onToggleViewMode = stableOnToggleViewMode,
                                            onOpenDrawer = stableOnOpenDrawer,
                                            onOpenSearch = stableOnOpenSearchDownload,
                                            onMangaClick = stableOnMangaClick
                                        )

                                        MainTab.DOWNLOAD_QUEUE -> DownloadQueueScreen(
                                            downloadProgressMap = downloadProgressMap,
                                            isPaused = isDownloadsPaused,
                                            onTogglePause = stableOnTogglePauseQueue,
                                            onCancelDownload = stableOnCancelDownloadQueue,
                                            onBackClick = stableOnBackClickQueue,
                                            onClearQueue = stableOnClearQueueQueue
                                        )

                                        MainTab.PROFILE -> SettingsScreen(
                                            readerSettings = readerSettings,
                                            onUpdateSettings = { viewModel.updateReaderSettings(it) },
                                            favoritesCount = favorites.size,
                                            historyCount = history.size,
                                            isCloudflareVerified = isCloudflareVerified,
                                            currentUser = currentUser,
                                            onLogout = { viewModel.authManager.logout() },
                                            onOpenAuth = { viewModel.selectTab(MainTab.AUTH) },
                                            onUpdateName = { newName -> viewModel.authManager.updateName(newName) },
                                            onOpenCloudflare = { viewModel.setShowBypassDialog(true) },
                                            onBackClick = { viewModel.selectTab(MainTab.HOME) }
                                        )

                                        MainTab.AUTH -> AuthScreen(
                                            authManager = viewModel.authManager,
                                            onAuthSuccess = {
                                                viewModel.selectTab(MainTab.PROFILE)
                                            },
                                            onBackClick = {
                                                viewModel.selectTab(MainTab.HOME)
                                            }
                                        )

                                        MainTab.CLOUDFLARE_BYPASS -> {}
                                        }
                                    }
                                }
                            }
                        }
                    } // end of "MAIN" ->
                    } // end of when(screen)

                    // MangaSlayer Opening Splash Screen
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showSplash,
                        exit = androidx.compose.animation.fadeOut(
                            animationSpec = androidx.compose.animation.core.tween(400)
                        )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(com.example.ui.theme.DarkBackground),
                            contentAlignment = androidx.compose.ui.Alignment.Center
                        ) {
                            androidx.compose.foundation.layout.Column(
                                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                            ) {
                                androidx.compose.material3.Text(
                                    text = "MangaSlayer",
                                    color = androidx.compose.ui.graphics.Color.White,
                                    fontSize = 38.sp,
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                )
                                androidx.compose.foundation.layout.Spacer(modifier = Modifier.size(28.dp))
                                androidx.compose.material3.CircularProgressIndicator(
                                    color = com.example.ui.theme.MangaRedPrimary,
                                    strokeWidth = 3.5.dp,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }
                    }
                    } // end of Surface
                } // end of CompositionLocalProvider
            }
        }
    }
}}
