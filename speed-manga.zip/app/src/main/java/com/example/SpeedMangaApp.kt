package com.example

import android.app.Application
import android.content.Context
import android.os.Build
import androidx.multidex.MultiDex
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import com.example.data.network.FastDns
import com.example.data.network.MadaraScraper
import com.example.utils.TlsCompat
import com.example.utils.UserAgentGenerator
import okhttp3.Cache
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

class SpeedMangaApp : Application(), ImageLoaderFactory {

    companion object {
        lateinit var instance: SpeedMangaApp
            private set

        val sharedOkHttpClient: OkHttpClient by lazy {
            val context = instance
            val httpCacheDir = File(context.cacheDir, "http_cache")
            val cache = Cache(httpCacheDir, 50L * 1024 * 1024) // 50MB Disk Cache

            val retryInterceptor = okhttp3.Interceptor { chain ->
                val request = chain.request()
                var response: okhttp3.Response? = null
                var tryCount = 0
                val maxRetries = 2
                var exception: java.io.IOException? = null

                while (tryCount <= maxRetries && response == null) {
                    try {
                        response = chain.proceed(request)
                    } catch (e: java.io.IOException) {
                        exception = e
                        if (tryCount == maxRetries) {
                            try {
                                val cacheReq = request.newBuilder()
                                    .cacheControl(okhttp3.CacheControl.FORCE_CACHE)
                                    .build()
                                return@Interceptor chain.proceed(cacheReq)
                            } catch (_: Exception) {
                                throw e
                            }
                        }
                        try { Thread.sleep(800L * (tryCount + 1)) } catch (_: Exception) {}
                    }
                    tryCount++
                }
                response ?: throw exception ?: java.io.IOException("Network error")
            }

            val headersInterceptor = okhttp3.Interceptor { chain ->
                val origReq = chain.request()
                val origUrl = origReq.url.toString()
                val reqHost = try { origReq.url.host } catch (_: Exception) { "" }
                val isMangalik = reqHost.contains("mangalik.net", ignoreCase = true)
                val cookies = MadaraScraper.cloudflareCookies
                val randomUa = UserAgentGenerator.getRandomUserAgent()
                val uaToUse = if (isMangalik && cookies.isNotBlank()) {
                    MadaraScraper.userAgent
                } else {
                    MadaraScraper.userAgent.ifBlank { randomUa }
                }

                val reqBuilder = origReq.newBuilder()
                    .header("User-Agent", uaToUse)
                    .header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                    .header("Accept-Language", "ar,en-US;q=0.9,en;q=0.8")

                if (origReq.header("Referer").isNullOrBlank()) {
                    val refererToUse = when {
                        isMangalik -> "https://mangalik.net/"
                        reqHost.contains("wp.com", ignoreCase = true) || reqHost.contains("blogspot", ignoreCase = true) -> "https://mangalik.net/"
                        reqHost.isNotBlank() -> "https://$reqHost/"
                        else -> "https://mangalik.net/"
                    }
                    reqBuilder.header("Referer", refererToUse)
                }

                if (isMangalik && cookies.isNotBlank() && origReq.header("Cookie").isNullOrBlank()) {
                    reqBuilder.header("Cookie", cookies)
                }

                val req = reqBuilder.build()
                var primaryResponse: okhttp3.Response? = null
                var primaryException: java.io.IOException? = null

                try {
                    primaryResponse = chain.proceed(req)
                    if (primaryResponse.isSuccessful) return@Interceptor primaryResponse
                } catch (e: java.io.IOException) {
                    primaryException = e
                }

                // Self-healing: if we got a 403 or 429 on mangalik domain, trigger silent Cloudflare bypass and retry
                if (primaryResponse != null && (primaryResponse.code == 403 || primaryResponse.code == 429) && isMangalik) {
                    primaryResponse.close()
                    val bypassed = kotlinx.coroutines.runBlocking {
                        com.example.data.network.CloudflareBypasser.runSilentBypassSuspend(context, origUrl)
                    }
                    if (bypassed) {
                        val retryReq = reqBuilder
                            .header("Cookie", MadaraScraper.cloudflareCookies)
                            .header("User-Agent", MadaraScraper.userAgent)
                            .build()
                        try {
                            val retryResponse = chain.proceed(retryReq)
                            if (retryResponse.isSuccessful) return@Interceptor retryResponse
                            retryResponse.close()
                        } catch (_: Exception) {}
                    }
                } else {
                    primaryResponse?.close()
                }

                // Fallback Retry: Clean headers and strip custom cookies for CDN compatibility
                try {
                    val fallbackReq = origReq.newBuilder()
                        .header("User-Agent", randomUa)
                        .header("Referer", "https://mangalik.net/")
                        .header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                        .removeHeader("Cookie")
                        .build()
                    val fallbackResponse = chain.proceed(fallbackReq)
                    if (fallbackResponse.isSuccessful) return@Interceptor fallbackResponse
                    fallbackResponse.close()
                } catch (_: Exception) {}

                // Fallback to cache if network fails
                try {
                    val cacheReq = req.newBuilder()
                        .cacheControl(okhttp3.CacheControl.FORCE_CACHE)
                        .build()
                    val cacheResponse = chain.proceed(cacheReq)
                    if (cacheResponse.isSuccessful) return@Interceptor cacheResponse
                    cacheResponse.close()
                } catch (_: Exception) {}

                throw (primaryException ?: java.io.IOException("Failed to load image: $origUrl"))
            }

            val baseBuilder = OkHttpClient.Builder()
                .cache(cache)
                .dns(FastDns)
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
                .dispatcher(Dispatcher().apply {
                    maxRequestsPerHost = 6
                    maxRequests = 24
                })
                .addInterceptor(retryInterceptor)
                .addInterceptor(headersInterceptor)

            TlsCompat.enableTls12And13(baseBuilder).build()
        }
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        MadaraScraper.appContext = this
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .okHttpClient(sharedOkHttpClient)
            .diskCachePolicy(CachePolicy.ENABLED)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("http_cache"))
                    .maxSizeBytes(50L * 1024 * 1024) // 50MB Persistent Disk Cache
                    .build()
            }
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)
                    .build()
            }
            .components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(ImageDecoderDecoder.Factory())
                } else {
                    add(GifDecoder.Factory())
                }
            }
            .allowHardware(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            .precision(coil.size.Precision.INEXACT)
            .crossfade(false) // Zero crossfade overhead for instant 60fps scrolling
            .build()
    }
}
