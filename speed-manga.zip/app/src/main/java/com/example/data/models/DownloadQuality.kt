package com.example.data.models

enum class DownloadQuality(
    val titleAr: String,
    val subtitleAr: String,
    val badge: String,
    val estSizeMbPerChapter: String,
    val maxPixelWidth: Int,
    val compressionQuality: Int
) {
    HIGH(
        titleAr = "جودة فائقة الوضوح (الأصلية)",
        subtitleAr = "أعلى دقة للقراءة وللتحميل، بدون أي ضغط للصور (لأصحاب الإنترنت السريع)",
        badge = "أصلية HQ",
        estSizeMbPerChapter = "~ 12 - 18 ميجابايت",
        maxPixelWidth = 1200,
        compressionQuality = 90
    ),
    MEDIUM(
        titleAr = "جودة متوازنة (موصى بها)",
        subtitleAr = "وضوح ممتاز وقراءة سريعة مع توفير 60% من باقة النت والمساحة",
        badge = "توفير 60%",
        estSizeMbPerChapter = "~ 4 - 7 ميجابايت",
        maxPixelWidth = 750,
        compressionQuality = 60
    ),
    LOW(
        titleAr = "جودة فائقة التوفير (اقتصادية)",
        subtitleAr = "قراءة سريعة جداً وتوفير 80% من باقة النت (للأجهزة والمساحات الضعيفة)",
        badge = "اقتصادية LQ",
        estSizeMbPerChapter = "~ 1.5 - 3 ميجابايت",
        maxPixelWidth = 480,
        compressionQuality = 40
    )
}

