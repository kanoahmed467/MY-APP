package com.example.data.models

import androidx.compose.runtime.Immutable

@Immutable
data class MangaItem(
    val id: String,
    val title: String,
    val titleArabic: String,
    val coverUrl: String,
    val bannerUrl: String = coverUrl,
    val rating: Float = 4.8f,
    val totalChapters: Int = 100,
    val status: String = "مستمرة",
    val author: String = "كاتب مانجاليك",
    val summary: String = "قصة مشوقة تحتوي على أحداث حماسية وتطور ملحوظ للشخصية الرئيسية في عالم محفوف بالمخاطر والمغامرات الشيقة.",
    val genres: List<String> = listOf("أكشن", "مغامرة", "خيال"),
    val isFeatured: Boolean = false,
    val views: String = "1.2M",
    val latestChapter: String = "الفصل 120",
    val siteUrl: String = "",
    val isNew: Boolean = false,
    val latestReleaseTime: String = ""
)

@Immutable
data class ChapterItem(
    val id: String,
    val mangaId: String = "",
    val chapterNumber: Float = 1.0f,
    val title: String,
    val releaseDate: String,
    val pages: List<String> = emptyList(),
    val url: String = ""
)

@Immutable
data class UserComment(
    val id: String,
    val mangaId: String,
    val chapterId: String? = null,
    val userName: String,
    val userAvatar: String = "",
    val content: String,
    val timestamp: String,
    val likes: Int = 0,
    val isLikedByMe: Boolean = false
)

enum class LibraryCategory(val displayName: String) {
    ALL("الكل"),
    DOWNLOADED("المحملة (بدون نت)"),
    FAVORITE("المفضلة"),
    READING("أقرأها حالياً"),
    PLAN_TO_READ("أرغب بقراءتها"),
    COMPLETED("تمت قراءتها"),
    HISTORY("سجل القراءة")
}
