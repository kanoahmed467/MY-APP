package com.example.data.network

import android.annotation.SuppressLint
import android.content.Context
import android.net.http.SslError
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

object CloudflareBypasser {
    private const val TAG = "CloudflareBypasser"
    private val _isBypassing = MutableStateFlow(false)
    val isBypassing: StateFlow<Boolean> = _isBypassing.asStateFlow()

    @SuppressLint("SetJavaScriptEnabled")
    fun runSilentBypass(context: Context, targetUrl: String = "https://mangalik.net/", onFinished: (Boolean, String, String) -> Unit = { _, _, _ -> }) {
        if (_isBypassing.value) {
            Log.d(TAG, "Silent bypass already running...")
            onFinished(false, "", "")
            return
        }
        _isBypassing.value = true
        Log.d(TAG, "Starting silent Cloudflare bypass via background WebView...")

        Handler(Looper.getMainLooper()).post {
            try {
                val webView = WebView(context.applicationContext)
                webView.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                val sysUa = try {
                    WebSettings.getDefaultUserAgent(context)
                } catch (_: Exception) {
                    MadaraScraper.userAgent
                }
                if (!sysUa.isNullOrBlank()) {
                    MadaraScraper.userAgent = sysUa
                }

                webView.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mediaPlaybackRequiresUserGesture = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    userAgentString = if (sysUa.isNotBlank()) sysUa else MadaraScraper.userAgent
                }

                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

                fun destroyWebViewSafely(wv: WebView?) {
                    try {
                        wv?.stopLoading()
                        wv?.postDelayed({
                            try {
                                wv.destroy()
                            } catch (e: Exception) {
                                Log.w(TAG, "Error destroying webview", e)
                            }
                        }, 500)
                    } catch (_: Exception) {}
                }

                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (!_isBypassing.value) return
                        val cookies = CookieManager.getInstance().getCookie(url) ?: ""
                        try { CookieManager.getInstance().flush() } catch (_: Exception) {}
                        Log.d(TAG, "Page loaded: $url, cookies length: ${cookies.length}")
                        
                        MadaraScraper.cloudflareCookies = cookies
                        val ua = try { view?.settings?.userAgentString ?: MadaraScraper.userAgent } catch (_: Exception) { MadaraScraper.userAgent }
                        if (ua.isNotBlank()) MadaraScraper.userAgent = ua

                        _isBypassing.value = false
                        onFinished(true, cookies, ua)
                        destroyWebViewSafely(view)
                    }

                    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                        Log.w(TAG, "SSL error ignored for legacy Android compatibility: ${error?.primaryError}")
                        handler?.proceed()
                    }

                    override fun onRenderProcessGone(
                        view: WebView?,
                        detail: android.webkit.RenderProcessGoneDetail?
                    ): Boolean {
                        Log.w(TAG, "WebView render process gone/crashed in silent bypass")
                        if (_isBypassing.value) {
                            _isBypassing.value = false
                            onFinished(false, "", "")
                        }
                        destroyWebViewSafely(view)
                        return true
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        errorCode: Int,
                        description: String?,
                        failingUrl: String?
                    ) {
                        super.onReceivedError(view, errorCode, description, failingUrl)
                        Log.w(TAG, "WebView error in silent bypass: $errorCode - $description")
                        if (_isBypassing.value) {
                            _isBypassing.value = false
                            onFinished(false, "", "")
                        }
                        destroyWebViewSafely(view)
                    }
                }
                val baseDomain = try {
                    val uri = java.net.URI(targetUrl)
                    "${uri.scheme}://${uri.host}/"
                } catch (_: Exception) {
                    "https://mangalik.net/"
                }
                Log.d(TAG, "Loading URL for silent bypass: $baseDomain")
                webView.loadUrl(baseDomain)
            } catch (e: Exception) {
                Log.e(TAG, "Error initiating silent bypass WebView", e)
                _isBypassing.value = false
                onFinished(false, "", "")
            }
        }
    }

    private val bypassMutex = kotlinx.coroutines.sync.Mutex()

    suspend fun runSilentBypassSuspend(context: Context, targetUrl: String = "https://mangalik.net/"): Boolean {
        val initialCookies = MadaraScraper.cloudflareCookies
        return bypassMutex.withLock {
            if (MadaraScraper.cloudflareCookies.isNotBlank() && MadaraScraper.cloudflareCookies != initialCookies) {
                Log.d(TAG, "Cookies were already refreshed by another thread. Reusing them.")
                return@withLock true
            }
            _isBypassing.value = false
            kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
                runSilentBypass(context, targetUrl) { success, _, _ ->
                    if (continuation.isActive) {
                        continuation.resume(success)
                    }
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun scrapeChapterWithHeadlessWebView(
        context: Context,
        chapterUrl: String,
        onFinished: (List<String>) -> Unit
    ) {
        if (chapterUrl.isBlank()) {
            onFinished(emptyList())
            return
        }

        Log.d(TAG, "Starting Headless WebView Scraper for chapter URL: $chapterUrl")

        Handler(Looper.getMainLooper()).post {
            try {
                val webView = WebView(context.applicationContext)
                webView.setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)

                val sysUa = try {
                    WebSettings.getDefaultUserAgent(context)
                } catch (_: Exception) {
                    MadaraScraper.userAgent
                }
                if (!sysUa.isNullOrBlank()) {
                    MadaraScraper.userAgent = sysUa
                }

                webView.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    mediaPlaybackRequiresUserGesture = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    userAgentString = if (sysUa.isNotBlank()) sysUa else MadaraScraper.userAgent
                }

                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

                var isFinished = false
                val handler = Handler(Looper.getMainLooper())

                fun cleanup(results: List<String>) {
                    if (isFinished) return
                    isFinished = true
                    Log.d(TAG, "Headless WebView Scraper completed with ${results.size} images for $chapterUrl")
                    try {
                        val cookies = CookieManager.getInstance().getCookie(chapterUrl) ?: ""
                        if (cookies.isNotBlank()) {
                            MadaraScraper.cloudflareCookies = cookies
                        }
                    } catch (_: Exception) {}

                    try {
                        webView.stopLoading()
                        webView.postDelayed({
                            try { webView.destroy() } catch (_: Exception) {}
                        }, 300)
                    } catch (_: Exception) {}

                    onFinished(results)
                }

                val extractionJs = """
                    (function() {
                        try {
                            window.scrollTo(0, document.body.scrollHeight / 2);
                            window.scrollTo(0, document.body.scrollHeight);
                        } catch(e) {}

                        var imgs = Array.from(document.querySelectorAll('div.reading-content img, div.page-break img, div.single-chapter img, img[class*="wp-manga"], div.text-left img, div.entry-content p img, .read-container img, .reader-area img, #readerarea img, .chapter-content img, .reading-content-wrap img, .main-col img, .container img, div.post-content img, .chapter-image img, img'));
                        var urls = [];
                        var blacklist = ['logo','banner','header','footer','sidebar','avatar','favicon','loader','loading','widget','social','discord','telegram','facebook','twitter','instagram','ads','promo','site-logo','nav-','badge','emoji','cursorleft','cursorright','32x32','192x192','180x180','270x270'];
                        
                        function isValid(url) {
                            if (!url || url.indexOf('data:') === 0) return false;
                            var l = url.toLowerCase();
                            for (var i = 0; i < blacklist.length; i++) {
                                if (l.indexOf(blacklist[i]) !== -1) return false;
                            }
                            return true;
                        }

                        imgs.forEach(function(img) {
                            var src = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-cfsrc') || img.getAttribute('data-original') || img.getAttribute('data-full-url') || img.getAttribute('data-url') || img.getAttribute('data-echo') || img.getAttribute('data-image') || img.getAttribute('data-file') || img.src;
                            if (src) {
                                src = src.trim();
                                if (src.indexOf('//') === 0) src = window.location.protocol + src;
                                else if (src.indexOf('/') === 0) src = window.location.origin + src;
                                if (isValid(src)) {
                                    urls.push(src);
                                }
                            }
                        });

                        if (urls.length < 3) {
                            var scripts = Array.from(document.querySelectorAll('script'));
                            scripts.forEach(function(s) {
                                var text = s.innerText || '';
                                var matches = text.match(/https?:\/\/[^\s"'<>\\]+\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?[^\s"'<>\\]*)?/gi);
                                if (matches) {
                                    matches.forEach(function(m) {
                                        var clean = m.replace(/\\/g, '');
                                        if (isValid(clean)) {
                                            urls.push(clean);
                                        }
                                    });
                                }
                            });
                        }
                        var unique = Array.from(new Set(urls));
                        return JSON.stringify(unique);
                    })();
                """.trimIndent()

                var pollCount = 0
                val maxPolls = 8

                fun pollExtraction() {
                    if (isFinished) return
                    pollCount++
                    webView.evaluateJavascript(extractionJs) { resultJson ->
                        if (isFinished) return@evaluateJavascript
                        val extractedList = mutableListOf<String>()
                        if (!resultJson.isNullOrBlank() && resultJson != "null" && resultJson != "[]") {
                            try {
                                var unescaped = resultJson
                                if (unescaped.startsWith("\"") && unescaped.endsWith("\"")) {
                                    unescaped = org.json.JSONTokener(unescaped).nextValue().toString()
                                }
                                val jsonArray = org.json.JSONArray(unescaped)
                                for (i in 0 until jsonArray.length()) {
                                    val item = jsonArray.optString(i)
                                    if (item.isNotBlank() && item.startsWith("http")) {
                                        extractedList.add(MadaraScraper.cleanChapterImageUrl(item))
                                    }
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "Error parsing JS extraction result: $resultJson", e)
                            }
                        }

                        if (extractedList.size >= 3) {
                            cleanup(extractedList)
                        } else if (pollCount >= maxPolls) {
                            cleanup(extractedList)
                        } else {
                            handler.postDelayed({ pollExtraction() }, 1000)
                        }
                    }
                }

                webView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (!isFinished) {
                            handler.postDelayed({ pollExtraction() }, 800)
                        }
                    }

                    override fun onReceivedSslError(view: WebView?, handlerSsl: SslErrorHandler?, error: SslError?) {
                        Log.w(TAG, "SSL error ignored in scraper for legacy Android compatibility: ${error?.primaryError}")
                        handlerSsl?.proceed()
                    }

                    override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                        super.onReceivedError(view, errorCode, description, failingUrl)
                        if (!isFinished && pollCount >= maxPolls) {
                            cleanup(emptyList())
                        }
                    }
                }

                handler.postDelayed({
                    if (!isFinished) {
                        pollExtraction()
                    }
                }, 10000)

                val cleanBaseUrl = if (chapterUrl.contains("?")) chapterUrl.substringBefore("?") else chapterUrl
                val loadTarget = if (cleanBaseUrl.endsWith("/")) "${cleanBaseUrl}?style=list" else "${cleanBaseUrl}/?style=list"
                webView.loadUrl(loadTarget)

            } catch (e: Exception) {
                Log.e(TAG, "Error in scrapeChapterWithHeadlessWebView", e)
                onFinished(emptyList())
            }
        }
    }

    suspend fun scrapeChapterWithHeadlessWebViewSuspend(context: Context, chapterUrl: String): List<String> =
        kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
            scrapeChapterWithHeadlessWebView(context, chapterUrl) { images ->
                if (continuation.isActive) {
                    continuation.resume(images)
                }
            }
        }
}
