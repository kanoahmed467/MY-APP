package com.example.data.network

import android.util.Log
import com.example.data.models.ChapterItem
import com.example.data.models.MangaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

object MadaraScraper {
    private const val TAG = "MadaraScraper"
    private const val DEFAULT_BASE_URL = "https://mangalik.net/"
    private const val DEFAULT_USER_AGENT = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"

    var userAgent: String = DEFAULT_USER_AGENT
    var cloudflareCookies: String = ""
    var appContext: android.content.Context? = null

    // Thread-safe in-memory cache for fast chapter opening
    private val chapterPagesCache = java.util.concurrent.ConcurrentHashMap<String, List<String>>()

    fun cacheChapterPages(urlOrId: String, pages: List<String>) {
        if (urlOrId.isNotBlank() && pages.isNotEmpty()) {
            val key = normalizeCacheKey(urlOrId)
            chapterPagesCache[key] = pages
        }
    }

    fun getCachedChapterPages(urlOrId: String): List<String>? {
        if (urlOrId.isBlank()) return null
        val key = normalizeCacheKey(urlOrId)
        return chapterPagesCache[key]
    }

    private fun normalizeCacheKey(urlOrId: String): String {
        return urlOrId.substringBefore("?").trimEnd('/').lowercase()
    }

    val weakConnectionEvent = kotlinx.coroutines.flow.MutableSharedFlow<Unit>(extraBufferCapacity = 1, onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)

    private val cookieJar = object : okhttp3.CookieJar {
        private val cookieStore = java.util.concurrent.ConcurrentHashMap<String, MutableList<okhttp3.Cookie>>()

        override fun saveFromResponse(url: okhttp3.HttpUrl, cookies: List<okhttp3.Cookie>) {
            val host = url.host
            val existing = cookieStore[host] ?: mutableListOf()
            val newCookies = cookies.filter { new -> existing.none { it.name == new.name } }
            existing.addAll(newCookies)
            cookieStore[host] = existing
        }

        override fun loadForRequest(url: okhttp3.HttpUrl): List<okhttp3.Cookie> {
            return cookieStore[url.host] ?: emptyList()
        }
    }

    val client by lazy {
        val cacheSize = 50L * 1024 * 1024 // 50 MB
        val cache = appContext?.cacheDir?.let { okhttp3.Cache(java.io.File(it, "http_cache"), cacheSize) }

        val pool = okhttp3.ConnectionPool(5, 5, TimeUnit.MINUTES)

        val rateLimitInterceptor = okhttp3.Interceptor { chain ->
            val request = chain.request()
            var response = chain.proceed(request)
            var tryCount = 0
            while ((response.code == 429 || response.code == 403) && tryCount < 3) {
                Log.w(TAG, "Rate limited or forbidden (${response.code}) on ${request.url}. Backing off...")
                response.close()
                tryCount++
                Thread.sleep(1000L * tryCount) // Exponential backoff via sleep in IO thread
                response = chain.proceed(request)
            }
            response
        }

        val networkRetryInterceptor = okhttp3.Interceptor { chain ->
            val request = chain.request()
            var response: okhttp3.Response? = null
            var tryCount = 0
            val maxRetries = 2
            var exception: java.io.IOException? = null

            while (tryCount <= maxRetries && response == null) {
                try {
                    response = chain.proceed(request)
                } catch (e: java.io.IOException) {
                    exception = e
                    if (tryCount == 0) {
                        weakConnectionEvent.tryEmit(Unit)
                    }
                    if (tryCount == maxRetries) {
                        // Network failed completely, fallback to cache
                        try {
                            val cacheReq = request.newBuilder()
                                .cacheControl(okhttp3.CacheControl.FORCE_CACHE)
                                .build()
                            return@Interceptor chain.proceed(cacheReq)
                        } catch (cacheEx: Exception) {
                            throw e
                        }
                    }
                    Thread.sleep(1500L * (tryCount + 1))
                }
                tryCount++
            }
            response ?: throw exception ?: java.io.IOException("Network failure")
        }

        val builder = OkHttpClient.Builder()
            .dns(FastDns)
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .followRedirects(true)
            .followSslRedirects(true)
            .connectionPool(pool)
            .cookieJar(cookieJar)
            .addInterceptor(networkRetryInterceptor)
            .addInterceptor(rateLimitInterceptor)
            .apply {
                if (cache != null) {
                    cache(cache)
                }
            }
        com.example.utils.TlsCompat.enableTls12And13(builder).build()
    }

    private fun buildRequest(url: String): Request {
        val referer = try {
            val host = java.net.URI(url).host
            if (!host.isNullOrBlank()) "https://$host/" else DEFAULT_BASE_URL
        } catch (_: Exception) {
            DEFAULT_BASE_URL
        }

        // Use the bypassed userAgent if cookies are active, otherwise rotate to mimic organic browsers
        val ua = if (cloudflareCookies.isNotBlank()) userAgent else com.example.utils.UserAgentGenerator.getRandomUserAgent()

        // Dynamically align Sec-Ch-Ua headers to match the selected User-Agent (Anti-Fingerprinting)
        val isMobile = ua.contains("Mobile", ignoreCase = true) || ua.contains("Android", ignoreCase = true) || ua.contains("iPhone", ignoreCase = true) || ua.contains("iPad", ignoreCase = true)
        val mobileHint = if (isMobile) "?1" else "?0"
        val platformHint = when {
            ua.contains("Android", ignoreCase = true) -> "\"Android\""
            ua.contains("iPhone", ignoreCase = true) || ua.contains("iPad", ignoreCase = true) -> "\"iOS\""
            ua.contains("Windows", ignoreCase = true) -> "\"Windows\""
            ua.contains("Macintosh", ignoreCase = true) -> "\"macOS\""
            else -> "\"Linux\""
        }

        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", ua)
            .header("Referer", referer)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
            .header("Accept-Language", "ar,en-US;q=0.9,en;q=0.8")
            .header("Sec-Ch-Ua", "\"Not_A Brand\";v=\"8\", \"Chromium\";v=\"120\", \"Google Chrome\";v=\"120\"")
            .header("Sec-Ch-Ua-Mobile", mobileHint)
            .header("Sec-Ch-Ua-Platform", platformHint)
            .header("Sec-Fetch-Dest", "document")
            .header("Sec-Fetch-Mode", "navigate")
            .header("Sec-Fetch-Site", "same-origin")
            .header("Sec-Fetch-User", "?1")
            .header("Upgrade-Insecure-Requests", "1")

        if (cloudflareCookies.isNotBlank()) {
            builder.header("Cookie", cloudflareCookies)
        }

        return builder.build()
    }

    suspend fun fetchHtmlDocument(url: String): Document? = withContext(Dispatchers.IO) {
        for (attempt in 1..2) {
            try {
                // Organic request jitter delay (Anti-Ban)
                val jitter = kotlin.random.Random.nextLong(60, 180)
                kotlinx.coroutines.delay(jitter)

                val request = buildRequest(url)
                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val html = response.body?.string() ?: ""
                        return@withContext Jsoup.parse(html, url)
                    } else if (response.code == 403 || response.code == 429) {
                        Log.w(TAG, "HTTP ${response.code} for $url.")
                        
                        // Smart rate-limiting back-off cooldown delay
                        val coolDown = kotlin.random.Random.nextLong(600, 1500)
                        kotlinx.coroutines.delay(coolDown)

                        val ctx = appContext
                        if (ctx != null && attempt == 1) {
                            Log.w(TAG, "Cloudflare challenge detected on 403/429 for $url. Silently bypassing Cloudflare...")
                            val bypassed = CloudflareBypasser.runSilentBypassSuspend(ctx, url)
                            if (bypassed) {
                                Log.d(TAG, "Cloudflare bypass succeeded. Retrying request with fresh cookies...")
                                continue
                            }
                        }
                        break
                    } else if (response.code in 500..599 && attempt < 2) {
                        Log.w(TAG, "HTTP ${response.code} for $url, retrying attempt $attempt...")
                        val retryBackoff = kotlin.random.Random.nextLong(200, 500)
                        kotlinx.coroutines.delay(retryBackoff)
                    } else {
                        Log.e(TAG, "HTTP error ${response.code} for $url")
                        break
                    }
                }
            } catch (e: Exception) {
                if (attempt < 2) {
                    Log.w(TAG, "Fetch attempt $attempt failed for $url: ${e.message}, retrying...")
                    val retryBackoff = kotlin.random.Random.nextLong(300, 800)
                    kotlinx.coroutines.delay(retryBackoff)
                } else {
                    Log.e(TAG, "Failed to fetch $url after $attempt attempts", e)
                }
            }
        }
        return@withContext null
    }

    /**
     * Parse Manga Details from Madara WordPress HTML
     */
    suspend fun fetchMangaDetails(mangaUrl: String): Triple<MangaItem, List<ChapterItem>, Map<String, Any>>? = withContext(Dispatchers.IO) {
        val cleanBaseUrl = if (mangaUrl.contains("?")) mangaUrl.substringBefore("?") else mangaUrl
        val cleanMangaUrl = cleanBaseUrl.trimEnd('/') + "/"
        val nocacheUrl = "$cleanMangaUrl?nocache=${System.currentTimeMillis()}"

        var doc = fetchHtmlDocument(nocacheUrl) ?: fetchHtmlDocument(cleanMangaUrl) ?: fetchHtmlDocument(mangaUrl) ?: return@withContext null

        try {
            // 1. Title: div.post-title h1 or h1.entry-title or h1
            val titleText = doc.select("div.post-title h1").text().ifBlank {
                doc.select("h1.entry-title").text().ifBlank {
                    doc.select("h1").first()?.text() ?: "مانجا غير معروفة"
                }
            }.cleanText()

            // 2. Cover Image: div.summary_image img -> data-src or src
            val imgElement = doc.select("div.summary_image img").first() ?: doc.select(".tab-summary img").first()
            val rawCoverUrl = imgElement?.let { img ->
                img.attr("data-src").ifBlank {
                    img.attr("data-lazy-src").ifBlank {
                        img.attr("data-cfsrc").ifBlank {
                            val dataSrcset = img.attr("data-srcset")
                            if (dataSrcset.isNotBlank()) {
                                dataSrcset.split(",").firstOrNull()?.trim()?.split(" ")?.firstOrNull() ?: ""
                            } else {
                                val srcset = img.attr("srcset")
                                if (srcset.isNotBlank()) {
                                    srcset.split(",").firstOrNull()?.trim()?.split(" ")?.firstOrNull() ?: ""
                                } else {
                                    img.attr("data-original").ifBlank {
                                        img.attr("src")
                                    }
                                }
                            }
                        }
                    }
                }
            } ?: ""
            val coverUrl = getHighResImageUrl(fixUrl(rawCoverUrl))

            // 3. Story Summary: div.description-summary or .summary__content
            val summaryText = doc.select("div.description-summary").text().ifBlank {
                doc.select("div.summary__content").text().ifBlank {
                    doc.select("div.manga-excerpt").text().ifBlank {
                        "لا يوجد وصف متوفر لهذه المانجا حالياً."
                    }
                }
            }.cleanText()

            // 4. Genres: .genres-content a
            val genresList = doc.select(".genres-content a, .manga-genres a").map { it.text().cleanText() }
                .filter { it.isNotBlank() }
                .ifEmpty { listOf("مانهوا", "أكشن", "خيال") }

            // 5. Rating & Info
            val ratingText = doc.select("span#averager, .post-total-rating .score, .total_votes").text()
            val ratingVal = ratingText.toFloatOrNull() ?: 4.8f

            val statusText = doc.select(".post-status .summary-content, .post-content_item:contains(الحالة) .summary-content").text().cleanText().ifBlank { "مستمرة" }
            val authorText = doc.select(".author-content a, .post-content_item:contains(الكاتب) .summary-content").text().cleanText().ifBlank { "مؤلف مانجا ليك" }

            // 6. Chapters list
            var chapterElements = doc.select("ul.main.version-chap li.wp-manga-chapter, li.wp-manga-chapter, li.chapter-item, ul.row-content li, div.chapter-li, div.wp-manga-chapter, .listing-chapters_wrap li, #manga-chapters-holder li, .sub-chap li")

            // If chapterElements is empty, try Madara AJAX chapters endpoint or admin-ajax.php with post-id
            if (chapterElements.isEmpty()) {
                val ajaxUrl = "${cleanMangaUrl.trimEnd('/')}/ajax/chapters/"
                try {
                    val request = Request.Builder()
                        .url(ajaxUrl)
                        .post(okhttp3.FormBody.Builder().build())
                        .header("User-Agent", userAgent)
                        .header("Referer", cleanMangaUrl)
                        .header("X-Requested-With", "XMLHttpRequest")
                        .apply {
                            if (cloudflareCookies.isNotBlank()) {
                                header("Cookie", cloudflareCookies)
                            }
                        }
                        .build()

                    client.newCall(request).execute().use { response ->
                        if (response.isSuccessful) {
                            val ajaxHtml = response.body?.string() ?: ""
                            if (ajaxHtml.isNotBlank()) {
                                val ajaxDoc = Jsoup.parse(ajaxHtml, cleanMangaUrl)
                                chapterElements = ajaxDoc.select("ul.main.version-chap li.wp-manga-chapter, li.wp-manga-chapter, li.chapter-item, ul.row-content li, div.chapter-li, div.wp-manga-chapter, .listing-chapters_wrap li, #manga-chapters-holder li, li, a")
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed fetching AJAX chapters for $ajaxUrl", e)
                }

                // If still empty, try extracting WordPress post ID for admin-ajax
                if (chapterElements.isEmpty()) {
                    val postId = doc.select("input#wp-manga-post-id, input.rating-post-id").attr("value").ifBlank {
                        doc.select("div#manga-chapters-holder, div.wp-manga-chapter").attr("data-id")
                    }.ifBlank {
                        Regex("""postid-(\d+)""").find(doc.select("body").attr("class"))?.groupValues?.getOrNull(1) ?: ""
                    }

                    if (postId.isNotBlank()) {
                        try {
                            val formBody = okhttp3.FormBody.Builder()
                                .add("action", "manga_get_chapters")
                                .add("manga", postId)
                                .build()
                            val adminAjaxReq = Request.Builder()
                                .url("https://mangalik.net/wp-admin/admin-ajax.php")
                                .post(formBody)
                                .header("User-Agent", userAgent)
                                .header("Referer", cleanMangaUrl)
                                .header("X-Requested-With", "XMLHttpRequest")
                                .apply {
                                    if (cloudflareCookies.isNotBlank()) header("Cookie", cloudflareCookies)
                                }
                                .build()
                            client.newCall(adminAjaxReq).execute().use { resp ->
                                if (resp.isSuccessful) {
                                    val html = resp.body?.string() ?: ""
                                    if (html.isNotBlank()) {
                                        val ajaxDoc = Jsoup.parse(html, cleanMangaUrl)
                                        chapterElements = ajaxDoc.select("ul.main.version-chap li.wp-manga-chapter, li.wp-manga-chapter, li.chapter-item, ul.row-content li, div.chapter-li, div.wp-manga-chapter, .listing-chapters_wrap li, #manga-chapters-holder li, li, a")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Failed fetching admin-ajax chapters for post $postId", e)
                        }
                    }
                }
            }

            val mangaId = extractMangaIdFromUrl(cleanMangaUrl)
            val chapters = mutableListOf<ChapterItem>()

            chapterElements.forEachIndexed { index, el ->
                val anchor = if (el.tagName() == "a") el else el.select("a").first()
                if (anchor != null) {
                    val rawHref = anchor.attr("href").trim()
                    val chUrl = fixUrl(rawHref)

                    val isNotSelfUrl = chUrl.trimEnd('/') != cleanMangaUrl.trimEnd('/')
                    val isValidUrl = chUrl.startsWith("http") &&
                                     !rawHref.startsWith("#") &&
                                     !rawHref.startsWith("javascript:") &&
                                     !chUrl.contains("/genre/") &&
                                     !chUrl.contains("/manga-genre/") &&
                                     !chUrl.contains("/author/") &&
                                     !chUrl.contains("/bookmark") &&
                                     !chUrl.contains("/login") &&
                                     !chUrl.contains("/register")

                    if (isValidUrl && isNotSelfUrl && !chapters.any { it.url == chUrl }) {
                        val chTitle = anchor.text().cleanText().ifBlank { "فصل ${chapters.size + 1}" }
                        val releaseDate = el.select("span.chapter-release-date i, span.chapter-release-date, .c-new-tag a").text().cleanText().ifBlank { "حديثاً" }
                        val chId = extractIdFromUrl(chUrl, chapters.size)
                        val chNum = Regex("""\d+(\.\d+)?""").find(chTitle)?.value?.toFloatOrNull()
                            ?: Regex("""\d+(\.\d+)?""").find(chId)?.value?.toFloatOrNull()
                            ?: (chapters.size + 1).toFloat()

                        chapters.add(
                            ChapterItem(
                                id = chId,
                                mangaId = mangaId,
                                chapterNumber = chNum,
                                title = chTitle,
                                releaseDate = releaseDate,
                                url = chUrl,
                                pages = emptyList()
                            )
                        )
                    }
                }
            }

            val item = MangaItem(
                id = mangaId,
                title = titleText,
                titleArabic = titleText,
                coverUrl = coverUrl,
                bannerUrl = coverUrl,
                rating = ratingVal,
                totalChapters = chapters.size,
                status = statusText,
                author = authorText,
                summary = summaryText,
                genres = genresList,
                isFeatured = false,
                views = "mangalik.net",
                latestChapter = chapters.firstOrNull()?.title ?: "الفصل 1",
                siteUrl = cleanMangaUrl
            )

            return@withContext Triple(item, chapters, mapOf("doc" to doc))
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing manga details for $mangaUrl", e)
            return@withContext null
        }
    }

    private fun extractIdFromUrl(url: String, fallbackIndex: Int = 0): String {
        val clean = url.substringBefore("?").substringBefore("#").trimEnd('/')
        val lastSegment = clean.substringAfterLast('/')
        val secondLastSegment = clean.substringBeforeLast('/').substringAfterLast('/')

        return if (lastSegment.isNotBlank() && !lastSegment.startsWith("http")) {
            if (secondLastSegment.isNotBlank() && !secondLastSegment.startsWith("http")) {
                "$secondLastSegment-$lastSegment"
            } else {
                lastSegment
            }
        } else {
            "chap-$fallbackIndex"
        }
    }

    private fun extractMangaIdFromUrl(url: String): String {
        val clean = url.substringBefore("?").substringBefore("#").trimEnd('/')
        val lastSegment = clean.substringAfterLast('/')
        return if (lastSegment.isNotBlank() && !lastSegment.startsWith("http")) {
            lastSegment
        } else {
            "manga-item"
        }
    }

    /**
     * Parse Chapter Images from Madara WordPress HTML with robust multi-pass extraction
     */
    suspend fun fetchChapterImages(chapterUrl: String): List<String> = withContext(Dispatchers.IO) {
        if (chapterUrl.isBlank()) return@withContext emptyList()
        val cached = getCachedChapterPages(chapterUrl)
        if (!cached.isNullOrEmpty()) {
            Log.d(TAG, "Instant memory cache hit for chapter: $chapterUrl (${cached.size} pages)")
            return@withContext cached
        }

        val fixed = fixUrl(chapterUrl)
        val cleanBaseUrl = fixed.substringBefore("?").trimEnd('/') + "/"
        val withoutTrailingSlash = fixed.substringBefore("?").trimEnd('/')

        val urlVariations = listOf(
            cleanBaseUrl,
            "$cleanBaseUrl?style=list",
            "$withoutTrailingSlash?style=list",
            withoutTrailingSlash,
            "$cleanBaseUrl?style=paged",
            "$cleanBaseUrl?view=all"
        ).distinct()

        var bestImages = emptyList<String>()

        for (url in urlVariations) {
            Log.d(TAG, "Fetching chapter images from URL variation: $url")
            val doc = fetchHtmlDocument(url)
            if (doc != null) {
                val extracted = extractImagesFromDocument(doc)
                if (extracted.size > bestImages.size) {
                    bestImages = extracted
                    Log.d(TAG, "Found ${extracted.size} images from $url")
                    if (bestImages.size >= 2) {
                        cacheChapterPages(chapterUrl, bestImages)
                        return@withContext bestImages
                    }
                }
            }
        }

        if (bestImages.isNotEmpty()) {
            cacheChapterPages(chapterUrl, bestImages)
        }

        return@withContext bestImages
    }

    private fun extractImageUrlFromImgTag(img: org.jsoup.nodes.Element): String {
        val attributes = listOf(
            "data-src", "data-lazy-src", "data-cfsrc", "data-original",
            "data-full-url", "data-url", "data-lazy-url", "data-src-webp",
            "data-cdn-src", "data-lazy", "data-altsrc", "data-actualsrc",
            "data-pic", "data-img", "data-file", "data-echo", "data-image"
        )
        for (attr in attributes) {
            val v = img.attr(attr).trim()
            if (v.isNotBlank() && !v.startsWith("data:", ignoreCase = true)) {
                return v
            }
        }
        val srcset = img.attr("data-srcset").ifBlank { img.attr("srcset") }.trim()
        if (srcset.isNotBlank() && !srcset.startsWith("data:", ignoreCase = true)) {
            val firstCandidate = srcset.split(",").firstOrNull()?.trim()?.split(" ")?.firstOrNull() ?: ""
            if (firstCandidate.isNotBlank() && !firstCandidate.startsWith("data:", ignoreCase = true)) {
                return firstCandidate
            }
        }
        val src = img.attr("src").trim()
        if (src.isNotBlank() && !src.startsWith("data:", ignoreCase = true)) {
            return src
        }
        return ""
    }

    private fun isChapterPageImage(rawUrl: String, imgElement: org.jsoup.nodes.Element? = null): Boolean {
        if (rawUrl.isBlank() || rawUrl.startsWith("data:", ignoreCase = true)) return false
        val lowerUrl = rawUrl.lowercase()

        val blacklist = listOf(
            "logo", "banner", "header", "footer", "sidebar",
            "avatar", "favicon", "loader", "loading", "widget", "social",
            "discord", "telegram", "facebook", "twitter", "instagram", "app-store",
            "google-play", "ads", "advertisement", "promo", "button",
            "site-logo", "branding", "nav-", "badge", "donate", "patreon", "paypal",
            "emoji", "cursorleft", "cursorright", "32x32", "192x192", "180x180", "270x270"
        )

        for (kw in blacklist) {
            if (lowerUrl.contains(kw)) return false
        }

        if (imgElement != null) {
            var current: org.jsoup.nodes.Element? = imgElement
            var depth = 0
            while (current != null && depth < 6) {
                val tagName = current.tagName().lowercase()
                val className = current.className().lowercase()
                val idName = current.id().lowercase()

                if (tagName == "header" || tagName == "nav" || tagName == "footer" || tagName == "aside") {
                    return false
                }
                val parentBlacklist = listOf(
                    "header", "nav", "footer", "sidebar", "logo", "banner", "comments",
                    "widget", "social", "menu", "site-header", "site-logo"
                )
                for (kw in parentBlacklist) {
                    if (className.contains(kw) || idName.contains(kw)) return false
                }

                current = current.parent()
                depth++
            }
        }

        return true
    }

    private fun extractImagesFromDocument(doc: Document): List<String> {
        val domUrls = mutableListOf<String>()
        try {
            // High-speed targeted selector extraction across all Madara and Arabic manga themes
            val imgElements = doc.select(
                "div.reading-content img, div.page-break img, .wp-manga-chapter-img, div.single-chapter img, " +
                ".reader-area img, #readerarea img, .read-container img, .chapter-content img, .reading-content-wrap img, " +
                "div.entry-content img, div.entry-content p img, .entry-content_wrap img, div.text-center img, " +
                "div.text-left img, div[id*='chapter'] img, div[class*='chapter'] img, div[class*='reading'] img, " +
                ".main-col img, div.post-content img, div.site-content img, .chapter-image img"
            )
            
            imgElements.forEach { img ->
                val rawUrl = extractImageUrlFromImgTag(img)
                if (rawUrl.isNotBlank() && isChapterPageImage(rawUrl, img)) {
                    val cleanUrl = cleanChapterImageUrl(rawUrl)
                    if (cleanUrl.startsWith("http")) {
                        domUrls.add(cleanUrl)
                    }
                }
            }

            // If empty, inspect all img elements with strict blacklist checking
            if (domUrls.isEmpty()) {
                val allImgs = doc.select("img")
                allImgs.forEach { img ->
                    val rawUrl = extractImageUrlFromImgTag(img)
                    if (rawUrl.isNotBlank() && isChapterPageImage(rawUrl, img)) {
                        val cleanUrl = cleanChapterImageUrl(rawUrl)
                        if (cleanUrl.startsWith("http")) {
                            domUrls.add(cleanUrl)
                        }
                    }
                }
            }

            // Fallback for JS-rendered arrays if DOM extraction fails
            if (domUrls.isEmpty()) {
                val scripts = doc.select("script")
                val imgRegex = Regex("""https?://[^\s"'<>\\]+\.(?:jpg|jpeg|png|webp|gif|avif)(?:\?[^\s"'<>\\]*)?""", RegexOption.IGNORE_CASE)
                val relativeImgRegex = Regex("""["'](/wp-content/[^\s"'<>\\]+\.(?:jpg|jpeg|png|webp|gif|avif))["']""", RegexOption.IGNORE_CASE)

                scripts.forEach { script ->
                    val jsText = script.html().replace("\\/", "/")
                    imgRegex.findAll(jsText).forEach { match ->
                        val url = match.value
                        if (isChapterPageImage(url, null)) {
                            val cleanUrl = cleanChapterImageUrl(url)
                            if (cleanUrl.startsWith("http")) domUrls.add(cleanUrl)
                        }
                    }
                    relativeImgRegex.findAll(jsText).forEach { match ->
                        val rel = match.groupValues[1]
                        val fullUrl = "https://mangalik.net$rel"
                        if (isChapterPageImage(fullUrl, null)) {
                            val cleanUrl = cleanChapterImageUrl(fullUrl)
                            if (cleanUrl.startsWith("http")) domUrls.add(cleanUrl)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting images", e)
        }
        return domUrls.distinct()
    }

    fun getHighResImageUrl(url: String): String {
        if (url.isBlank()) return url
        val base = url.substringBefore("?")
        val query = if (url.contains("?")) "?" + url.substringAfter("?") else ""

        val regex = "-\\d+x\\d+(\\.[a-zA-Z0-9]+)$".toRegex()
        var cleaned = base.replace(regex, "$1")
        val regexCrop = "-\\d+x\\d+-[a-zA-Z]+(\\.[a-zA-Z0-9]+)$".toRegex()
        cleaned = cleaned.replace(regexCrop, "$1")
        return cleaned + query
    }

    fun cleanChapterImageUrl(rawUrl: String): String {
        var url = rawUrl.trim()
        if (url.isBlank() || url.startsWith("data:", ignoreCase = true)) return ""
        return fixUrl(url)
    }

    private fun extractMangaCoverUrl(container: org.jsoup.nodes.Element): String {
        val imgElements = container.select("div.tab-thumb img, div.item-thumb img, div.summary_image img, .c-image-hover img, div.post-thumb img, img")
        for (img in imgElements) {
            val candidate = img.attr("data-src").ifBlank {
                img.attr("data-lazy-src").ifBlank {
                    img.attr("data-cfsrc").ifBlank {
                        val dataSrcset = img.attr("data-srcset")
                        if (dataSrcset.isNotBlank()) {
                            dataSrcset.split(",").firstOrNull()?.trim()?.split(" ")?.firstOrNull() ?: ""
                        } else {
                            val srcset = img.attr("srcset")
                            if (srcset.isNotBlank()) {
                                srcset.split(",").firstOrNull()?.trim()?.split(" ")?.firstOrNull() ?: ""
                            } else {
                                img.attr("data-original").ifBlank {
                                    img.attr("src")
                                }
                            }
                        }
                    }
                }
            }
            val fixed = getHighResImageUrl(fixUrl(candidate))
            if (fixed.isNotBlank() &&
                !fixed.contains("new.gif") &&
                !fixed.contains("logo") &&
                !fixed.contains("avatar") &&
                !fixed.contains("icon") &&
                !fixed.endsWith(".gif")
            ) {
                return fixed
            }
        }
        return ""
    }

    /**
     * Parse Latest Updates page number (e.g., 1, 2, 3...)
     * Page 1: https://mangalik.net/
     * Page 2: https://mangalik.net/page/2/
     */
    suspend fun fetchLatestUpdatesPage(page: Int): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) "https://mangalik.net/" else "https://mangalik.net/page/$page/"
        return@withContext parseCatalogFromUrl(url)
    }

    /**
     * Parse Manga List page number (e.g., 1, 2, 3...)
     * Ordered from A to Z (Alphabetical)
     */
    suspend fun fetchMangaListPage(page: Int): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) "https://mangalik.net/manga/?m_orderby=alphabet" else "https://mangalik.net/manga/page/$page/?m_orderby=alphabet"
        return@withContext parseCatalogFromUrl(url)
    }

    /**
     * Parse Trending Manga List page
     * Ordered by trending
     */
    suspend fun fetchTrendingMangaPage(page: Int): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) "https://mangalik.net/manga/?m_orderby=trending" else "https://mangalik.net/manga/page/$page/?m_orderby=trending"
        return@withContext parseCatalogFromUrl(url)
    }

    /**
     * Parse Manga List by Genre page
     */
    suspend fun fetchMangaByGenrePage(genreSlug: String, page: Int): List<MangaItem> = withContext(Dispatchers.IO) {
        val url = if (page <= 1) "https://mangalik.net/manga-genre/$genreSlug/" else "https://mangalik.net/manga-genre/$genreSlug/page/$page/"
        return@withContext parseCatalogFromUrl(url)
    }

    /**
     * Legacy backup methods for compatibility
     */
    suspend fun fetchHomeCatalog(baseUrl: String = DEFAULT_BASE_URL): List<MangaItem> = fetchLatestUpdatesPage(1)
    suspend fun fetchCatalogPage(page: Int): List<MangaItem> = fetchMangaListPage(page)

    /**
     * Smart Search via Madara AJAX Endpoint
     * HTTP POST Request to https://mangalik.net/wp-admin/admin-ajax.php
     * Form Body: action=wp-manga-search-manga, title={query}
     */
    suspend fun searchMangaAjax(query: String): List<MangaItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val cleanQuery = query.trim()
        val results = mutableListOf<MangaItem>()

        try {
            val formBody = okhttp3.FormBody.Builder()
                .add("action", "wp-manga-search-manga")
                .add("title", cleanQuery)
                .add("s", cleanQuery)
                .build()

            val request = Request.Builder()
                .url("https://mangalik.net/wp-admin/admin-ajax.php")
                .post(formBody)
                .header("User-Agent", userAgent)
                .header("Referer", "https://mangalik.net/")
                .header("X-Requested-With", "XMLHttpRequest")
                .header("Accept", "application/json, text/javascript, */*; q=0.01")
                .apply {
                    if (cloudflareCookies.isNotBlank()) {
                        header("Cookie", cloudflareCookies)
                    }
                }
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string()?.trim() ?: ""
                    Log.d(TAG, "AJAX Search response length: ${bodyString.length}")

                    if (bodyString.startsWith("[")) {
                        try {
                            val jsonArray = org.json.JSONArray(bodyString)
                            parseJsonArrayToMangas(jsonArray, results)
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed parsing JSON array", e)
                        }
                    } else if (bodyString.startsWith("{")) {
                        try {
                            val jsonObject = org.json.JSONObject(bodyString)
                            val dataObj = jsonObject.opt("data")
                            when (dataObj) {
                                is org.json.JSONArray -> parseJsonArrayToMangas(dataObj, results)
                                is org.json.JSONObject -> parseJsonArrayToMangas(org.json.JSONArray().put(dataObj), results)
                                is String -> {
                                    if (dataObj.contains("<")) {
                                        parseHtmlStringToMangas(dataObj, results)
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed parsing JSON object", e)
                        }
                    } else if (bodyString.contains("<")) {
                        parseHtmlStringToMangas(bodyString, results)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "AJAX Search request failed for query: $cleanQuery", e)
        }

        // Fallback or enrich with HTML GET search
        val htmlResults = searchMangas(cleanQuery)
        if (results.isEmpty()) {
            results.addAll(htmlResults)
        } else {
            for (i in results.indices) {
                val current = results[i]
                val match = htmlResults.find {
                    it.siteUrl.equals(current.siteUrl, ignoreCase = true) ||
                    it.id.equals(current.id, ignoreCase = true) ||
                    it.title.equals(current.title, ignoreCase = true)
                }
                if (match != null) {
                    results[i] = current.copy(
                        coverUrl = match.coverUrl.ifBlank { current.coverUrl },
                        bannerUrl = match.coverUrl.ifBlank { current.bannerUrl },
                        latestChapter = if (current.latestChapter == "جديد" && match.latestChapter != "جديد") match.latestChapter else current.latestChapter
                    )
                }
            }
        }

        return@withContext results.distinctBy { it.siteUrl.ifEmpty { it.id } }
    }

    private fun parseJsonArrayToMangas(dataArray: org.json.JSONArray, results: MutableList<MangaItem>) {
        for (i in 0 until dataArray.length()) {
            val itemObj = dataArray.optJSONObject(i) ?: continue
            val title = itemObj.optString("title").cleanText()
            val siteUrl = fixUrl(itemObj.optString("url"))
            val mangaId = extractMangaIdFromUrl(siteUrl)

            if (title == "قائمة المانجا" || title == "الأحدث" || title.contains("الأحدث") || mangaId.isBlank() || mangaId == "manga" || mangaId == "series" || mangaId == "manga-item" || title.all { it.isDigit() }) continue

            val thumbHtml = itemObj.optString("thumb").ifBlank {
                itemObj.optString("img").ifBlank {
                    itemObj.optString("image").ifBlank {
                        itemObj.optString("cover").ifBlank {
                            itemObj.optString("thumbnail").ifBlank {
                                itemObj.optString("post_image").ifBlank {
                                    itemObj.optString("post_thumb").ifBlank {
                                        itemObj.optString("src")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            var coverUrl = ""
            if (thumbHtml.isNotBlank()) {
                if (thumbHtml.contains("<")) {
                    val parsedDoc = org.jsoup.Jsoup.parse(thumbHtml)
                    coverUrl = extractMangaCoverUrl(parsedDoc)
                } else {
                    coverUrl = thumbHtml
                }
            }
            coverUrl = fixUrl(coverUrl)

            if (title.isNotBlank() && siteUrl.isNotBlank()) {
                results.add(
                    MangaItem(
                        id = mangaId,
                        title = title,
                        titleArabic = title,
                        coverUrl = coverUrl,
                        bannerUrl = coverUrl,
                        rating = 4.8f,
                        totalChapters = 100,
                        status = "مستمرة",
                        author = "mangalik.net",
                        summary = "نتيجة بحث من mangalik.net",
                        genres = listOf("أكشن", "مانهوا"),
                        isFeatured = false,
                        views = "mangalik",
                        latestChapter = "جديد",
                        siteUrl = siteUrl
                    )
                )
            }
        }
    }

    private fun parseHtmlStringToMangas(html: String, results: MutableList<MangaItem>) {
        val doc = org.jsoup.Jsoup.parse(html)
        val titleLinks = doc.select("a[href*='/manga/'], a[href*='/series/'], a[href*='/manhwa/'], a[href*='/manhua/'], a[href*='/comic/'], div.post-title a, h3 a")
        titleLinks.forEachIndexed { idx, anchor ->
            val titleText = anchor.text().cleanText()
            val siteUrl = fixUrl(anchor.attr("href"))
            val mangaId = extractMangaIdFromUrl(siteUrl)

            if (titleText.isNotBlank() && siteUrl.isNotBlank() && titleText != "قائمة المانجا" && titleText != "الأحدث" && !titleText.contains("الأحدث") && mangaId != "manga" && mangaId != "series" && !titleText.all { it.isDigit() }) {
                var container: org.jsoup.nodes.Element? = anchor.parent()
                var p = container
                for (i in 0..7) {
                    if (p == null) break
                    if (p.hasClass("c-tabs-item__content") || p.hasClass("page-item-detail") || p.hasClass("row") || p.select("img").isNotEmpty()) {
                        container = p
                        if (p.hasClass("c-tabs-item__content") || p.hasClass("page-item-detail")) break
                    }
                    p = p.parent()
                }
                val cardEl = container ?: anchor
                val cover = extractMangaCoverUrl(cardEl)

                results.add(
                    MangaItem(
                        id = mangaId,
                        title = titleText,
                        titleArabic = titleText,
                        coverUrl = cover,
                        bannerUrl = cover,
                        rating = 4.8f,
                        totalChapters = 100,
                        status = "مستمرة",
                        author = "mangalik.net",
                        summary = "نتيجة بحث من mangalik.net",
                        genres = listOf("أكشن", "مانهوا"),
                        isFeatured = false,
                        views = "mangalik",
                        latestChapter = "جديد",
                        siteUrl = siteUrl
                    )
                )
            }
        }
    }

    /**
     * Search Mangalik.net for a query via HTTP GET
     */
    suspend fun searchMangas(query: String): List<MangaItem> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        val encoded = try { java.net.URLEncoder.encode(query, "UTF-8") } catch (e: Exception) { query }
        val searchUrl1 = "https://mangalik.net/?s=$encoded&post_type=wp-manga"
        val searchUrl2 = "https://mangalik.net/?s=$encoded"

        val items1 = parseCatalogFromUrl(searchUrl1)
        val items2 = if (items1.isEmpty()) parseCatalogFromUrl(searchUrl2) else emptyList()

        return@withContext (items1 + items2).distinctBy { it.siteUrl.ifEmpty { it.id } }
    }

    private suspend fun parseCatalogFromUrl(url: String): List<MangaItem> = withContext(Dispatchers.IO) {
        val doc = fetchHtmlDocument(url) ?: return@withContext emptyList()
        val items = mutableListOf<MangaItem>()

        try {
            // First, try container-based extraction for Madara themes (highest accuracy)
            val containers = doc.select(".page-item-detail, .c-tabs-item__content, .manga-item, .c-manga-item, .tab-content-item, div.badge-pos-1, .item-summary, div.col-6.col-md-3, div.col-6.col-sm-4, div.col-12.col-md-6")

            if (containers.isNotEmpty()) {
                containers.forEach { cardEl ->
                    // Find true title anchor
                    val titleAnchor = cardEl.select(".post-title a, h3.h5 a, h3.h4 a, h3 a, h4 a, h5 a, .font-title a, .item-thumb a, div.tab-thumb a, .c-image-hover a").firstOrNull { a ->
                        val href = fixUrl(a.attr("href")).lowercase()
                        val text = a.text().trim()
                        if (!href.startsWith("http")) return@firstOrNull false
                        if (href.contains("/chapter") || href.contains("/page/") || href.contains("/genre/") || href.contains("/manga-genre/") || href.contains("/author/") || href.contains("/user/") || href.contains("#")) return@firstOrNull false

                        val path = href.substringAfter("mangalik.net/").substringBefore("?").substringBefore("#").trim('/')
                        val segments = path.split('/').filter { it.isNotBlank() }
                        if (segments.size > 2) return@firstOrNull false
                        if (segments.isEmpty() || segments.first() in listOf("genre", "author", "page", "user")) return@firstOrNull false

                        val isPureNumberOrChapter = text.matches(Regex("""^(\d+(\.\d+)?|\d+-\d+)$""")) ||
                            text.matches(Regex("""^(فصل|الفصل|ch|chapter|vol|volume|ep|episode)\s*[\d\.\-]+.*""", RegexOption.IGNORE_CASE)) ||
                            text.startsWith("فصل", ignoreCase = true) ||
                            text.startsWith("الفصل", ignoreCase = true) ||
                            text.startsWith("chapter", ignoreCase = true) ||
                            text.startsWith("ch.", ignoreCase = true)

                        if (isPureNumberOrChapter || text.all { it.isDigit() || it == '.' || it == '-' }) return@firstOrNull false
                        if (text == "الأحدث" || text.contains("الأحدث") || text == "قائمة المانجا" || text == "الرئيسية" || text == "المكتبة" || text == "تصفح" || text.startsWith("NEW")) return@firstOrNull false

                        true
                    }

                    if (titleAnchor != null) {
                        val titleText = titleAnchor.text().cleanText()
                        val siteUrl = fixUrl(titleAnchor.attr("href")).substringBefore("?").substringBefore("#").trimEnd('/') + "/"
                        val mangaId = extractMangaIdFromUrl(siteUrl)

                        if (mangaId.isNotBlank() && mangaId != "manga" && mangaId != "series" && !titleText.all { it.isDigit() || it == '.' }) {
                            val cover = extractMangaCoverUrl(cardEl)

                            // Latest chapter extraction
                            val latestChapEl = cardEl.select(".list-chapter .chapter-item a, div.chapter-item span.chapter a, div.chapter-item a, .latest-chap a, .chapter a, span.font-meta a, span.btn-link a, .chapter-item a").firstOrNull()
                            val rawChapText = latestChapEl?.text()?.cleanText() ?: ""

                            val releaseTimeEl = cardEl.select("span.post-on, .chapter-release-date, span.font-meta:has(i), .c-new-tag, time").firstOrNull()
                            val releaseTime = releaseTimeEl?.text()?.cleanText() ?: ""

                            val isChapter1 = when {
                                rawChapText.isBlank() -> false
                                else -> {
                                    val numStr = Regex("""\d+(\.\d+)?""").find(rawChapText)?.value
                                    numStr == "1" || numStr == "01" || numStr == "1.0"
                                }
                            }

                            val isBrandNew = isChapter1 ||
                                (cardEl.select(".c-new-tag, .new, .badge-new").text().contains("عمل جديد", ignoreCase = true))

                            val formattedChap = when {
                                rawChapText.isBlank() -> if (isBrandNew) "الفصل 1" else ""
                                rawChapText.matches(Regex("""^\d+(\.\d+)?$""")) -> "الفصل $rawChapText"
                                rawChapText.startsWith("الفصل") || rawChapText.startsWith("فصل") -> rawChapText
                                rawChapText.startsWith("ch", ignoreCase = true) || rawChapText.startsWith("chapter", ignoreCase = true) -> {
                                    val num = Regex("""\d+(\.\d+)?""").find(rawChapText)?.value ?: ""
                                    if (num.isNotBlank()) "الفصل $num" else rawChapText
                                }
                                rawChapText.contains("جديد") -> "الفصل 1"
                                else -> {
                                    val num = Regex("""\d+(\.\d+)?""").find(rawChapText)?.value
                                    if (num != null) "الفصل $num" else rawChapText
                                }
                            }

                            val ratingStr = cardEl.select("span.score.font-meta.total_votes, span.score, .post-total-rating .score, .total_votes").text()
                            val ratingVal = ratingStr.toFloatOrNull() ?: 4.8f

                            val genres = cardEl.select(".mg_genres a, .genres-content a").map { it.text().cleanText() }.filter { it.isNotBlank() }
                                .ifEmpty { listOf("مانهوا", "أكشن", "خيال") }

                            items.add(
                                MangaItem(
                                    id = mangaId,
                                    title = titleText,
                                    titleArabic = titleText,
                                    coverUrl = cover,
                                    bannerUrl = cover,
                                    rating = ratingVal,
                                    totalChapters = 100,
                                    status = "مستمرة",
                                    author = "mangalik.net",
                                    summary = "مانجا متاحة حصرياً عبر موقع مانجا ليك mangalik.net",
                                    genres = genres,
                                    isFeatured = items.isEmpty(),
                                    views = "mangalik",
                                    latestChapter = formattedChap,
                                    siteUrl = siteUrl,
                                    isNew = isBrandNew,
                                    latestReleaseTime = releaseTime
                                )
                            )
                        }
                    }
                }
            }

            // Fallback to link matching if containers didn't return items
            if (items.isEmpty()) {
                val titleLinks = doc.select("h3.h5 a, div.post-title a, h3.h4 a, .post-title a, h3 a, .title a, div.tab-thumb a, div.item-thumb a, .c-image-hover a, a[href*='/manga/'], a[href*='/series/'], a[href*='/manhwa/'], a[href*='/manhua/'], a[href*='/comic/']")
                    .filter { a ->
                        val href = fixUrl(a.attr("href")).lowercase()
                        val text = a.text().trim()

                        if (!href.startsWith("http")) return@filter false
                        if (href.contains("/chapter") || href.contains("/page/") || href.contains("/genre/") || href.contains("/manga-genre/") || href.contains("/author/") || href.contains("/user/") || href.contains("#")) return@filter false

                        val path = href.substringAfter("mangalik.net/").substringBefore("?").substringBefore("#").trim('/')
                        val segments = path.split('/').filter { it.isNotBlank() }
                        if (segments.size > 2) return@filter false
                        if (segments.isEmpty() || segments.first() in listOf("genre", "author", "page", "user")) return@filter false

                        val isPureNumberOrChapter = text.matches(Regex("""^(\d+(\.\d+)?|\d+-\d+)$""")) ||
                            text.matches(Regex("""^(فصل|الفصل|ch|chapter|vol|volume|ep|episode)\s*[\d\.\-]+.*""", RegexOption.IGNORE_CASE)) ||
                            text.startsWith("فصل", ignoreCase = true) ||
                            text.startsWith("الفصل", ignoreCase = true) ||
                            text.startsWith("chapter", ignoreCase = true) ||
                            text.startsWith("ch.", ignoreCase = true)

                        if (isPureNumberOrChapter || text.all { it.isDigit() || it == '.' || it == '-' }) return@filter false
                        if (text == "الأحدث" || text.contains("الأحدث") || text == "قائمة المانجا" || text == "الرئيسية" || text == "المكتبة" || text == "تصفح" || text.startsWith("NEW")) return@filter false

                        true
                    }

                titleLinks.distinctBy { fixUrl(it.attr("href")) }.forEachIndexed { idx, anchor ->
                    val titleText = anchor.text().cleanText()
                    val siteUrl = fixUrl(anchor.attr("href")).substringBefore("?").substringBefore("#").trimEnd('/') + "/"
                    val mangaId = extractMangaIdFromUrl(siteUrl)

                    if (mangaId.lowercase() == "manga" || mangaId.lowercase() == "series" || titleText == "الأحدث" || titleText.contains("الأحدث") || titleText == "قائمة المانجا" || titleText.all { it.isDigit() || it == '.' }) {
                        return@forEachIndexed
                    }

                    var container: org.jsoup.nodes.Element? = anchor.parent()
                    var p = container
                    for (i in 0..7) {
                        if (p == null) break
                        if (p.hasClass("c-tabs-item__content") ||
                            p.hasClass("page-item-detail") ||
                            p.hasClass("manga-item") ||
                            p.hasClass("c-manga-item") ||
                            p.hasClass("tab-content-item") ||
                            p.hasClass("badge-pos-1") ||
                            p.hasClass("item-summary") ||
                            p.hasClass("row")
                        ) {
                            container = p
                            if (p.hasClass("c-tabs-item__content") || p.hasClass("page-item-detail") || p.hasClass("manga-item") || p.hasClass("tab-content-item")) {
                                break
                            }
                        }
                        p = p.parent()
                    }
                    val cardEl = container ?: anchor

                    val cover = extractMangaCoverUrl(cardEl)

                    val latestChapEl = cardEl.select("div.chapter-item span.chapter a, div.chapter-item a, .latest-chap a, .chapter a, span.font-meta a, span.btn-link a").firstOrNull()
                    val rawChapText = latestChapEl?.text()?.cleanText() ?: ""

                    val releaseTimeEl = cardEl.select("span.post-on, .chapter-release-date, span.font-meta:has(i), .c-new-tag, time").firstOrNull()
                    val releaseTime = releaseTimeEl?.text()?.cleanText() ?: ""

                    val isChapter1 = when {
                        rawChapText.isBlank() -> false
                        else -> {
                            val numStr = Regex("""\d+(\.\d+)?""").find(rawChapText)?.value
                            numStr == "1" || numStr == "01" || numStr == "1.0"
                        }
                    }

                    val isBrandNew = isChapter1

                    val formattedChap = when {
                        rawChapText.isBlank() -> if (isBrandNew) "الفصل 1" else ""
                        rawChapText.matches(Regex("""^\d+(\.\d+)?$""")) -> "الفصل $rawChapText"
                        rawChapText.startsWith("الفصل") || rawChapText.startsWith("فصل") -> rawChapText
                        rawChapText.startsWith("ch", ignoreCase = true) -> "الفصل " + Regex("""\d+(\.\d+)?""").find(rawChapText)?.value.orEmpty()
                        else -> rawChapText
                    }

                    val ratingStr = cardEl.select("span.score.font-meta.total_votes, span.score, .post-total-rating .score, .total_votes").text()
                    val ratingVal = ratingStr.toFloatOrNull() ?: 4.8f

                    val genres = cardEl.select(".mg_genres a, .genres-content a").map { it.text().cleanText() }.filter { it.isNotBlank() }
                        .ifEmpty { listOf("مانهوا", "أكشن", "خيال") }

                    if (titleText.isNotBlank() && siteUrl.isNotBlank() && siteUrl.contains("mangalik.net")) {
                        items.add(
                            MangaItem(
                                id = mangaId,
                                title = titleText,
                                titleArabic = titleText,
                                coverUrl = cover,
                                bannerUrl = cover,
                                rating = ratingVal,
                                totalChapters = 100,
                                status = "مستمرة",
                                author = "mangalik.net",
                                summary = "مانجا متاحة حصرياً عبر موقع مانجا ليك mangalik.net",
                                genres = genres,
                                isFeatured = items.isEmpty(),
                                views = "mangalik",
                                latestChapter = formattedChap,
                                siteUrl = siteUrl,
                                isNew = isBrandNew,
                                latestReleaseTime = releaseTime
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing catalog from $url", e)
        }

        return@withContext items.distinctBy { it.siteUrl.ifEmpty { it.id } }
    }

    fun fixUrl(rawUrl: String): String {
        var clean = rawUrl.trim()
        if (clean.startsWith("//")) {
            clean = "https:$clean"
        } else if (clean.startsWith("/")) {
            clean = "https://mangalik.net$clean"
        }
        
        // Strip Photon CDN prefixes if present
        if (clean.contains("wp.com/mangalik.net", ignoreCase = true)) {
            clean = "https://mangalik.net" + clean.substringAfter("mangalik.net")
        } else if (clean.contains("wp.com/", ignoreCase = true)) {
            clean = clean.replace(Regex("""https?://[a-zA-Z0-9-]+\.wp\.com/"""), "https://")
        }
        
        return clean
    }

    private fun String.cleanText(): String {
        return this.replace("\\s+".toRegex(), " ").trim()
    }
}
