package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import com.example.R
import com.example.data.local.CommentEntity
import com.example.data.local.DownloadedChapterEntity
import com.example.data.local.FavoriteMangaEntity
import com.example.data.local.MangaDao
import com.example.data.local.MangaDatabase
import com.example.data.local.ReadingHistoryEntity
import com.example.data.models.ChapterItem
import com.example.data.models.DownloadQuality
import com.example.data.models.LibraryCategory
import com.example.data.models.MangaItem
import com.example.data.models.UserComment
import com.example.data.network.MadaraScraper
import com.example.utils.DownloadNotificationHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class MangaRepository(private val context: Context) {
    private val dao: MangaDao = MangaDatabase.getDatabase(context).mangaDao()
    private val notificationHelper = DownloadNotificationHelper(context)

    var isCloudflareBypassed: Boolean = true
    var cloudflareCookies: String = ""

    private val httpClient get() = MadaraScraper.client

    private val activeDownloadJobs = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val applicationScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)
    private val _isDownloadsPaused = MutableStateFlow(false)
    val isDownloadsPaused: StateFlow<Boolean> = _isDownloadsPaused.asStateFlow()

    private fun checkServiceState() {
        if (activeDownloadJobs.isEmpty()) {
            com.example.service.DownloadService.stop(context)
        } else {
            com.example.service.DownloadService.start(context)
        }
    }

    fun togglePauseDownloads() {
        _isDownloadsPaused.value = !_isDownloadsPaused.value
    }

    fun cancelDownload(mangaId: String, chapterId: String) {
        activeDownloadJobs[chapterId]?.cancel()
        activeDownloadJobs.remove(chapterId)
        _downloadProgress.value = _downloadProgress.value - chapterId
        try {
            val downloadDir = File(context.filesDir, "downloads/$mangaId/$chapterId")
            if (downloadDir.exists()) {
                downloadDir.deleteRecursively()
            }
        } catch (e: Exception) {
            Log.e("MangaRepository", "Failed deleting cancelled download $chapterId", e)
        }
        checkServiceState()
    }

    fun clearAllDownloadsQueue() {
        activeDownloadJobs.forEach { (_, job) -> job.cancel() }
        activeDownloadJobs.clear()
        _downloadProgress.value = emptyMap()
        checkServiceState()
    }

    // Download progress map: chapterId -> Float progress (0.0f to 1.0f)
    private val _downloadProgress = MutableStateFlow<Map<String, Float>>(emptyMap())
    val downloadProgress: StateFlow<Map<String, Float>> = _downloadProgress.asStateFlow()

    val downloadedChapters: Flow<List<DownloadedChapterEntity>> = dao.getAllDownloadedChapters()

    fun getDownloadedChapter(chapterId: String): Flow<DownloadedChapterEntity?> {
        return dao.getDownloadedChapter(chapterId)
    }

    suspend fun getDownloadedChapterDirectly(chapterId: String): DownloadedChapterEntity? {
        return dao.getDownloadedChapterDirect(chapterId)
    }

    suspend fun downloadChapter(
        mangaId: String,
        mangaTitle: String,
        coverUrl: String,
        chapter: ChapterItem,
        quality: DownloadQuality = DownloadQuality.MEDIUM
    ): Boolean = withContext(Dispatchers.IO) {
        val chapterId = chapter.id
        val pages = chapter.pages
        if (pages.isEmpty()) return@withContext false

        val currentJob = coroutineContext[kotlinx.coroutines.Job]
        if (currentJob != null) {
            activeDownloadJobs[chapterId] = currentJob
        }

        val notificationId = (mangaId + chapterId).hashCode()
        notificationHelper.showDownloadProgress(
            notificationId = notificationId,
            mangaTitle = mangaTitle,
            chapterTitle = chapter.title,
            progressPercent = 0,
            qualityBadge = quality.badge
        )

        try {
            val downloadDir = File(context.filesDir, "downloads/$mangaId/$chapterId").apply { mkdirs() }

            val totalPages = pages.size
            val completedCounter = java.util.concurrent.atomic.AtomicInteger(0)
            val totalBytesCounter = java.util.concurrent.atomic.AtomicLong(0L)
            val downloadedPathsMap = java.util.concurrent.ConcurrentHashMap<Int, String>()
            val semaphore = kotlinx.coroutines.sync.Semaphore(5)

            coroutineScope {
                val jobs = pages.mapIndexed { index, pageUrl ->
                    async(Dispatchers.IO) {
                        semaphore.withPermit {
                            while (_isDownloadsPaused.value) {
                                kotlinx.coroutines.delay(500)
                            }

                            if (!kotlinx.coroutines.currentCoroutineContext().isActive) {
                                return@withPermit
                            }

                            val destFile = File(downloadDir, "page_${index + 1}.jpg")
                            if (!destFile.exists() || destFile.length() == 0L) {
                                val request = Request.Builder()
                                    .url(pageUrl)
                                    .header("User-Agent", MadaraScraper.userAgent)
                                    .header("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            header("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .build()

                                var pageDownloaded = false
                                var pageAttempt = 0
                                while (!pageDownloaded && pageAttempt < 3 && kotlinx.coroutines.currentCoroutineContext().isActive) {
                                    pageAttempt++
                                    try {
                                        httpClient.newCall(request).execute().use { response ->
                                            if (response.isSuccessful && response.body != null) {
                                                val bytes = response.body!!.bytes()
                                                if (quality == DownloadQuality.HIGH) {
                                                    FileOutputStream(destFile).use { out -> out.write(bytes) }
                                                } else {
                                                    try {
                                                        val originalBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                                        if (originalBitmap != null) {
                                                            val origW = originalBitmap.width
                                                            val origH = originalBitmap.height
                                                            val targetW = minOf(origW, quality.maxPixelWidth)
                                                            val scale = targetW.toFloat() / origW.toFloat()
                                                            val targetH = (origH * scale).toInt().coerceAtLeast(1)

                                                            val scaledBitmap = if (targetW != origW) {
                                                                Bitmap.createScaledBitmap(originalBitmap, targetW, targetH, true)
                                                            } else {
                                                                originalBitmap
                                                            }

                                                            FileOutputStream(destFile).use { out ->
                                                                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality.compressionQuality, out)
                                                            }

                                                            if (scaledBitmap != originalBitmap) {
                                                                scaledBitmap.recycle()
                                                            }
                                                            originalBitmap.recycle()
                                                        } else {
                                                            FileOutputStream(destFile).use { out -> out.write(bytes) }
                                                        }
                                                    } catch (e: Exception) {
                                                        Log.e("MangaRepository", "Failed to compress image for quality $quality", e)
                                                        FileOutputStream(destFile).use { out -> out.write(bytes) }
                                                    }
                                                }
                                                pageDownloaded = true
                                            } else {
                                                kotlinx.coroutines.delay(500)
                                            }
                                        }
                                    } catch (e: Exception) {
                                        Log.w("MangaRepository", "Attempt $pageAttempt failed for page $index: ${e.message}")
                                        if (pageAttempt < 3) kotlinx.coroutines.delay(800)
                                    }
                                }
                            }

                            if (destFile.exists() && destFile.length() > 0L) {
                                totalBytesCounter.addAndGet(destFile.length())
                                downloadedPathsMap[index] = "file://${destFile.absolutePath}"
                            }

                            val finishedCount = completedCounter.incrementAndGet()
                            val progressFraction = finishedCount.toFloat() / totalPages
                            val progressPercent = (finishedCount * 100) / totalPages

                            _downloadProgress.value = _downloadProgress.value + (chapterId to progressFraction)
                            notificationHelper.showDownloadProgress(
                                notificationId = notificationId,
                                mangaTitle = mangaTitle,
                                chapterTitle = chapter.title,
                                progressPercent = progressPercent,
                                qualityBadge = quality.badge
                            )
                        }
                    }
                }
                jobs.awaitAll()
            }

            val localPaths = (0 until totalPages).mapNotNull { downloadedPathsMap[it] }
            val totalBytesDownloaded = totalBytesCounter.get()

            if (localPaths.isNotEmpty()) {
                val sizeMb = String.format("%.1f MB (%s)", totalBytesDownloaded / (1024.0 * 1024.0), quality.badge)
                val entity = DownloadedChapterEntity(
                    chapterId = chapterId,
                    mangaId = mangaId,
                    mangaTitle = mangaTitle,
                    chapterTitle = "${chapter.title} [${quality.badge}]",
                    coverUrl = coverUrl,
                    localPagePathsJson = localPaths.joinToString(","),
                    downloadedAt = System.currentTimeMillis(),
                    totalSizeMb = sizeMb
                )
                dao.insertDownloadedChapter(entity)
                _downloadProgress.value = _downloadProgress.value - chapterId

                val telegramManager = com.example.utils.TelegramManager.getInstance(context)
                if (telegramManager.isAutoUploadEnabled) {
                    applicationScope.launch(Dispatchers.IO) {
                        try {
                            telegramManager.uploadChapter(
                                mangaTitle = mangaTitle,
                                chapterTitle = chapter.title,
                                downloadDir = downloadDir,
                                coverUrl = coverUrl
                            )
                        } catch (e: Exception) {
                            Log.e("MangaRepository", "Failed auto telegram upload", e)
                        }
                    }
                }

                notificationHelper.showDownloadComplete(
                    notificationId = notificationId,
                    mangaTitle = mangaTitle,
                    chapterTitle = chapter.title,
                    qualityBadge = quality.badge
                )
                return@withContext true
            } else {
                notificationHelper.showDownloadFailed(
                    notificationId = notificationId,
                    mangaTitle = mangaTitle,
                    chapterTitle = chapter.title
                )
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            _downloadProgress.value = _downloadProgress.value - chapterId
            notificationHelper.cancelNotification(notificationId)
            throw e
        } catch (e: Exception) {
            Log.e("MangaRepository", "Error downloading chapter $chapterId", e)
            notificationHelper.showDownloadFailed(
                notificationId = notificationId,
                mangaTitle = mangaTitle,
                chapterTitle = chapter.title
            )
        }
        _downloadProgress.value = _downloadProgress.value - chapterId
        return@withContext false
    }

    fun enqueueDownloadChapter(
        manga: MangaItem,
        chapter: ChapterItem,
        quality: DownloadQuality = DownloadQuality.MEDIUM
    ) {
        val chapterId = chapter.id
        if (activeDownloadJobs.containsKey(chapterId)) return

        checkServiceState()

        val job = applicationScope.launch {
            try {
                val targetChapter = if (chapter.pages.isEmpty() && chapter.url.isNotBlank()) {
                    val extractedPages = MadaraScraper.fetchChapterImages(chapter.url)
                    chapter.copy(pages = extractedPages)
                } else chapter

                if (targetChapter.pages.isNotEmpty()) {
                    downloadChapter(
                        mangaId = manga.id,
                        mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                        coverUrl = manga.coverUrl,
                        chapter = targetChapter,
                        quality = quality
                    )
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("MangaRepository", "Failed enqueued download $chapterId", e)
            } finally {
                activeDownloadJobs.remove(chapterId)
                checkServiceState()
            }
        }
        activeDownloadJobs[chapterId] = job
    }

    fun enqueueDownloadAllChapters(
        manga: MangaItem,
        chapters: List<ChapterItem>,
        quality: DownloadQuality = DownloadQuality.MEDIUM
    ) {
        if (chapters.isEmpty()) return
        checkServiceState()

        applicationScope.launch {
            try {
                val alreadyDownloaded = dao.getAllDownloadedChaptersDirect().map { it.chapterId }.toSet()
                // Sort ascending by chapter number so Chapter 1 is downloaded first, then 2, 3...
                val pendingChapters = chapters
                    .filter { !alreadyDownloaded.contains(it.id) }
                    .sortedBy { it.chapterNumber }

                for (ch in pendingChapters) {
                    if (!kotlinx.coroutines.currentCoroutineContext().isActive) break
                    val chapterId = ch.id
                    val currentJob = coroutineContext[kotlinx.coroutines.Job]
                    if (currentJob != null) {
                        activeDownloadJobs[chapterId] = currentJob
                    }
                    try {
                        val targetChapter = if (ch.pages.isEmpty() && ch.url.isNotBlank()) {
                            val extractedPages = MadaraScraper.fetchChapterImages(ch.url)
                            ch.copy(pages = extractedPages)
                        } else ch

                        if (targetChapter.pages.isNotEmpty()) {
                            downloadChapter(
                                mangaId = manga.id,
                                mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                                coverUrl = manga.coverUrl,
                                chapter = targetChapter,
                                quality = quality
                            )
                        }
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.e("MangaRepository", "Failed batch download chapter $chapterId", e)
                    } finally {
                        activeDownloadJobs.remove(chapterId)
                        checkServiceState()
                    }
                    // Gentle, natural pause between downloading consecutive chapters
                    kotlinx.coroutines.delay(150)
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                // Cancellation is normal, do not log error
            } catch (e: Exception) {
                Log.e("MangaRepository", "Failed batch download process", e)
            } finally {
                checkServiceState()
            }
        }
    }

    suspend fun deleteDownloadedChapter(mangaId: String, chapterId: String) = withContext(Dispatchers.IO) {
        try {
            val downloadDir = File(context.filesDir, "downloads/$mangaId/$chapterId")
            if (downloadDir.exists()) {
                downloadDir.deleteRecursively()
            }
            dao.deleteDownloadedChapter(chapterId)
        } catch (e: Exception) {
            Log.e("MangaRepository", "Error deleting downloaded chapter $chapterId", e)
        }
    }

    // Live catalog items from mangalik.net stored in memory
    private val liveMangas = mutableListOf<MangaItem>()

    fun getMangas(): List<MangaItem> = liveMangas

    fun setLiveMangas(mangas: List<MangaItem>) {
        liveMangas.clear()
        liveMangas.addAll(mangas)
    }

    fun getMangaById(id: String): MangaItem? {
        return liveMangas.find { it.id == id } ?: liveMangas.firstOrNull()
    }

    fun getChaptersForManga(mangaId: String): List<ChapterItem> {
        return emptyList()
    }

    // Room Favorites Data Flow
    val allFavorites: Flow<List<FavoriteMangaEntity>> = dao.getAllFavorites()

    fun isFavorite(mangaId: String): Flow<Boolean> {
        return dao.getFavoriteById(mangaId).map { it != null }
    }

    suspend fun toggleFavorite(manga: MangaItem, category: LibraryCategory = LibraryCategory.FAVORITE) {
        val existing = dao.getFavoriteByIdDirect(manga.id)
        if (existing != null && category == LibraryCategory.FAVORITE) {
            dao.deleteFavorite(manga.id)
        } else {
            dao.insertFavorite(
                FavoriteMangaEntity(
                    mangaId = manga.id,
                    title = manga.title,
                    titleArabic = manga.titleArabic.ifEmpty { manga.title },
                    coverUrl = manga.coverUrl,
                    rating = manga.rating,
                    totalChapters = manga.totalChapters,
                    status = manga.status,
                    category = category.name
                )
            )
        }
    }

    suspend fun removeFavorite(mangaId: String) {
        dao.deleteFavorite(mangaId)
    }

    // Reading History
    val readingHistory: Flow<List<ReadingHistoryEntity>> = dao.getReadingHistory()

    suspend fun saveReadingProgress(mangaId: String, mangaTitle: String, coverUrl: String, chapterId: String, chapterTitle: String, pageIndex: Int, totalPages: Int) {
        dao.insertHistory(
            ReadingHistoryEntity(
                mangaId = mangaId,
                mangaTitle = mangaTitle,
                coverUrl = coverUrl,
                chapterId = chapterId,
                chapterTitle = chapterTitle,
                lastPageIndex = pageIndex,
                totalPages = totalPages
            )
        )
    }

    // Comments
    fun getComments(mangaId: String): Flow<List<UserComment>> {
        return dao.getCommentsForManga(mangaId).map { entities ->
            if (entities.isEmpty()) {
                // Return default initial Arabic comments if empty
                listOf(
                    UserComment(
                        id = "c1",
                        mangaId = mangaId,
                        userName = "أحمد الساير",
                        content = "فصل اسطوري جداً! الرسم والأحداث في قمة الحماس والتشويق 🔥",
                        timestamp = "منذ ساعة",
                        likes = 24,
                        isLikedByMe = true
                    ),
                    UserComment(
                        id = "c2",
                        mangaId = mangaId,
                        userName = "عمر مانجا",
                        content = "شكراً لفريق سبيد مانجا على السرعة الفائقة في الترجمة وتنزيل الفصول!",
                        timestamp = "منذ 3 ساعات",
                        likes = 15,
                        isLikedByMe = false
                    )
                )
            } else {
                entities.map { entity ->
                    UserComment(
                        id = entity.id,
                        mangaId = entity.mangaId,
                        chapterId = entity.chapterId,
                        userName = entity.userName,
                        userAvatar = entity.userAvatar,
                        content = entity.content,
                        timestamp = "الآن",
                        likes = entity.likes,
                        isLikedByMe = entity.isLikedByMe
                    )
                }
            }
        }
    }

    suspend fun addComment(mangaId: String, userName: String, text: String) {
        val newComment = CommentEntity(
            id = "comment-${System.currentTimeMillis()}",
            mangaId = mangaId,
            userName = userName.ifBlank { "عاشق المانجا" },
            content = text,
            timestamp = System.currentTimeMillis(),
            likes = 0
        )
        dao.insertComment(newComment)
    }

    suspend fun toggleCommentLike(commentId: String, currentLikes: Int, currentIsLiked: Boolean) {
        val newLikes = if (currentIsLiked) currentLikes - 1 else currentLikes + 1
        dao.updateCommentLike(commentId, newLikes.coerceAtLeast(0), !currentIsLiked)
    }
}
