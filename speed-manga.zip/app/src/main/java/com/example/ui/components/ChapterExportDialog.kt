package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.models.ChapterItem
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextMuted
import com.example.utils.ChapterExportManager
import com.example.utils.ExportFormat
import com.example.utils.ExportResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

private enum class ExportDialogStep {
    CONFIG,
    EXPORTING,
    SUCCESS,
    ERROR
}

@Composable
fun ChapterExportDialog(
    mangaTitle: String,
    chapters: List<ChapterItem>,
    initialFormat: ExportFormat? = null,
    initialCreateSubfolder: Boolean? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val readerPrefs = remember { com.example.utils.ReaderPreferences(context) }
    val userSettings = remember { readerPrefs.getSettings() }

    val defaultFormat = remember(userSettings.exportFormat, initialFormat) {
        initialFormat ?: if (userSettings.exportFormat == "CBZ") ExportFormat.CBZ else ExportFormat.PDF
    }
    val defaultSubfolder = remember(userSettings.createMangaSubfolders, initialCreateSubfolder) {
        initialCreateSubfolder ?: userSettings.createMangaSubfolders
    }

    var selectedFormat by remember { mutableStateOf(defaultFormat) }
    var createSubfolder by remember { mutableStateOf(defaultSubfolder) }
    var dialogStep by remember { mutableStateOf(ExportDialogStep.EXPORTING) }

    var currentChapterIndex by remember { mutableIntStateOf(0) }
    var currentPageIndex by remember { mutableIntStateOf(0) }
    var totalPagesInChapter by remember { mutableIntStateOf(0) }
    var progressStatusText by remember { mutableStateOf("") }

    var lastExportResult by remember { mutableStateOf<ExportResult?>(null) }
    var lastExportedFiles by remember { mutableStateOf<List<File>>(emptyList()) }
    var errorMessage by remember { mutableStateOf("") }

    val isSingleChapter = chapters.size == 1
    val singleChapter = chapters.firstOrNull()

    fun startExport() {
        dialogStep = ExportDialogStep.EXPORTING
        currentChapterIndex = 0
        val exportedFiles = mutableListOf<File>()

        coroutineScope.launch(Dispatchers.IO) {
            try {
                for (i in chapters.indices) {
                    currentChapterIndex = i
                    val chapter = chapters[i]

                    val result = ChapterExportManager.exportChapter(
                        context = context,
                        mangaTitle = mangaTitle,
                        chapterTitle = chapter.title.ifEmpty { "Chapter-${chapter.chapterNumber}" },
                        chapterUrl = chapter.url,
                        pagePathsOrUrls = chapter.pages,
                        format = selectedFormat,
                        qualitySetting = userSettings.downloadQuality,
                        createMangaSubfolder = createSubfolder,
                        onProgress = { curr, total, status ->
                            currentPageIndex = curr
                            totalPagesInChapter = total
                            progressStatusText = if (chapters.size > 1) {
                                "[فصل ${i + 1}/${chapters.size}] $status"
                            } else {
                                status
                            }
                        }
                    )

                    if (!result.isSuccess || result.file == null) {
                        errorMessage = result.errorMessage ?: "فشل تصدير الفصل ${chapter.title}"
                        dialogStep = ExportDialogStep.ERROR
                        return@launch
                    }

                    exportedFiles.add(result.file)
                    lastExportResult = result
                }

                lastExportedFiles = exportedFiles
                dialogStep = ExportDialogStep.SUCCESS
            } catch (e: Exception) {
                errorMessage = e.message ?: "حدث خطأ غير متوقع"
                dialogStep = ExportDialogStep.ERROR
            }
        }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        startExport()
    }

    Dialog(
        onDismissRequest = {
            if (dialogStep != ExportDialogStep.EXPORTING) onDismiss()
        },
        properties = DialogProperties(
            dismissOnBackPress = dialogStep != ExportDialogStep.EXPORTING,
            dismissOnClickOutside = dialogStep != ExportDialogStep.EXPORTING,
            usePlatformDefaultWidth = false
        )
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(20.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp))
                .testTag("chapter_export_dialog"),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(MangaRedPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = null,
                                tint = MangaRedPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "حفظ في ذاكرة الهاتف",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (isSingleChapter) singleChapter?.title ?: "" else "${chapters.size} فصول محددة",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    if (dialogStep != ExportDialogStep.EXPORTING) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                AnimatedContent(
                    targetState = dialogStep,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "ExportDialogAnimation"
                ) { step ->
                    when (step) {
                        ExportDialogStep.CONFIG -> {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "اختر صيغة الملف لحفظها في الهاتف:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 12.dp),
                                    textAlign = TextAlign.Start
                                )

                                // Format Option: PDF
                                FormatOptionCard(
                                    title = "مستند PDF عالي الجودة (.pdf)",
                                    description = "ملف PDF واحد يحتوي على جميع الصفحات، جاهز للقراءة والطباعة والمشاركة.",
                                    icon = Icons.Default.PictureAsPdf,
                                    isSelected = selectedFormat == ExportFormat.PDF,
                                    badge = "موصى به",
                                    onClick = { selectedFormat = ExportFormat.PDF }
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Format Option: CBZ
                                FormatOptionCard(
                                    title = "أرشيف كوميكس مضغوط (.cbz)",
                                    description = "المعيار العالمي للقصص المصورة والمانجا، متوافق مع تطبيقات القراءة الخارجية.",
                                    icon = Icons.Default.Folder,
                                    isSelected = selectedFormat == ExportFormat.CBZ,
                                    badge = "خفيف وسريع",
                                    onClick = { selectedFormat = ExportFormat.CBZ }
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // Folder Structure Preview & Switch
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Folder,
                                                    contentDescription = null,
                                                    tint = MangaGold,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = "إنشاء مجلد مخصص للمانجا",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }

                                            Switch(
                                                checked = createSubfolder,
                                                onCheckedChange = { createSubfolder = it },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = Color.White,
                                                    checkedTrackColor = MangaRedPrimary
                                                )
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))

                                        val previewPath = if (createSubfolder) {
                                            "Downloads/SpeedManga/${ChapterExportManager.sanitizeFileName(mangaTitle)}/"
                                        } else {
                                            "Downloads/SpeedManga/"
                                        }

                                        Text(
                                            text = "المسار: $previewPath",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                // Action Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onDismiss,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = "إلغاء",
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    Button(
                                        onClick = { startExport() },
                                        modifier = Modifier
                                            .weight(1.3f)
                                            .testTag("confirm_export_button"),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                                    ) {
                                        Text(
                                            text = "بدء الحفظ الآن 📥",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        ExportDialogStep.EXPORTING -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                CircularProgressIndicator(
                                    color = MangaRedPrimary,
                                    strokeWidth = 3.5.dp,
                                    strokeCap = StrokeCap.Round,
                                    modifier = Modifier.size(48.dp)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Text(
                                    text = if (chapters.size > 1) {
                                        "جاري حفظ الفصل ${currentChapterIndex + 1} من ${chapters.size}"
                                    } else {
                                        "جاري إنشاء ملف ${selectedFormat.displayName}..."
                                    },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MangaRedPrimary.copy(alpha = 0.12f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "صيغة الحفظ: ${selectedFormat.extension.uppercase()} (حسب الإعدادات)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MangaRedPrimary
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = progressStatusText.ifEmpty { "يرجى الانتظار لحظات..." },
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )

                                if (totalPagesInChapter > 0) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    val progressFraction = (currentPageIndex.toFloat() / totalPagesInChapter.toFloat()).coerceIn(0f, 1f)
                                    LinearProgressIndicator(
                                        progress = { progressFraction },
                                        color = MangaRedPrimary,
                                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                                        strokeCap = StrokeCap.Round,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "$currentPageIndex / $totalPagesInChapter صفحة",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MangaRedPrimary
                                    )
                                }
                            }
                        }

                        ExportDialogStep.SUCCESS -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF2E7D32).copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF4CAF50),
                                        modifier = Modifier.size(36.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = "تم الحفظ في الهاتف بنجاح! 🎉",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                val savedFile = lastExportedFiles.firstOrNull()
                                Text(
                                    text = "تم الحفظ في:\n${savedFile?.parentFile?.name ?: "SpeedManga"}/${savedFile?.name ?: ""}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                )

                                Spacer(modifier = Modifier.height(20.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    if (savedFile != null && lastExportedFiles.size == 1) {
                                        OutlinedButton(
                                            onClick = {
                                                ChapterExportManager.openFile(context, savedFile, selectedFormat)
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.OpenInNew,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "فتح",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                ChapterExportManager.shareFile(
                                                    context,
                                                    savedFile,
                                                    savedFile.nameWithoutExtension
                                                )
                                            },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = MaterialTheme.colorScheme.onSurface
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = "مشاركة",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Button(
                                        onClick = onDismiss,
                                        modifier = Modifier.weight(1.2f),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                                    ) {
                                        Text(
                                            text = "تم",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        ExportDialogStep.ERROR -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = MangaRedPrimary,
                                    modifier = Modifier.size(44.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = "فشل حفظ الفصل",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = errorMessage,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    OutlinedButton(
                                        onClick = onDismiss,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text("إغلاق", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    Button(
                                        onClick = { startExport() },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary)
                                    ) {
                                        Text("إعادة المحاولة", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FormatOptionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    badge: String,
    onClick: () -> Unit
) {
    val borderColor = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val bgColor = if (isSelected) MangaRedPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = bgColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isSelected) MangaRedPrimary.copy(alpha = 0.15f)
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badge,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 15.sp
                )
            }
        }
    }
}
