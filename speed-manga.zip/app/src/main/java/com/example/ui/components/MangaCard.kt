package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.models.MangaItem
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary

private val CardShape = RoundedCornerShape(14.dp)
private val ImageShape = RoundedCornerShape(10.dp)
private val ChapterBadgeShape = RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp, topEnd = 4.dp, bottomStart = 4.dp)
private val NewBadgeShape = RoundedCornerShape(6.dp)

private val ChapterRegex = Regex("""\d+(\.\d+)?""")

@Composable
fun MangaCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier,
    isListView: Boolean = false
) {
    if (isListView) {
        MangaListCard(manga = manga, onClick = onClick, modifier = modifier)
    } else {
        MangaGridCard(manga = manga, onClick = onClick, modifier = modifier)
    }
}

/**
 * Grid View Card:
 * Features high quality cover, prominent latest chapter pill badge on cover,
 * glowing animated "جديد ✨" badge for new works, title, status and rating.
 */
@Composable
fun MangaGridCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val imageRequest = remember(manga.coverUrl, manga.id) {
        ImageRequest.Builder(context)
            .data(manga.coverUrl.ifBlank { null })
            .memoryCacheKey(manga.coverUrl.ifBlank { manga.id })
            .diskCacheKey(manga.coverUrl.ifBlank { manga.id })
            .crossfade(true)
            .size(200, 280)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .placeholder(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .error(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .build()
    }

    val titleText = remember(manga.titleArabic, manga.title) {
        manga.titleArabic.ifEmpty { manga.title }
    }

    val displayRating = remember(manga.rating) {
        if (manga.rating > 0) String.format(java.util.Locale.US, "%.1f", manga.rating) else "8.0"
    }

    val isCompleted = remember(manga.status) {
        manga.status.contains("منتهي") || manga.status.contains("Completed", ignoreCase = true)
    }
    val statusText = if (isCompleted) "منتهية" else "مستمرة"
    val statusColor = if (isCompleted) Color(0xFFF87171) else Color(0xFF4ADE80)

    val isNewWork = remember(manga.isNew, manga.latestChapter, manga.totalChapters) {
        val chapNum = Regex("""\d+(\.\d+)?""").find(manga.latestChapter)?.value
        val isFirstChapter = chapNum == "1" || chapNum == "01" || chapNum == "1.0"
        (manga.isNew && isFirstChapter) || (manga.totalChapters <= 1 && isFirstChapter)
    }

    val formattedLatestChapter = remember(manga.latestChapter) {
        when {
            manga.latestChapter.isBlank() -> "الفصل 1"
            manga.latestChapter.startsWith("الفصل") || manga.latestChapter.startsWith("فصل") -> manga.latestChapter
            manga.latestChapter.matches(Regex("""^\d+(\.\d+)?$""")) -> "الفصل ${manga.latestChapter}"
            else -> {
                val num = Regex("""\d+(\.\d+)?""").find(manga.latestChapter)?.value
                if (num != null) "الفصل $num" else manga.latestChapter
            }
        }
    }

    // Infinite animation for NEW works badge & aura
    val infiniteTransition = rememberInfiniteTransition(label = "new_work_anim_${manga.id}")
    val badgeScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "badge_scale"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = androidx.compose.animation.core.spring(stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
        label = "card_scale"
    )

    val clickModifier = remember(manga, onClick, interactionSource) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null
        ) { onClick(manga) }
    }

    val cardBg = MaterialTheme.colorScheme.surface
    val imageBg = MaterialTheme.colorScheme.surfaceVariant
    val borderColor = if (isNewWork) {
        MangaRedPrimary.copy(alpha = 0.6f * glowAlpha)
    } else {
        MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
    }
    val titleColor = MaterialTheme.colorScheme.onSurface

    Column(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CardShape)
            .background(cardBg)
            .border(
                width = if (isNewWork) 1.5.dp else 1.dp,
                color = borderColor,
                shape = CardShape
            )
            .then(clickModifier)
            .padding(5.dp)
            .testTag("manga_grid_card_${manga.id}"),
        horizontalAlignment = Alignment.Start
    ) {
        // Cover Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(ImageShape)
                .background(imageBg)
        ) {
            if (manga.coverUrl.isNotBlank()) {
                AsyncImage(
                    model = imageRequest,
                    contentDescription = titleText,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                    contentDescription = null,
                    tint = MangaRedPrimary.copy(alpha = 0.7f),
                    modifier = Modifier
                        .size(24.dp)
                        .align(Alignment.Center)
                )
            }

            // Dark subtle vignette gradient at the bottom of cover for high contrast
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color(0xD90E0B16))
                        )
                    )
            )

            // Prominent Latest Chapter Pill Badge at bottom-start of cover
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xF01D152C),
                                Color(0xF02B1944)
                            )
                        )
                    )
                    .border(
                        width = 0.8.dp,
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                MangaRedPrimary.copy(alpha = 0.8f),
                                MangaGold.copy(alpha = 0.6f)
                            )
                        ),
                        shape = RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.5.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Icon(
                        imageVector = if (isNewWork) Icons.Default.AutoAwesome else Icons.Default.Bolt,
                        contentDescription = null,
                        tint = if (isNewWork) MangaGold else MangaRedPrimary,
                        modifier = Modifier.size(10.dp)
                    )
                    Text(
                        text = formattedLatestChapter,
                        fontSize = 9.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        maxLines = 1
                    )
                }
            }

            // Animated Luxurious "جديد ✨" Badge at top-end
            if (isNewWork) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .graphicsLayer {
                            scaleX = badgeScale
                            scaleY = badgeScale
                            alpha = glowAlpha
                        }
                        .shadow(elevation = 6.dp, shape = NewBadgeShape, ambientColor = MangaRedPrimary, spotColor = MangaGold)
                        .clip(NewBadgeShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFFF1744),
                                    Color(0xFFD50000),
                                    Color(0xFFFF9100)
                                )
                            )
                        )
                        .border(
                            width = 0.8.dp,
                            color = Color(0xFFFFE57F),
                            shape = NewBadgeShape
                        )
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(9.dp)
                        )
                        Text(
                            text = "جديد",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(5.dp))

        // Title
        Text(
            text = titleText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = titleColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Start,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp)
        )

        Spacer(modifier = Modifier.height(3.dp))

        // Status + Rating Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Text(
                    text = statusText,
                    color = statusColor,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = MangaGold,
                    modifier = Modifier.size(10.5.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = displayRating,
                    color = MangaGold,
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Detailed List View Card:
 * Features prominent chapter info, animated NEW badge, genre tags, status, and rating.
 */
@Composable
fun MangaListCard(
    manga: MangaItem,
    onClick: (MangaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val imageRequest = remember(manga.coverUrl, manga.id) {
        ImageRequest.Builder(context)
            .data(manga.coverUrl.ifBlank { null })
            .memoryCacheKey(manga.coverUrl.ifBlank { manga.id })
            .diskCacheKey(manga.coverUrl.ifBlank { manga.id })
            .crossfade(true)
            .size(164, 230)
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .placeholder(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .error(android.graphics.drawable.ColorDrawable(android.graphics.Color.parseColor("#1E1E1E")))
            .build()
    }

    val isNewWork = remember(manga.isNew, manga.latestChapter, manga.totalChapters) {
        val chapNum = Regex("""\d+(\.\d+)?""").find(manga.latestChapter)?.value
        val isFirstChapter = chapNum == "1" || chapNum == "01" || chapNum == "1.0"
        (manga.isNew && isFirstChapter) || (manga.totalChapters <= 1 && isFirstChapter)
    }

    val formattedLatestChapter = remember(manga.latestChapter) {
        when {
            manga.latestChapter.isBlank() -> "الفصل 1"
            manga.latestChapter.startsWith("الفصل") || manga.latestChapter.startsWith("فصل") -> manga.latestChapter
            manga.latestChapter.matches(Regex("""^\d+(\.\d+)?$""")) -> "الفصل ${manga.latestChapter}"
            else -> {
                val num = Regex("""\d+(\.\d+)?""").find(manga.latestChapter)?.value
                if (num != null) "الفصل $num" else manga.latestChapter
            }
        }
    }

    val titleText = remember(manga.titleArabic, manga.title) {
        manga.titleArabic.ifEmpty { manga.title }
    }

    val displayRating = remember(manga.rating) {
        String.format(java.util.Locale.US, "%.1f", manga.rating)
    }

    val isCompleted = remember(manga.status) {
        manga.status.contains("منتهي") || manga.status.contains("Completed", ignoreCase = true)
    }
    val statusText = if (isCompleted) "منتهية" else "مستمرة"
    val statusColor = if (isCompleted) Color(0xFFF87171) else Color(0xFF4ADE80)

    val genresText = remember(manga.genres) {
        if (manga.genres.isNotEmpty()) manga.genres.take(3).joinToString(" • ") else "مانهوا • أكشن"
    }

    val infiniteTransition = rememberInfiniteTransition(label = "list_new_anim_${manga.id}")
    val badgeScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "list_badge_scale"
    )

    val interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.97f else 1f,
        animationSpec = androidx.compose.animation.core.spring(stiffness = androidx.compose.animation.core.Spring.StiffnessMediumLow),
        label = "list_card_scale"
    )

    val clickModifier = remember(manga, onClick, interactionSource) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null
        ) { onClick(manga) }
    }

    val cardBg = MaterialTheme.colorScheme.surface
    val imageBg = MaterialTheme.colorScheme.surfaceVariant
    val borderColor = if (isNewWork) MangaRedPrimary.copy(alpha = 0.5f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
    val titleColor = MaterialTheme.colorScheme.onSurface
    val subtitleColor = MaterialTheme.colorScheme.onSurfaceVariant

    Box(
        modifier = modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(CardShape)
            .background(cardBg)
            .then(clickModifier)
            .border(1.dp, borderColor, CardShape)
            .padding(8.dp)
            .testTag("manga_list_card_${manga.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Cover Image Box
            Box(
                modifier = Modifier
                    .width(84.dp)
                    .height(118.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(imageBg)
            ) {
                if (manga.coverUrl.isNotBlank()) {
                    AsyncImage(
                        model = imageRequest,
                        contentDescription = titleText,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = null,
                        tint = MangaRedPrimary,
                        modifier = Modifier
                            .size(28.dp)
                            .align(Alignment.Center)
                    )
                }

                if (isNewWork) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(3.dp)
                            .graphicsLayer {
                                scaleX = badgeScale
                                scaleY = badgeScale
                            }
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(Color(0xFFFF1744), Color(0xFFFF9100))
                                )
                            )
                            .padding(horizontal = 4.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "جديد ✨",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Information Column
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Title
                Text(
                    text = titleText,
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = titleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Prominent Latest Chapter Pill
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF261D3A))
                            .border(0.8.dp, MangaRedPrimary.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = if (isNewWork) Icons.Default.AutoAwesome else Icons.Default.Bolt,
                                contentDescription = null,
                                tint = if (isNewWork) MangaGold else MangaRedPrimary,
                                modifier = Modifier.size(11.dp)
                            )
                            Text(
                                text = formattedLatestChapter,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    if (manga.latestReleaseTime.isNotBlank()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = subtitleColor,
                                modifier = Modifier.size(10.dp)
                            )
                            Text(
                                text = manga.latestReleaseTime,
                                fontSize = 10.sp,
                                color = subtitleColor
                            )
                        }
                    }
                }

                // Categories / Genres
                Text(
                    text = genresText,
                    fontSize = 10.5.sp,
                    color = subtitleColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                // Status & Rating Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(statusColor)
                        )
                        Text(
                            text = statusText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = statusColor
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = MangaGold,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = displayRating,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = MangaGold
                        )
                    }
                }
            }
        }
    }
}


