package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.MangaItem
import com.example.ui.components.AppTopBar
import com.example.ui.components.MangaCard
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextSecondary

import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import coil.imageLoader
import coil.request.ImageRequest

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.snapshotFlow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    latestUpdates: List<MangaItem>,
    searchResults: List<MangaItem> = emptyList(),
    selectedGenre: String?,
    isOnline: Boolean = true,
    isLoadingHome: Boolean = false,
    isLoadingMore: Boolean = false,
    isSearching: Boolean = false,
    isListView: Boolean = false,
    searchQuery: String = "",
    isSearchMode: Boolean = false,
    onGenreSelected: (String) -> Unit,
    onMangaClick: (MangaItem) -> Unit,
    onOpenDrawer: () -> Unit,
    onToggleViewMode: () -> Unit,
    onOpenSearch: () -> Unit,
    onCloseSearch: () -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onLoadNextPage: () -> Unit = {},
    onRefresh: () -> Unit = {}
) {
    val genres = listOf("الكل", "أكشن", "مانهوا", "إيسيكاي", "مغامرة", "خيال", "كوميديا", "دراما")
    val context = androidx.compose.ui.platform.LocalContext.current
    val gridState = rememberLazyGridState()

    val filteredMangas = latestUpdates

    val scrollState = rememberScrollState()

    // Smooth prefetching listener when user reaches 6 items before bottom
    val shouldLoadNextPage by androidx.compose.runtime.remember(gridState, filteredMangas.size, searchQuery) {
        androidx.compose.runtime.derivedStateOf {
            val total = filteredMangas.size
            val visible = gridState.layoutInfo.visibleItemsInfo.size
            val firstIndex = gridState.firstVisibleItemIndex
            total > 0 && (firstIndex + visible) >= total - 6 && searchQuery.isBlank()
        }
    }

    LaunchedEffect(shouldLoadNextPage) {
        if (shouldLoadNextPage) {
            onLoadNextPage()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(androidx.compose.material3.MaterialTheme.colorScheme.background)
    ) {
        // Red App Top Bar
        AppTopBar(
            title = if (isSearchMode) "" else (if (selectedGenre.isNullOrBlank() || selectedGenre == "الكل") "آخر التحديثات" else selectedGenre),
            isListView = isListView,
            isSearchMode = isSearchMode,
            searchQuery = searchQuery,
            onOpenDrawer = onOpenDrawer,
            onToggleViewMode = onToggleViewMode,
            onOpenSearch = onOpenSearch,
            onCloseSearch = onCloseSearch,
            onSearchQueryChange = onSearchQueryChange
        )

        // Offline Banner Alert
        if (!isOnline) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MangaGold.copy(alpha = 0.15f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.WifiOff,
                    contentDescription = null,
                    tint = MangaGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.size(8.dp))
                Text(
                    text = "يرجى الاتصال بالإنترنت لتصفح التحديثات المباشرة. يمكنك قراءة الفصول المحملة.",
                    fontSize = 12.sp,
                    color = MangaGold,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        val pullRefreshState = androidx.compose.material3.pulltorefresh.rememberPullToRefreshState()
        val gridAlpha by animateFloatAsState(
            targetValue = if (isLoadingHome && filteredMangas.isNotEmpty()) 0.7f else 1f,
            animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
            label = "refresh_grid_alpha"
        )
        val gridScale by animateFloatAsState(
            targetValue = if (isLoadingHome && filteredMangas.isNotEmpty()) 0.985f else 1f,
            animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
            label = "refresh_grid_scale"
        )

        PullToRefreshBox(
            isRefreshing = isLoadingHome,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize(),
            state = pullRefreshState,
            indicator = {
                com.example.ui.components.AnimePullToRefreshIndicator(
                    state = pullRefreshState,
                    isRefreshing = isLoadingHome,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        ) {
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(if (isListView) 1 else 3),
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        alpha = gridAlpha
                        scaleX = gridScale
                        scaleY = gridScale
                    },
                contentPadding = PaddingValues(start = 6.dp, end = 6.dp, top = 8.dp, bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    // Genre Filter Chips (Flat Row with horizontalScroll)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(scrollState)
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        genres.forEach { genre ->
                            val isSelected = (selectedGenre == genre) || (selectedGenre == null && genre == "الكل")
                            val chipBg = if (isSelected) MangaRedPrimary else androidx.compose.material3.MaterialTheme.colorScheme.surface
                            val chipTextColor = if (isSelected) Color.White else androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant
                            val chipBorder = if (isSelected) Color.Transparent else androidx.compose.material3.MaterialTheme.colorScheme.outline
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(chipBg)
                                    .border(1.dp, chipBorder.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                    .clickable { onGenreSelected(genre) }
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                                    .testTag("genre_chip_$genre")
                            ) {
                                Text(
                                    text = genre,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = chipTextColor
                                )
                            }
                        }
                    }
                }

                if ((isLoadingHome || isSearching) && filteredMangas.isEmpty()) {
                    items(
                        count = 9,
                        key = { "skeleton_$it" },
                        contentType = { "skeleton" }
                    ) {
                        if (isListView) {
                            com.example.ui.components.MangaListCardSkeleton()
                        } else {
                            com.example.ui.components.MangaGridCardSkeleton()
                        }
                    }
                } else if (filteredMangas.isEmpty()) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (searchQuery.isNotBlank()) "لا توجد نتائج مطابقة للبحث" else "لا توجد نتائج مطابقة",
                                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    items(
                        items = filteredMangas,
                        key = { it.id },
                        contentType = { "manga_card" }
                    ) { item ->
                        MangaCard(
                            manga = item,
                            onClick = onMangaClick,
                            isListView = isListView
                        )
                    }

                    if (isLoadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                CircularProgressIndicator(color = MangaRedPrimary, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
