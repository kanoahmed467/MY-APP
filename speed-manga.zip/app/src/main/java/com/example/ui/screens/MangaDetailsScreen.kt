package com.example.ui.screens
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.filled.Deselect

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import com.example.ui.components.ChapterExportDialog
import com.example.ui.components.MangaCard
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Comment
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.DownloadForOffline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.local.DownloadedChapterEntity
import com.example.data.models.ChapterItem
import com.example.data.models.DownloadQuality
import com.example.data.models.LibraryCategory
import com.example.data.models.MangaItem
import com.example.data.models.UserComment
import com.example.data.network.MadaraScraper
import com.example.ui.components.DownloadQualityDialog
import com.example.ui.theme.MangaGold
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextMuted
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun MangaDetailsScreen(
    manga: MangaItem,
    chapters: List<ChapterItem>,
    comments: List<UserComment>,
    isFavorite: Boolean,
    isLoadingDetails: Boolean = false,
    isDownloadedMode: Boolean = false,
    downloadedChapters: List<DownloadedChapterEntity> = emptyList(),
    downloadProgressMap: Map<String, Float> = emptyMap(),
    defaultDownloadQuality: String = "HIGH",
    onBackClick: () -> Unit,
    onChapterClick: (ChapterItem) -> Unit,
    onDownloadChapter: (ChapterItem, DownloadQuality) -> Unit = { _, _ -> },
    onDownloadAllChapters: (List<ChapterItem>, DownloadQuality) -> Unit = { _, _ -> },
    onDeleteDownloadedChapter: (String, String) -> Unit = { _, _ -> },
    onOpenDownloadedChapter: (DownloadedChapterEntity) -> Unit = {},
    onToggleFavorite: (MangaItem, LibraryCategory) -> Unit,
    onPostComment: (String, String) -> Unit,
    onLikeComment: (String, Int, Boolean) -> Unit,
    onOpenCloudflare: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Details, 1: Chapters, 2: Statistics
    var isReversedSort by remember { mutableStateOf(false) }
    var showMyListBottomSheet by remember { mutableStateOf(false) }
    var showImageFullscreen by remember { mutableStateOf(false) }
    var commentText by remember { mutableStateOf("") }
    var userNameText by remember { mutableStateOf("") }

    // Instant Optimistic Favorite State & Spring Animation
    var localFavorite by remember(isFavorite) { mutableStateOf(isFavorite) }
    var heartClicked by remember { mutableStateOf(false) }

    val heartScale by animateFloatAsState(
        targetValue = if (heartClicked) 1.45f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        finishedListener = { heartClicked = false },
        label = "heartScale"
    )

    LaunchedEffect(isFavorite) {
        localFavorite = isFavorite
    }

    var screenEntered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        screenEntered = true
    }
    val contentAlpha by animateFloatAsState(
        targetValue = if (screenEntered) 1f else 0f,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "contentAlpha"
    )
    val contentOffsetY by animateFloatAsState(
        targetValue = if (screenEntered) 0f else 30f,
        animationSpec = tween(400, easing = FastOutSlowInEasing),
        label = "contentOffsetY"
    )

    val startReadingInteraction = remember { MutableInteractionSource() }
    val startReadingScale = rememberPressedScale(startReadingInteraction)

    val myListInteraction = remember { MutableInteractionSource() }
    val myListScale = rememberPressedScale(myListInteraction)

    // Pager state for smooth horizontal tab swiping
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 3 })
    val activeTab = pagerState.currentPage

    val detailsListState = rememberLazyListState()
    val chaptersListState = rememberLazyListState()
    val statisticsListState = rememberLazyListState()

    var readChapterIds by remember { mutableStateOf(setOf<String>()) }
    var selectedChapterForDownload by remember { mutableStateOf<ChapterItem?>(null) }
    var showDownloadAllQualityDialog by remember { mutableStateOf(false) }

    var isSelectionMode by remember { mutableStateOf(false) }
    var selectedChapterIds by remember { mutableStateOf(setOf<String>()) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportTargetChapters by remember { mutableStateOf<List<ChapterItem>>(emptyList()) }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val effectiveChapters = remember(chapters, downloadedChapters, manga.id, isDownloadedMode) {
        if (isDownloadedMode) {
            downloadedChapters
                .filter { it.mangaId == manga.id }
                .map { entity ->
                    val num = Regex("""\d+(\.\d+)?""").find(entity.chapterTitle)?.value?.toFloatOrNull()
                        ?: entity.chapterTitle.replace(Regex("[^0-9.]"), "").toFloatOrNull() ?: 1.0f
                    ChapterItem(
                        id = entity.chapterId,
                        mangaId = entity.mangaId,
                        chapterNumber = num,
                        title = entity.chapterTitle,
                        releaseDate = "محمّل أوفلاين",
                        pages = entity.localPagePathsJson.split(",").filter { it.isNotBlank() },
                        url = ""
                    )
                }
                .sortedBy { it.chapterNumber }
        } else if (chapters.isNotEmpty()) {
            chapters
        } else {
            downloadedChapters
                .filter { it.mangaId == manga.id }
                .map { entity ->
                    val num = Regex("""\d+(\.\d+)?""").find(entity.chapterTitle)?.value?.toFloatOrNull()
                        ?: entity.chapterTitle.replace(Regex("[^0-9.]"), "").toFloatOrNull() ?: 1.0f
                    ChapterItem(
                        id = entity.chapterId,
                        mangaId = entity.mangaId,
                        chapterNumber = num,
                        title = entity.chapterTitle,
                        releaseDate = "محمّل أوفلاين",
                        pages = entity.localPagePathsJson.split(",").filter { it.isNotBlank() },
                        url = ""
                    )
                }
                .sortedBy { it.chapterNumber }
        }
    }

    val sortedChapters = remember(effectiveChapters, isReversedSort) {
        if (isReversedSort) effectiveChapters.reversed() else effectiveChapters
    }

    val downloadedChapterIds = remember(downloadedChapters) {
        downloadedChapters.map { it.chapterId }.toSet()
    }

    val coverRequest = remember(manga.coverUrl) {
        ImageRequest.Builder(context)
            .data(manga.coverUrl.ifBlank { null })
            .addHeader("User-Agent", MadaraScraper.userAgent)
            .addHeader("Referer", "https://mangalik.net/")
            .apply {
                if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                    addHeader("Cookie", MadaraScraper.cloudflareCookies)
                }
            }
            .memoryCachePolicy(CachePolicy.ENABLED)
            .diskCachePolicy(CachePolicy.ENABLED)
            .crossfade(true)
            .build()
    }

    if (selectedChapterForDownload != null) {
        DownloadQualityDialog(
            chapter = selectedChapterForDownload!!,
            onDismiss = { selectedChapterForDownload = null },
            onConfirmDownload = { quality ->
                onDownloadChapter(selectedChapterForDownload!!, quality)
                selectedChapterForDownload = null
            }
        )
    }

    if (showDownloadAllQualityDialog) {
        DownloadQualityDialog(
            chapter = ChapterItem(
                id = "all",
                mangaId = manga.id,
                chapterNumber = 0f,
                title = "تحميل جميع الفصول (${effectiveChapters.size} فصل)",
                releaseDate = "تنزيل كامل المانجا"
            ),
            onDismiss = { showDownloadAllQualityDialog = false },
            onConfirmDownload = { quality ->
                onDownloadAllChapters(effectiveChapters, quality)
                showDownloadAllQualityDialog = false
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = contentAlpha
                    translationY = contentOffsetY * density
                }
        ) {
            AnimatedContent(
                targetState = isSelectionMode,
                transitionSpec = {
                    fadeIn(tween(300)) togetherWith fadeOut(tween(300))
                },
                label = "topBarTransition"
            ) { selectionActive ->
                if (selectionActive) {
                    // Contextual Action Bar for Selection Mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MangaRedPrimary)
                            .statusBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                isSelectionMode = false
                                selectedChapterIds = emptySet()
                            },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "إلغاء التحديد",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Text(
                            text = "${selectedChapterIds.size}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.weight(1f)
                        )

                        val allIds = effectiveChapters.map { it.id }.toSet()
                        val isAllSelected = selectedChapterIds.size == allIds.size && allIds.isNotEmpty()

                        IconButton(
                            onClick = {
                                selectedChapterIds = if (isAllSelected) emptySet() else allIds
                            },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = if (isAllSelected) Icons.Default.Deselect else Icons.Default.SelectAll,
                                contentDescription = "تحديد الكل",
                                tint = Color.White
                            )
                        }

                        if (isDownloadedMode) {
                            IconButton(
                                onClick = { if (selectedChapterIds.isNotEmpty()) showDeleteConfirmDialog = true },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف الفصول",
                                    tint = Color.White
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    val selectedList = chapters.filter { it.id in selectedChapterIds }
                                    if (selectedList.isNotEmpty()) {
                                        exportTargetChapters = selectedList
                                        showExportDialog = true
                                    }
                                },
                                modifier = Modifier.size(38.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SaveAlt,
                                    contentDescription = "حفظ بالهاتف",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                } else {
                    // Standard Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface)
                            .statusBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = manga.titleArabic.ifEmpty { manga.title },
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                coroutineScope.launch {
                                    pagerState.animateScrollToPage(0)
                                }
                            },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Comment,
                                    contentDescription = "التعليقات",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                heartClicked = true
                                val newState = !localFavorite
                                localFavorite = newState
                                onToggleFavorite(manga, LibraryCategory.FAVORITE)
                                val msg = if (newState) "تمت الإضافة للمفضلة ❤️" else "تمت الإزالة من المفضلة 💔"
                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .graphicsLayer(scaleX = heartScale, scaleY = heartScale)
                        ) {
                            Icon(
                                imageVector = if (localFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                contentDescription = "المفضلة",
                                tint = if (localFavorite) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // Top Navigation Tabs Row (التفاصيل | الفصول | إحصائيات)
            TabRow(
                selectedTabIndex = activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                indicator = { tabPositions ->
                    if (activeTab < tabPositions.size) {
                        TabRowDefaults.Indicator(
                            Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                            color = MangaRedPrimary,
                            height = 3.dp
                        )
                    }
                }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = {
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(0)
                        }
                    },
                    text = {
                        Text(
                            text = "التفاصيل",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (activeTab == 0) MangaRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )

                Tab(
                    selected = activeTab == 1,
                    onClick = {
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(1)
                        }
                    },
                    text = {
                        Text(
                            text = "الفصول (${effectiveChapters.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (activeTab == 1) MangaRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )

                Tab(
                    selected = activeTab == 2,
                    onClick = {
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(2)
                        }
                    },
                    text = {
                        Text(
                            text = "إحصائيات",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = if (activeTab == 2) MangaRedPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
            }

            // Screen Content using HorizontalPager for smooth horizontal swiping
            Box(modifier = Modifier.weight(1f)) {
                HorizontalPager(
                    state = pagerState,
                    beyondViewportPageCount = 2,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    if (isLoadingDetails && effectiveChapters.isEmpty()) {
                        when (page) {
                            0 -> DetailsTabSkeleton()
                            1 -> ChaptersTabSkeleton()
                            2 -> DetailsTabSkeleton()
                        }
                    } else {
                        when (page) {
                            0 -> DetailsTabContent(
                                manga = manga,
                                isFavorite = localFavorite,
                                coverRequest = coverRequest,
                                listState = detailsListState,
                                onStartReading = {
                                    if (effectiveChapters.isNotEmpty()) {
                                        onChapterClick(effectiveChapters.first())
                                    }
                                },
                                onOpenMyListSheet = { showMyListBottomSheet = true },
                                onCoverClick = { showImageFullscreen = true },
                                onCopyTitle = {
                                    clipboardManager.setText(AnnotatedString(manga.titleArabic.ifEmpty { manga.title }))
                                    Toast.makeText(context, "تم نسخ اسم المانجا بنجاح 📋", Toast.LENGTH_SHORT).show()
                                }
                            )

                            1 -> ChaptersTabContent(
                                mangaTitle = manga.titleArabic.ifEmpty { manga.title },
                                chapters = sortedChapters,
                                isLoading = isLoadingDetails,
                                isReversedSort = isReversedSort,
                                downloadedChapterIds = downloadedChapterIds,
                                downloadProgressMap = downloadProgressMap,
                                readChapterIds = readChapterIds,
                                listState = chaptersListState,
                                isSelectionMode = isSelectionMode,
                                selectedChapterIds = selectedChapterIds,
                                onSelectionModeChange = { isSelectionMode = it },
                                onSelectedChapterIdsChange = { selectedChapterIds = it },
                                onToggleSort = { isReversedSort = !isReversedSort },
                                onChapterClick = { ch ->
                                    readChapterIds = readChapterIds + ch.id
                                    onChapterClick(ch)
                                },
                                onToggleReadChapter = { chId ->
                                    readChapterIds = if (readChapterIds.contains(chId)) {
                                        readChapterIds - chId
                                    } else {
                                        readChapterIds + chId
                                    }
                                },
                                onDownloadChapter = { ch ->
                                    val resolvedQuality = when (defaultDownloadQuality) {
                                        "MEDIUM" -> DownloadQuality.MEDIUM
                                        "LOW" -> DownloadQuality.LOW
                                        else -> DownloadQuality.HIGH
                                    }
                                    onDownloadChapter(ch, resolvedQuality)
                                    android.widget.Toast.makeText(context, "بدء تنزيل ${ch.title}", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                onDownloadAllClick = {
                                    val resolvedQuality = when (defaultDownloadQuality) {
                                        "MEDIUM" -> DownloadQuality.MEDIUM
                                        "LOW" -> DownloadQuality.LOW
                                        else -> DownloadQuality.HIGH
                                    }
                                    onDownloadAllChapters(effectiveChapters, resolvedQuality)
                                    android.widget.Toast.makeText(context, "بدء تنزيل جميع الفصول (${effectiveChapters.size} فصل)", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                onDeleteChapters = { chapterIdsToDelete ->
                                    chapterIdsToDelete.forEach { chId ->
                                        onDeleteDownloadedChapter(manga.id, chId)
                                    }
                                }
                            )

                            2 -> StatisticsTabContent(
                                manga = manga,
                                chaptersCount = effectiveChapters.size,
                                listState = statisticsListState
                            )
                        }
                    }
                }
            }
        }

        // Floating Red "ابداء القراءة" FAB button on Chapters tab with entrance animation
        AnimatedVisibility(
            visible = activeTab == 1 && effectiveChapters.isNotEmpty(),
            enter = fadeIn(tween(200)) + scaleIn(tween(200)),
            exit = fadeOut(tween(150)) + scaleOut(tween(150)),
            modifier = Modifier.align(Alignment.BottomEnd)
        ) {
            Box(
                modifier = Modifier
                    .padding(bottom = 24.dp, end = 20.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(MangaRedPrimary)
                    .clickable { onChapterClick(effectiveChapters.first()) }
                    .padding(horizontal = 22.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ابداء القراءة",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet for "قائمتي" (My List Categories)
    if (showMyListBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMyListBottomSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "قائمتي",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    IconButton(onClick = { showMyListBottomSheet = false }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = TextMuted
                        )
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 10.dp))

                val categories = listOf(
                    Triple(LibraryCategory.READING, "اشاهدها حاليا", Icons.Default.PlayCircleFilled),
                    Triple(LibraryCategory.PLAN_TO_READ, "ارغب بمشاهدتها", Icons.AutoMirrored.Filled.List),
                    Triple(LibraryCategory.COMPLETED, "تم مشاهدتها", Icons.Default.CheckCircle),
                    Triple(LibraryCategory.FAVORITE, "لا ارغب بمشاهدتها", Icons.Default.Cancel)
                )

                categories.forEach { (cat, label, icon) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onToggleFavorite(manga, cat)
                                showMyListBottomSheet = false
                                Toast.makeText(context, "تم حفظ العمل في: $label", Toast.LENGTH_SHORT).show()
                            }
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = MangaRedPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = label,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    // Fullscreen High-Res Cover Image Viewer Dialog with Glass Transparency & Save Button
    if (showImageFullscreen) {
        Dialog(
            onDismissRequest = { showImageFullscreen = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.68f))
                    .clickable { showImageFullscreen = false },
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.88f)
                            .aspectRatio(3f / 4.2f)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.90f))
                            .clickable(enabled = false) {}
                    ) {
                        AsyncImage(
                            model = coverRequest,
                            contentDescription = manga.titleArabic,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Glass Close Button
                        OutlinedButton(
                            onClick = { showImageFullscreen = false },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "إغلاق",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        // Save Image Button
                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    saveImageToStorage(context, manga.coverUrl, manga.titleArabic)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "حفظ الصورة",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun DetailsTabContent(
    manga: MangaItem,
    isFavorite: Boolean,
    coverRequest: ImageRequest,
    listState: LazyListState,
    onStartReading: () -> Unit,
    onOpenMyListSheet: () -> Unit,
    onCoverClick: () -> Unit,
    onCopyTitle: () -> Unit
) {
    val startReadingInteraction = remember { MutableInteractionSource() }
    val startReadingScale = rememberPressedScale(startReadingInteraction)

    val myListInteraction = remember { MutableInteractionSource() }
    val myListScale = rememberPressedScale(myListInteraction)

    var isSynopsisExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            // Main Banner & Info Card Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                // Background Blurred Poster Preview
                AsyncImage(
                    model = coverRequest,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = 0.35f },
                    contentScale = ContentScale.Crop
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .align(Alignment.BottomStart),
                    verticalAlignment = Alignment.Bottom
                ) {
                    // Cover Image Box
                    Box(
                        modifier = Modifier
                            .width(105.dp)
                            .height(150.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                            .clickable { onCoverClick() }
                    ) {
                        AsyncImage(
                            model = coverRequest,
                            contentDescription = manga.titleArabic,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    // Title & Quick Metadata
                    Column(
                        modifier = Modifier.weight(1f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { onCopyTitle() }
                        ) {
                            Text(
                                text = manga.titleArabic.ifEmpty { manga.title },
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "نسخ الاسم",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "الكاتب: ${manga.author.ifEmpty { "مؤلف مانجا ليك" }}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Updating OnGoing",
                                fontSize = 11.sp,
                                color = Color(0xFFEAB308),
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = MangaGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = "${manga.rating} / 4.8",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MangaGold
                            )
                        }
                    }
                }
            }
        }

        // Quick Action Buttons Row (ابدأ القراءة الان + أضف لقائمتي)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Red "ابدأ القراءة الان" Button
                Button(
                    onClick = onStartReading,
                    interactionSource = startReadingInteraction,
                    colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.8f)
                        .height(44.dp)
                        .graphicsLayer {
                            scaleX = startReadingScale
                            scaleY = startReadingScale
                        }
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ابدأ القراءة الان",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Dark "+ أضف لقائمتي" Button
                Button(
                    onClick = onOpenMyListSheet,
                    interactionSource = myListInteraction,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(44.dp)
                        .graphicsLayer {
                            scaleX = myListScale
                            scaleY = myListScale
                        }
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Bookmark else Icons.Default.Add,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isFavorite) "في قائمتي" else "أضف لقائمتي",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Categories Chips
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "التصنيفات:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.height(6.dp))

                val genres = manga.genres.ifEmpty { listOf("رومانسى", "شوجو", "فانتزيا", "كوميدى") }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    genres.forEach { genre ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = genre,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // Story Synopsis ("قصة المانجا")
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .animateContentSize(animationSpec = spring(
                        dampingRatio = Spring.DampingRatioLowBouncy,
                        stiffness = Spring.StiffnessLow
                    ))
                    .clickable { isSynopsisExpanded = !isSynopsisExpanded }
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "قصة المانجا",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = manga.summary.ifEmpty {
                        "في يوم من الأيام، في قارة يحكمها التنين الأسود، بدأ تظهر مستحوذات يعكرن صفو السلام. قصص غامضة وأحداث مشوقة تأخذك في رحلة عالم الفنون القتالية والخيال."
                    },
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp,
                    maxLines = if (isSynopsisExpanded) Int.MAX_VALUE else 3,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isSynopsisExpanded) "عرض أقل ▲" else "إقرأ المزيد ▼",
                    fontSize = 11.sp,
                    color = MangaRedPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Extra Info Table
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("مصدر", fontSize = 12.sp, color = TextMuted)
                            Text("غير معروف", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Column {
                            Text("أصل", fontSize = 12.sp, color = TextMuted)
                            Text("كوري", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("عرض من", fontSize = 12.sp, color = TextMuted)
                            Text("?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Column {
                            Text("إلى", fontSize = 12.sp, color = TextMuted)
                            Text("?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChaptersTabContent(
    mangaTitle: String = "",
    chapters: List<ChapterItem>,
    isLoading: Boolean,
    isReversedSort: Boolean,
    downloadedChapterIds: Set<String>,
    downloadProgressMap: Map<String, Float>,
    readChapterIds: Set<String>,
    listState: LazyListState,
    isSelectionMode: Boolean,
    selectedChapterIds: Set<String>,
    onSelectionModeChange: (Boolean) -> Unit,
    onSelectedChapterIdsChange: (Set<String>) -> Unit,
    onToggleSort: () -> Unit,
    onChapterClick: (ChapterItem) -> Unit,
    onToggleReadChapter: (String) -> Unit,
    onDownloadChapter: (ChapterItem) -> Unit,
    onDownloadAllClick: () -> Unit,
    onDeleteChapters: (List<String>) -> Unit
) {
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportTargetChapters by remember { mutableStateOf<List<ChapterItem>>(emptyList()) }
    val context = LocalContext.current

    if (showExportDialog && exportTargetChapters.isNotEmpty()) {
        ChapterExportDialog(
            mangaTitle = mangaTitle.ifEmpty { "Manga" },
            chapters = exportTargetChapters,
            onDismiss = { showExportDialog = false }
        )
    }

    // Confirmation Dialog
    if (showDeleteConfirmDialog) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = null,
                        tint = MangaRedPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "حذف الفصول المحددة",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            },
            text = {
                Text(
                    text = "هل أنت تأكد من حذف ${selectedChapterIds.size} فصل/فصول محملة من هذا الجهاز؟",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val toDelete = selectedChapterIds.toList()
                        onDeleteChapters(toDelete)
                        Toast.makeText(context, "تم حذف ${toDelete.size} فصل بنجاح 🗑️", Toast.LENGTH_SHORT).show()
                        onSelectedChapterIdsChange(emptySet())
                        onSelectionModeChange(false)
                        showDeleteConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("حذف الآن", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = { showDeleteConfirmDialog = false }
                ) {
                    Text("إلغاء", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Top Toolbar inside chapters tab
        item {
            AnimatedVisibility(
                visible = !isSelectionMode,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "جميع الفصول المتاحة (${chapters.size})",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (chapters.isNotEmpty()) {
                            Surface(
                                onClick = onDownloadAllClick,
                                shape = RoundedCornerShape(8.dp),
                                color = MangaRedPrimary.copy(alpha = 0.15f),
                                border = BorderStroke(0.5.dp, MangaRedPrimary.copy(alpha = 0.4f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DownloadForOffline,
                                        contentDescription = "تحميل الكل",
                                        tint = MangaRedPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "تحميل الكل",
                                        fontSize = 12.sp,
                                        color = MangaRedPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Surface(
                            onClick = onToggleSort,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SwapVert,
                                    contentDescription = "ترتيب",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (isReversedSort) "تصاعدي" else "تنازلي",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isLoading) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = MangaRedPrimary, strokeWidth = 3.dp)
                }
            }
        }

        items(
            items = chapters,
            key = { ch -> ch.id },
            contentType = { "chapter_row" }
        ) { chapter ->
            val isDownloaded = downloadedChapterIds.contains(chapter.id)
            val isRead = readChapterIds.contains(chapter.id)
            val progress = downloadProgressMap[chapter.id]
            val isSelected = selectedChapterIds.contains(chapter.id)

            ChapterRowItem(
                chapter = chapter,
                isDownloaded = isDownloaded,
                isRead = isRead,
                progress = progress,
                isSelectionMode = isSelectionMode,
                isSelected = isSelected,
                onChapterClick = { ch ->
                    if (isSelectionMode) {
                        onSelectedChapterIdsChange(if (isSelected) selectedChapterIds - ch.id else selectedChapterIds + ch.id)
                        if (selectedChapterIds.isEmpty()) onSelectionModeChange(false)
                    } else {
                        onChapterClick(ch)
                    }
                },
                onChapterLongClick = { ch ->
                    if (!isSelectionMode) {
                        onSelectionModeChange(true)
                        onSelectedChapterIdsChange(setOf(ch.id))
                    } else {
                        onSelectedChapterIdsChange(if (isSelected) selectedChapterIds - ch.id else selectedChapterIds + ch.id)
                        if (selectedChapterIds.isEmpty()) onSelectionModeChange(false)
                    }
                },
                onToggleRead = { onToggleReadChapter(chapter.id) },
                onDownloadChapter = onDownloadChapter,
                onExportChapter = { ch ->
                    exportTargetChapters = listOf(ch)
                    showExportDialog = true
                }
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChapterRowItem(
    chapter: ChapterItem,
    isDownloaded: Boolean,
    isRead: Boolean,
    progress: Float?,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onChapterClick: (ChapterItem) -> Unit,
    onChapterLongClick: (ChapterItem) -> Unit,
    onToggleRead: () -> Unit,
    onDownloadChapter: (ChapterItem) -> Unit,
    onExportChapter: (ChapterItem) -> Unit
) {
    val rowInteractionSource = remember { MutableInteractionSource() }
    val rowScale = rememberPressedScale(rowInteractionSource)

    val backgroundColor = when {
        isSelected -> MangaRedPrimary.copy(alpha = 0.20f)
        isRead -> MaterialTheme.colorScheme.surface.copy(alpha = 0.65f)
        else -> MaterialTheme.colorScheme.surface
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = rowScale
                scaleY = rowScale
            }
            .background(backgroundColor)
            .combinedClickable(
                interactionSource = rowInteractionSource,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = { onChapterClick(chapter) },
                onLongClick = { onChapterLongClick(chapter) }
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Selection Checkbox Circle
            AnimatedVisibility(
                visible = isSelectionMode,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Box(
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.surfaceVariant)
                        .border(
                            width = 1.5.dp,
                            color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.outlineVariant,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "محدد",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Text(
                text = chapter.title.ifEmpty { "الفصل-${chapter.chapterNumber.toInt()}" },
                fontSize = 14.sp,
                fontWeight = if (isSelected || !isRead) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) MangaRedPrimary else if (isRead) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!isSelectionMode) {
                    IconButton(
                        onClick = { onToggleRead() },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isRead) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = if (isRead) "تمت القراءة" else "غير مقروء",
                            tint = if (isRead) MangaRedPrimary else TextMuted.copy(alpha = 0.5f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    if (isDownloaded) {
                        IconButton(
                            onClick = { onExportChapter(chapter) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = "حفظ بالهاتف",
                                tint = MangaGold,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        Icon(
                            imageVector = Icons.Default.DownloadDone,
                            contentDescription = "محمّل",
                            tint = MangaGold,
                            modifier = Modifier.size(20.dp)
                        )
                    } else if (progress != null) {
                        CircularProgressIndicator(
                            progress = { progress },
                            color = MangaRedPrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        IconButton(
                            onClick = { onExportChapter(chapter) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SaveAlt,
                                contentDescription = "حفظ بالهاتف",
                                tint = TextMuted.copy(alpha = 0.6f),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { onDownloadChapter(chapter) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "تحميل",
                                tint = TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
        androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)
    }
}

@Composable
private fun StatisticsTabContent(
    manga: MangaItem,
    chaptersCount: Int,
    listState: LazyListState
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp)
    ) {
        // Rating Vote Bars (تصويتات)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تصويتات",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        for (i in 1..10) {
                            val heightFactor = if (i == 10) 0.9f else if (i == 9) 0.3f else 0.05f
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                                modifier = Modifier.fillMaxHeight()
                            ) {
                                if (i == 10) {
                                    Text(
                                        text = "2.00",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextMuted
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .width(14.dp)
                                        .fillMaxHeight(heightFactor)
                                        .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                                        .background(if (i == 10) MangaRedPrimary else MaterialTheme.colorScheme.outlineVariant)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "$i",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Donut Chart for Categories
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(120.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val strokeWidth = 24.dp.toPx()
                            drawArc(
                                color = Color(0xFF7DD3FC),
                                startAngle = 0f,
                                sweepAngle = 200f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            drawArc(
                                color = Color(0xFF4ADE80),
                                startAngle = 200f,
                                sweepAngle = 70f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            drawArc(
                                color = Color(0xFFF87171),
                                startAngle = 270f,
                                sweepAngle = 70f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            drawArc(
                                color = Color(0xFFA855F7),
                                startAngle = 340f,
                                sweepAngle = 20f,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StatLegendItem(color = Color(0xFF7DD3FC), label = "المانجا المفضلة: 76")
                        StatLegendItem(color = Color(0xFF4ADE80), label = "أقرأها حاليا: 26")
                        StatLegendItem(color = Color(0xFFF87171), label = "ارغب بقراءتها: 72")
                        StatLegendItem(color = Color(0xFFA855F7), label = "تم قراءتها: 3")
                        StatLegendItem(color = Color(0xFFEC4899), label = "لا ارغب بقراءتها: 4")
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Average Ratings breakdown
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "متوسط تقييم القصة، الشخصيات، والرسم",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        RatingStatBox(title = "القصة", score = "9.50")
                        RatingStatBox(title = "الشخصيات", score = "9.20")
                        RatingStatBox(title = "الرسم", score = "9.80")
                    }
                }
            }
        }
    }
}

@Composable
private fun StatLegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun RatingStatBox(title: String, score: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = title, fontSize = 12.sp, color = TextMuted)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = score, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = MangaGold)
    }
}

private suspend fun saveImageToStorage(context: Context, imageUrl: String, title: String) {
    withContext(Dispatchers.IO) {
        try {
            val url = URL(imageUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 8000
            connection.readTimeout = 8000
            connection.connect()

            if (connection.responseCode == HttpURLConnection.HTTP_OK) {
                val inputStream = connection.inputStream
                val bitmap = BitmapFactory.decodeStream(inputStream)

                if (bitmap != null) {
                    val filename = "Manga_${title.replace(Regex("[^a-zA-Z0-9]"), "_")}_${System.currentTimeMillis()}.jpg"
                    val contentValues = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MangaSlayer")
                        }
                    }

                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

                    if (uri != null) {
                        val outputStream: OutputStream? = resolver.openOutputStream(uri)
                        if (outputStream != null) {
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
                            outputStream.close()
                            withContext(Dispatchers.Main) {
                                Toast.makeText(context, "تم حفظ الصورة في المعرض بنجاح 🖼️", Toast.LENGTH_LONG).show()
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "حدث خطأ أثناء حفظ الصورة", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun Modifier.shimmerPulse(): Modifier {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.75f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800, easing = FastOutSlowInEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
        ),
        label = "alpha"
    )
    return this.graphicsLayer { this.alpha = alpha }
}

@Composable
fun rememberPressedScale(interactionSource: MutableInteractionSource): Float {
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "pressScale"
    )
    return scale
}

@Composable
fun DetailsTabSkeleton() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.background
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .align(Alignment.BottomStart),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Box(
                        modifier = Modifier
                            .width(105.dp)
                            .height(150.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .shimmerPulse()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .height(22.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.5f)
                                .height(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .width(90.dp)
                                .height(14.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1.8f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .height(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(70.dp)
                        .height(14.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    repeat(4) {
                        Box(
                            modifier = Modifier
                                .width(65.dp)
                                .height(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                    }
                }
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .width(90.dp)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Spacer(modifier = Modifier.height(12.dp))
                repeat(4) { i ->
                    val widthFraction = if (i == 3) 0.6f else 1.0f
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(widthFraction)
                            .height(12.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .shimmerPulse()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

@Composable
fun ChaptersTabSkeleton() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(160.dp)
                        .height(16.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .shimmerPulse()
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .width(80.dp)
                            .height(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .shimmerPulse()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Box(
                        modifier = Modifier
                            .width(60.dp)
                            .height(28.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .shimmerPulse()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
        }

        items(8) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .width(180.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .shimmerPulse()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                        Box(
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                                .shimmerPulse()
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
                androidx.compose.material3.HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = 1.dp)
            }
        }
    }
}
