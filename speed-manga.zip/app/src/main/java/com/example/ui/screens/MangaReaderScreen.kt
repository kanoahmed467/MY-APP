package com.example.ui.screens

import android.os.Build
import com.example.data.models.DownloadQuality

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.ViewCarousel
import androidx.compose.material.icons.filled.ViewDay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import coil.compose.SubcomposeAsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.example.data.models.ChapterItem
import com.example.data.network.MadaraScraper
import com.example.ui.components.ReadingTimerOverlay
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MangaRedPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.utils.ReaderSettings
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaReaderScreen(
    mangaTitle: String,
    chapter: ChapterItem,
    allChapters: List<ChapterItem>,
    readerSettings: ReaderSettings = ReaderSettings(),
    onUpdateSettings: (ReaderSettings) -> Unit = {},
    isLoadingReader: Boolean,
    onCloseReader: () -> Unit,
    onSelectChapter: (ChapterItem) -> Unit,
    onPageChanged: (Int) -> Unit,
    onOpenCloudflare: () -> Unit = {},
    onRetry: () -> Unit = {}
) {
    var showControls by remember { mutableStateOf(false) }
    var showChapterSelector by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    val maxDisplayWidth = remember(readerSettings.downloadQuality) { 
        when (readerSettings.downloadQuality) { 
            "MEDIUM" -> DownloadQuality.MEDIUM.maxPixelWidth 
            "LOW" -> DownloadQuality.LOW.maxPixelWidth 
            else -> DownloadQuality.HIGH.maxPixelWidth 
        } 
    }
    
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    
    val pages = chapter.pages
    val lazyListState = rememberLazyListState()

    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE
    val displayPages = remember(pages, isLandscape, readerSettings.pairAdjacentLandscape) {
        if (isLandscape && readerSettings.pairAdjacentLandscape && pages.isNotEmpty()) {
            val pairs = mutableListOf<List<String>>()
            var i = 0
            while (i < pages.size) {
                if (i + 1 < pages.size) {
                    pairs.add(listOf(pages[i], pages[i+1]))
                    i += 2
                } else {
                    pairs.add(listOf(pages[i]))
                    i += 1
                }
            }
            pairs
        } else {
            pages.map { listOf(it) }
        }
    }

    val pagerState = rememberPagerState(pageCount = { displayPages.size.coerceAtLeast(1) })
    val verticalPagerState = rememberPagerState(pageCount = { displayPages.size.coerceAtLeast(1) })
    var pagerScrollEnabled by remember { mutableStateOf(true) }

    val isWebtoonMode = readerSettings.readingMode == "WEBTOON"
    val isVerticalPaged = readerSettings.readingMode == "VERTICAL_PAGED"
    val isRtlMode = readerSettings.readingMode == "RTL"
    val isLtrMode = readerSettings.readingMode == "LTR"

    val currentPg = if (pages.isEmpty()) 0 else {
        if (isWebtoonMode) {
            (lazyListState.firstVisibleItemIndex + 1).coerceIn(1, pages.size)
        } else if (isVerticalPaged) {
            val idx = verticalPagerState.currentPage.coerceIn(0, displayPages.size - 1)
            val prevSinglePages = displayPages.take(idx).sumOf { it.size }
            (prevSinglePages + displayPages[idx].size).coerceIn(1, pages.size)
        } else {
            val idx = pagerState.currentPage.coerceIn(0, displayPages.size - 1)
            val prevSinglePages = displayPages.take(idx).sumOf { it.size }
            (prevSinglePages + displayPages[idx].size).coerceIn(1, pages.size)
        }
    }

    // Slider State
    var isSeekingSlider by remember { mutableStateOf(false) }
    var sliderValue by remember { mutableFloatStateOf(1f) }
    
    LaunchedEffect(currentPg, isSeekingSlider) {
        if (!isSeekingSlider && pages.isNotEmpty()) {
            sliderValue = currentPg.toFloat()
        }
    }

    // Immersive Mode & System Bars handling
    DisposableEffect(
        showControls,
        readerSettings.fullscreen,
        readerSettings.keepScreenOn,
        readerSettings.customBrightness,
        readerSettings.brightnessLevel
    ) {
        val window = (context as? android.app.Activity)?.window
        if (window != null) {
            try {
                val insetsController = WindowCompat.getInsetsController(window, view)
                if (!showControls && readerSettings.fullscreen) {
                    insetsController.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                    insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else {
                    insetsController.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                }

                if (readerSettings.keepScreenOn) {
                    window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }

                val lp = window.attributes
                if (readerSettings.customBrightness) {
                    lp.screenBrightness = readerSettings.brightnessLevel.coerceIn(0.1f, 1.0f)
                } else {
                    lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                }
                window.attributes = lp
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        onDispose {
            val w = (context as? android.app.Activity)?.window
            if (w != null) {
                try {
                    val insetsController = WindowCompat.getInsetsController(w, view)
                    insetsController.show(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
                    w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    val lp = w.attributes
                    lp.screenBrightness = android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
                    w.attributes = lp
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    LaunchedEffect(pagerState.currentPage, verticalPagerState.currentPage) {
        pagerScrollEnabled = true
    }

    LaunchedEffect(lazyListState) {
        snapshotFlow { lazyListState.firstVisibleItemIndex }.collect { index ->
            if (isWebtoonMode && pages.isNotEmpty()) onPageChanged(index)
        }
    }
    LaunchedEffect(verticalPagerState) {
        snapshotFlow { verticalPagerState.currentPage }.collect { index ->
            if (isVerticalPaged && pages.isNotEmpty()) {
                val idx = index.coerceIn(0, displayPages.size - 1)
                val prevSinglePages = displayPages.take(idx).sumOf { it.size }
                onPageChanged(prevSinglePages)
            }
        }
    }
    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.currentPage }.collect { index ->
            if (!isWebtoonMode && !isVerticalPaged && pages.isNotEmpty()) {
                val idx = index.coerceIn(0, displayPages.size - 1)
                val prevSinglePages = displayPages.take(idx).sumOf { it.size }
                onPageChanged(prevSinglePages)
            }
        }
    }

    val contentScale = when (readerSettings.pageScaling) {
        "FIT_WIDTH" -> ContentScale.FillWidth
        "FIT_HEIGHT" -> ContentScale.FillHeight
        "ORIGINAL" -> ContentScale.None
        else -> ContentScale.FillWidth
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .focusRequester(focusRequester)
            .focusable()
            .onKeyEvent { keyEvent ->
                if (keyEvent.type == KeyEventType.KeyDown) {
                    when (keyEvent.key) {
                        Key.DirectionRight -> {
                            scope.launch {
                                if (isVerticalPaged) {
                                    val target = verticalPagerState.currentPage - 1
                                    if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                } else if (!isWebtoonMode) {
                                    val target = if (isRtlMode) pagerState.currentPage - 1 else pagerState.currentPage + 1
                                    if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                }
                            }
                            true
                        }
                        Key.DirectionLeft -> {
                            scope.launch {
                                if (isVerticalPaged) {
                                    val target = verticalPagerState.currentPage + 1
                                    if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                } else if (!isWebtoonMode) {
                                    val target = if (isRtlMode) pagerState.currentPage + 1 else pagerState.currentPage - 1
                                    if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                }
                            }
                            true
                        }
                        Key.Spacebar, Key.PageDown, Key.DirectionDown -> {
                            if (readerSettings.keyboardShortcuts) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val nextItem = (lazyListState.firstVisibleItemIndex + 1).coerceAtMost(pages.size - 1)
                                        lazyListState.animateScrollToItem(nextItem)
                                    } else if (isVerticalPaged) {
                                        val target = verticalPagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                    } else {
                                        val target = if (isRtlMode) pagerState.currentPage - 1 else pagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.PageUp, Key.DirectionUp -> {
                            if (readerSettings.keyboardShortcuts) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val prevItem = (lazyListState.firstVisibleItemIndex - 1).coerceAtLeast(0)
                                        lazyListState.animateScrollToItem(prevItem)
                                    } else if (isVerticalPaged) {
                                        val target = verticalPagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                    } else {
                                        val target = if (isRtlMode) pagerState.currentPage + 1 else pagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.VolumeUp -> {
                            if (readerSettings.volumeKeyNav) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val prevItem = (lazyListState.firstVisibleItemIndex - 1).coerceAtLeast(0)
                                        lazyListState.animateScrollToItem(prevItem)
                                    } else if (isVerticalPaged) {
                                        val target = verticalPagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                    } else {
                                        val target = pagerState.currentPage - 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        Key.VolumeDown -> {
                            if (readerSettings.volumeKeyNav) {
                                scope.launch {
                                    if (isWebtoonMode) {
                                        val nextItem = (lazyListState.firstVisibleItemIndex + 1).coerceAtMost(pages.size - 1)
                                        lazyListState.animateScrollToItem(nextItem)
                                    } else if (isVerticalPaged) {
                                        val target = verticalPagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) verticalPagerState.animateScrollToPage(target)
                                    } else {
                                        val target = pagerState.currentPage + 1
                                        if (target in 0 until displayPages.size) pagerState.animateScrollToPage(target)
                                    }
                                }
                                true
                            } else false
                        }
                        else -> false
                    }
                } else false
            }
            .testTag("reader_screen")
    ) {
        // Reader Content Area
        if (isLoadingReader) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = MangaRedPrimary,
                    strokeWidth = 3.5.dp,
                    modifier = Modifier.size(48.dp)
                )
            }
        } else if (pages.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(DarkBackground)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = MangaRedPrimary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "تعذر تحميل صور هذا الفصل",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "اضغط على زر إعادة المحاولة لجلب صفحات الفصل مرة أخرى تلقائياً.",
                            color = TextSecondary,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = onRetry,
                            colors = ButtonDefaults.buttonColors(containerColor = MangaRedPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إعادة المحاولة", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        } else {
            val pagerContentScale = when (readerSettings.pageScaling) {
                "FIT_HEIGHT" -> ContentScale.FillHeight
                "FIT_WIDTH" -> ContentScale.FillWidth
                "ORIGINAL" -> ContentScale.None
                else -> ContentScale.Fit
            }

            if (isWebtoonMode) {
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = readerSettings.sidePadding.dp)
                        .pointerInput(readerSettings.tapToNavigate) {
                            detectTapGestures(
                                onTap = { offset ->
                                    val screenWidth = size.width.toFloat()
                                    val x = offset.x
                                    val leftBoundary = screenWidth / 3.5f
                                    val rightBoundary = screenWidth - (screenWidth / 3.5f)
                                    
                                    if (readerSettings.tapToNavigate) {
                                        if (x < leftBoundary) {
                                            scope.launch {
                                                val target = maxOf(0, lazyListState.firstVisibleItemIndex - 1)
                                                lazyListState.animateScrollToItem(target)
                                            }
                                        } else if (x > rightBoundary) {
                                            scope.launch {
                                                val target = minOf(displayPages.size - 1, lazyListState.firstVisibleItemIndex + 1)
                                                lazyListState.animateScrollToItem(target)
                                            }
                                        } else {
                                            showControls = !showControls
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                }
                            )
                        }
                ) {
                    itemsIndexed(displayPages) { index, pageUrls ->
                        var retryCount by remember { mutableStateOf(0) }
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            pageUrls.forEachIndexed { subIndex, pageUrl ->
                                val finalPageUrl = remember(pageUrl, retryCount) {
                                    if (retryCount > 0 && pageUrl.startsWith("http")) {
                                        if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                    } else {
                                        pageUrl
                                    }
                                }
                                val imageRequest = remember(finalPageUrl, retryCount, maxDisplayWidth, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                    ImageRequest.Builder(context)
                                        .data(finalPageUrl)
                                        .addHeader("User-Agent", MadaraScraper.userAgent)
                                        .addHeader("Referer", "https://mangalik.net/")
                                        .apply {
                                            if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                                addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                            }
                                        }
                                        .size(maxDisplayWidth, 15000)
                                        .scale(coil.size.Scale.FIT)
                                        .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                        .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                        .precision(coil.size.Precision.INEXACT)
                                        .crossfade(false)
                                        .build()
                                }

                                val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                    androidx.compose.ui.graphics.FilterQuality.High
                                } else {
                                    androidx.compose.ui.graphics.FilterQuality.Medium
                                }

                                val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                    androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                        androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                            -1f,  0f,  0f,  0f,  1f,
                                             0f, -1f,  0f,  0f,  1f,
                                             0f,  0f, -1f,  0f,  1f,
                                             0f,  0f,  0f,  1f,  0f
                                        ))
                                    )
                                } else null

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(DarkBackground),
                                    contentAlignment = Alignment.Center
                                ) {
                                    SubcomposeAsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة ${index + 1}",
                                        loading = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(380.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    color = MangaRedPrimary,
                                                    strokeWidth = 3.dp,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            }
                                        },
                                        error = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(200.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                IconButton(
                                                    onClick = { retryCount++ },
                                                    modifier = Modifier
                                                        .size(48.dp)
                                                        .background(DarkSurface, CircleShape)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Refresh,
                                                        contentDescription = "إعادة المحاولة",
                                                        tint = MangaRedPrimary,
                                                        modifier = Modifier.size(26.dp)
                                                    )
                                                }
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.04f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.04f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt
                                    )
                                }
                            }
                        }
                    }
                }
            } else if (isVerticalPaged) {
                // Vertical Single Page Paged Mode
                VerticalPager(
                    state = verticalPagerState,
                    beyondViewportPageCount = 2,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = readerSettings.sidePadding.dp)
                ) { pageIndex ->
                    val pageUrls = displayPages[pageIndex]
                    ReaderPageContainer(
                        pageUrls = pageUrls,
                        pageIndex = pageIndex,
                        readerSettings = readerSettings,
                        contentScale = pagerContentScale,
                        onToggleControls = { showControls = !showControls },
                        onNavigateNext = {
                            scope.launch {
                                val target = minOf(displayPages.size - 1, verticalPagerState.currentPage + 1)
                                verticalPagerState.animateScrollToPage(target)
                            }
                        },
                        onNavigatePrev = {
                            scope.launch {
                                val target = maxOf(0, verticalPagerState.currentPage - 1)
                                verticalPagerState.animateScrollToPage(target)
                            }
                        }
                    )
                }
            } else {
                // Horizontal Single/Double Page Mode (RTL Manga or LTR Manhwa)
                HorizontalPager(
                    state = pagerState,
                    reverseLayout = isLtrMode,
                    beyondViewportPageCount = 2,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = readerSettings.sidePadding.dp)
                ) { pageIndex ->
                    val pageUrls = displayPages[pageIndex]
                    ReaderPageContainer(
                        pageUrls = pageUrls,
                        pageIndex = pageIndex,
                        readerSettings = readerSettings,
                        contentScale = pagerContentScale,
                        onToggleControls = { showControls = !showControls },
                        onNavigateNext = {
                            scope.launch {
                                val target = if (isRtlMode) {
                                    minOf(displayPages.size - 1, pagerState.currentPage + 1)
                                } else {
                                    maxOf(0, pagerState.currentPage - 1)
                                }
                                pagerState.animateScrollToPage(target)
                            }
                        },
                        onNavigatePrev = {
                            scope.launch {
                                val target = if (isRtlMode) {
                                    maxOf(0, pagerState.currentPage - 1)
                                } else {
                                    minOf(displayPages.size - 1, pagerState.currentPage + 1)
                                }
                                pagerState.animateScrollToPage(target)
                            }
                        }
                    )
                }
            }
        }
        
        // Invisible tap backdrop to dismiss controls
        if (showControls) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures {
                            showControls = false
                        }
                    }
            )
        }

        // Top Bar Overlay (Slides from/to Top)
        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(
                initialOffsetY = { -it },
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { -it },
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(200)),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.92f))
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {},
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onCloseReader,
                    modifier = Modifier.testTag("close_reader")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "رجوع",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.Start
                ) {
                    Text(
                        text = mangaTitle,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = chapter.title,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.75f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { showSettingsSheet = true },
                    modifier = Modifier.testTag("reader_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "إعدادات القارئ",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Bottom Control Bar Overlay (Slides from/to Bottom)
        val currentIndex = allChapters.indexOfFirst { it.id == chapter.id }
        val prevChapter = if (currentIndex > 0) allChapters.getOrNull(currentIndex - 1) else null
        val nextChapter = if (currentIndex < allChapters.size - 1) allChapters.getOrNull(currentIndex + 1) else null

        AnimatedVisibility(
            visible = showControls,
            enter = slideInVertically(
                initialOffsetY = { it },
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            ) + fadeIn(animationSpec = tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { it },
                animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
            ) + fadeOut(animationSpec = tween(200)),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.92f))
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {},
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Previous Chapter Button (Left Icon in screenshot)
                IconButton(
                    onClick = { prevChapter?.let { onSelectChapter(it) } },
                    enabled = prevChapter != null,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "الفصل السابق",
                        tint = if (prevChapter != null) Color.White else Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Current Page Number Text
                Text(
                    text = "${currentPg.coerceAtLeast(1)}",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )

                // Page Progress Slider
                Slider(
                    value = sliderValue,
                    onValueChange = { newVal ->
                        isSeekingSlider = true
                        sliderValue = newVal
                    },
                    onValueChangeFinished = {
                        isSeekingSlider = false
                        val targetPage = sliderValue.toInt() - 1
                        if (targetPage in 0 until pages.size) {
                            scope.launch {
                                if (isWebtoonMode) {
                                    lazyListState.scrollToItem(targetPage)
                                } else if (isVerticalPaged) {
                                    val pIdx = targetPage.coerceIn(0, displayPages.size - 1)
                                    verticalPagerState.scrollToPage(pIdx)
                                } else {
                                    val pIdx = targetPage.coerceIn(0, displayPages.size - 1)
                                    pagerState.scrollToPage(pIdx)
                                }
                            }
                        }
                    },
                    valueRange = 1f..pages.size.coerceAtLeast(1).toFloat(),
                    steps = if (pages.size > 2) pages.size - 2 else 0,
                    colors = SliderDefaults.colors(
                        thumbColor = MangaRedPrimary,
                        activeTrackColor = MangaRedPrimary,
                        inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp)
                )

                // Total Pages Text
                Text(
                    text = "${pages.size}",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )

                // Next Chapter Button (Right Icon in screenshot)
                IconButton(
                    onClick = { nextChapter?.let { onSelectChapter(it) } },
                    enabled = nextChapter != null,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "الفصل التالي",
                        tint = if (nextChapter != null) Color.White else Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
        
        // Quick Chapter Selector Dialog
        if (showChapterSelector) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showChapterSelector = false }
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 450.dp)
                        .padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "اختر الفصل",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            itemsIndexed(allChapters) { _, chItem ->
                                val isCurrent = chItem.id == chapter.id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isCurrent) MangaRedPrimary.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable {
                                            onSelectChapter(chItem)
                                            showChapterSelector = false
                                        }
                                        .padding(horizontal = 12.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = chItem.title,
                                        color = if (isCurrent) MangaRedPrimary else TextPrimary,
                                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { showChapterSelector = false },
                            modifier = Modifier.align(Alignment.End),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إلغاء", color = TextPrimary)
                        }
                    }
                }
            }
        }

        // Reader Settings Bottom Sheet
        if (showSettingsSheet) {
            val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ModalBottomSheet(
                onDismissRequest = { showSettingsSheet = false },
                sheetState = sheetState,
                containerColor = DarkSurface,
                dragHandle = {
                    Box(
                        modifier = Modifier
                            .padding(vertical = 10.dp)
                            .size(width = 36.dp, height = 4.dp)
                            .background(Color.Gray.copy(alpha = 0.4f), CircleShape)
                    )
                }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .navigationBarsPadding()
                ) {
                    Text(
                        text = "إعدادات القارئ",
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 18.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    // Reading Mode Selector
                    Text(
                        text = "نمط القراءة",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val modes = listOf(
                            "WEBTOON" to "ويب تون",
                            "RTL" to "مانجا (RTL)",
                            "LTR" to "مانهوا (LTR)"
                        )
                        modes.forEach { (modeCode, modeLabel) ->
                            val isSelected = readerSettings.readingMode == modeCode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MangaRedPrimary else DarkSurfaceVariant)
                                    .clickable {
                                        onUpdateSettings(readerSettings.copy(readingMode = modeCode))
                                    }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = modeLabel,
                                    color = if (isSelected) Color.White else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Keep Screen On Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Fullscreen, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("وضع ملء الشاشة", color = TextPrimary, fontSize = 14.sp)
                        }
                        Switch(
                            checked = readerSettings.fullscreen,
                            onCheckedChange = { onUpdateSettings(readerSettings.copy(fullscreen = it)) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MangaRedPrimary
                            )
                        )
                    }

                    // Keep Screen On Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.BrightnessMedium, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("إبقاء الشاشة مفعلة", color = TextPrimary, fontSize = 14.sp)
                        }
                        Switch(
                            checked = readerSettings.keepScreenOn,
                            onCheckedChange = { onUpdateSettings(readerSettings.copy(keepScreenOn = it)) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MangaRedPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Reading Timer Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Schedule, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("عداد وقت القراءة (الأيقونة الطافية)", color = TextPrimary, fontSize = 14.sp)
                        }
                        Switch(
                            checked = readerSettings.enableReadingTimer,
                            onCheckedChange = { onUpdateSettings(readerSettings.copy(enableReadingTimer = it)) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MangaRedPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick Jump to Chapters
                    Button(
                        onClick = {
                            showSettingsSheet = false
                            showChapterSelector = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.AutoMirrored.Filled.List, contentDescription = null, tint = MangaRedPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("قائمة كافة فصول المانجا", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        }

        // Reading Timer Overlay Floating Widget
        if (readerSettings.enableReadingTimer && pages.isNotEmpty()) {
            ReadingTimerOverlay(
                currentPage = currentPg,
                totalPages = pages.size
            )
        }
    }
}

@Composable
private fun ReaderPageContainer(
    pageUrls: List<String>,
    pageIndex: Int,
    readerSettings: ReaderSettings,
    contentScale: ContentScale,
    onToggleControls: () -> Unit,
    onNavigateNext: () -> Unit,
    onNavigatePrev: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val maxDisplayWidth = remember(readerSettings.downloadQuality) { 
        when (readerSettings.downloadQuality) { 
            "MEDIUM" -> DownloadQuality.MEDIUM.maxPixelWidth 
            "LOW" -> DownloadQuality.LOW.maxPixelWidth 
            else -> DownloadQuality.HIGH.maxPixelWidth 
        } 
    }
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }
    val isZoomed = scale > 1.05f

    val zoomModifier = if (isZoomed) {
        Modifier.pointerInput(isZoomed) {
            detectTransformGestures { _, pan, zoom, _ ->
                scale = (scale * zoom).coerceIn(1f, 3.5f)
                if (scale > 1.05f) {
                    offsetX += pan.x
                    offsetY += pan.y
                } else {
                    scale = 1f
                    offsetX = 0f
                    offsetY = 0f
                }
            }
        }
    } else {
        Modifier
    }

    val tapModifier = Modifier.pointerInput(readerSettings.tapToNavigate, isZoomed) {
        detectTapGestures(
            onDoubleTap = {
                if (scale > 1.05f) {
                    scale = 1f
                    offsetX = 0f
                    offsetY = 0f
                } else {
                    scale = 2.2f
                }
            },
            onTap = { offset ->
                if (scale > 1.05f) {
                    scale = 1f
                    offsetX = 0f
                    offsetY = 0f
                    return@detectTapGestures
                }
                val screenWidth = size.width.toFloat()
                val x = offset.x
                val leftBoundary = screenWidth / 3.2f
                val rightBoundary = screenWidth - (screenWidth / 3.2f)

                if (readerSettings.tapToNavigate) {
                    if (x < leftBoundary) {
                        onNavigatePrev()
                    } else if (x > rightBoundary) {
                        onNavigateNext()
                    } else {
                        onToggleControls()
                    }
                } else {
                    onToggleControls()
                }
            }
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .then(zoomModifier)
            .then(tapModifier),
        contentAlignment = Alignment.Center
    ) {
        val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
            androidx.compose.ui.graphics.FilterQuality.High
        } else {
            androidx.compose.ui.graphics.FilterQuality.Medium
        }

        val colorFilt = if (readerSettings.tintMode == "INVERTED") {
            androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                    -1f,  0f,  0f,  0f,  1f,
                     0f, -1f,  0f,  0f,  1f,
                     0f,  0f, -1f,  0f,  1f,
                     0f,  0f,  0f,  1f,  0f
                ))
            )
        } else null

        if (pageUrls.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    ),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                pageUrls.forEachIndexed { _, pageUrl ->
                    var retryCount by remember { mutableStateOf(0) }
                    val finalPageUrl = remember(pageUrl, retryCount) {
                        if (retryCount > 0 && pageUrl.startsWith("http")) {
                            if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                        } else {
                            pageUrl
                        }
                    }
                    val imageRequest = remember(finalPageUrl, retryCount, maxDisplayWidth, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                        ImageRequest.Builder(context)
                            .data(finalPageUrl)
                            .addHeader("User-Agent", MadaraScraper.userAgent)
                            .addHeader("Referer", "https://mangalik.net/")
                            .apply {
                                if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                    addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                }
                            }
                            .size(maxDisplayWidth, 15000)
                                        .scale(coil.size.Scale.FIT)
                                        .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .precision(coil.size.Precision.INEXACT)
                            .crossfade(false)
                            .build()
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        SubcomposeAsyncImage(
                            model = imageRequest,
                            contentDescription = "صفحة ${pageIndex + 1}",
                            loading = {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(
                                        color = MangaRedPrimary,
                                        strokeWidth = 3.dp,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            },
                            error = {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    IconButton(
                                        onClick = { retryCount++ },
                                        modifier = Modifier
                                            .size(48.dp)
                                            .background(DarkSurface, CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Refresh,
                                            contentDescription = "إعادة المحاولة",
                                            tint = MangaRedPrimary,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = if (readerSettings.cropMargins) 1.04f else 1.0f,
                                    scaleY = if (readerSettings.cropMargins) 1.04f else 1.0f
                                ),
                            contentScale = contentScale,
                            filterQuality = filterQual,
                            colorFilter = colorFilt
                        )
                    }
                }
            }
        } else {
            val pageUrl = pageUrls.firstOrNull().orEmpty()
            var retryCount by remember { mutableStateOf(0) }
            val finalPageUrl = remember(pageUrl, retryCount) {
                if (retryCount > 0 && pageUrl.startsWith("http")) {
                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                } else {
                    pageUrl
                }
            }
            val imageRequest = remember(finalPageUrl, retryCount, maxDisplayWidth, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                ImageRequest.Builder(context)
                    .data(finalPageUrl)
                    .addHeader("User-Agent", MadaraScraper.userAgent)
                    .addHeader("Referer", "https://mangalik.net/")
                    .apply {
                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                        }
                    }
                    .size(maxDisplayWidth, 15000)
                                        .scale(coil.size.Scale.FIT)
                                        .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                    .precision(coil.size.Precision.INEXACT)
                    .crossfade(false)
                    .build()
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    ),
                contentAlignment = Alignment.Center
            ) {
                SubcomposeAsyncImage(
                    model = imageRequest,
                    contentDescription = "صفحة ${pageIndex + 1}",
                    loading = {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(
                                color = MangaRedPrimary,
                                strokeWidth = 3.dp,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    },
                    error = {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            IconButton(
                                onClick = { retryCount++ },
                                modifier = Modifier
                                    .size(48.dp)
                                    .background(DarkSurface, CircleShape)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "إعادة المحاولة",
                                    tint = MangaRedPrimary,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = if (readerSettings.cropMargins) 1.04f else 1.0f,
                            scaleY = if (readerSettings.cropMargins) 1.04f else 1.0f
                        ),
                    contentScale = contentScale,
                    filterQuality = filterQual,
                    colorFilter = colorFilt
                )
            }
        }
    }
}
