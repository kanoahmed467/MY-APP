package com.example.ui.screens
import androidx.compose.material.icons.filled.HighQuality

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.UserAccount
import com.example.ui.theme.MangaRedPrimary
import com.example.utils.CacheManager
import com.example.utils.ReaderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class SettingsPage {
    MAIN,
    READER
}

@Composable
fun SettingsScreen(
    readerSettings: ReaderSettings,
    onUpdateSettings: (ReaderSettings) -> Unit,
    favoritesCount: Int = 0,
    historyCount: Int = 0,
    isCloudflareVerified: Boolean = false,
    currentUser: UserAccount? = null,
    onLogout: () -> Unit = {},
    onOpenAuth: () -> Unit = {},
    onUpdateName: (String) -> Unit = {},
    onOpenCloudflare: () -> Unit = {},
    onBackClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var currentPage by remember { mutableStateOf(SettingsPage.MAIN) }

    BackHandler(enabled = currentPage == SettingsPage.READER) {
        currentPage = SettingsPage.MAIN
    }

    AnimatedContent(
        targetState = currentPage,
        transitionSpec = {
            if (targetState == SettingsPage.READER) {
                slideInHorizontally { width -> -width } togetherWith slideOutHorizontally { width -> width }
            } else {
                slideInHorizontally { width -> width } togetherWith slideOutHorizontally { width -> -width }
            }
        },
        label = "SettingsPageTransition"
    ) { page ->
        when (page) {
            SettingsPage.MAIN -> {
                MainSettingsView(
                    readerSettings = readerSettings,
                    onUpdateSettings = onUpdateSettings,
                    onNavigateToReaderSettings = { currentPage = SettingsPage.READER },
                    onBackClick = onBackClick
                )
            }
            SettingsPage.READER -> {
                ReaderSettingsSubView(
                    readerSettings = readerSettings,
                    onUpdateSettings = onUpdateSettings,
                    onBackClick = { currentPage = SettingsPage.MAIN }
                )
            }
        }
    }
}

@Composable
private fun MainSettingsView(
    readerSettings: ReaderSettings,
    onUpdateSettings: (ReaderSettings) -> Unit,
    onNavigateToReaderSettings: () -> Unit,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var cacheSizeText by remember { mutableStateOf("0.00 ميجابايت") }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showDownloadQualityDialog by remember { mutableStateOf(false) }
    var showExportFormatDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val size = CacheManager.getFormattedCacheSize(context)
            withContext(Dispatchers.Main) {
                cacheSizeText = size
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Red Top App Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MangaRedPrimary)
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "الاعدادات",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Settings Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 12.dp)
        ) {
            // Section: عام
            SettingsSectionHeader(title = "عام")

            // 1. الوضع الليلي
            SettingsToggleRow(
                title = "الوضع الليلي",
                subtitle = "تفعيل المظهر الداكن في كامل التطبيق",
                icon = Icons.Default.BrightnessMedium,
                checked = readerSettings.isDarkMode,
                onCheckedChange = { isDark ->
                    onUpdateSettings(readerSettings.copy(isDarkMode = isDark))
                }
            )

            SettingsDivider()

            // 2. العارض (ينتقل لصفحة العارض)
            SettingsClickableRow(
                title = "العارض",
                subtitle = "تخصيص نمط القراءة، ملء الشاشة، والتحكم بالصفحات",
                icon = Icons.AutoMirrored.Filled.MenuBook,
                onClick = onNavigateToReaderSettings
            )

            SettingsDivider()

            // 3. مسح البيانات المؤقتة
            SettingsValueRow(
                title = "مسح البيانات المؤقتة",
                valueText = cacheSizeText,
                icon = Icons.Default.DeleteSweep,
                onClick = {
                    coroutineScope.launch(Dispatchers.IO) {
                        CacheManager.clearAppCache(context)
                        withContext(Dispatchers.Main) {
                            cacheSizeText = "0 بايت"
                            Toast.makeText(context, "تم مسح البيانات المؤقتة بنجاح", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )

            SettingsDivider()

            // 4. تفعيل الإشعارات
            SettingsToggleRow(
                title = "تفعيل الإشعارات",
                subtitle = "تلقي تنبيهات عند نزول فصول جديدة لمانجاتك المفضلة",
                icon = Icons.Default.Notifications,
                checked = readerSettings.notificationsEnabled,
                onCheckedChange = { enabled ->
                    onUpdateSettings(readerSettings.copy(notificationsEnabled = enabled))
                }
            )

            SettingsDivider()

            // 5. جودة عرض وتحميل الصور
            val currentQualityLabel = when (readerSettings.downloadQuality) {
                "MEDIUM" -> "متوسطة"
                "LOW" -> "منخفضة"
                else -> "عالية (الأصلية)"
            }
            SettingsValueRow(
                title = "جودة عرض وتحميل الصور",
                valueText = currentQualityLabel,
                icon = Icons.Default.HighQuality,
                onClick = { showDownloadQualityDialog = true }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section: حفظ وتصدير الفصول إلى الهاتف (PDF / CBZ)
            SettingsSectionHeader(title = "حفظ وتصدير الفصول إلى الهاتف")

            // صيغة الحفظ الافتراضية
            val exportFormatLabel = if (readerSettings.exportFormat == "CBZ") "أرشيف CBZ" else "مستند PDF"
            SettingsValueRow(
                title = "صيغة الحفظ الافتراضية",
                valueText = exportFormatLabel,
                icon = if (readerSettings.exportFormat == "CBZ") Icons.Default.SaveAlt else Icons.Default.PictureAsPdf,
                onClick = { showExportFormatDialog = true }
            )

            SettingsDivider()

            // تنظيم المجلدات
            SettingsToggleRow(
                title = "إنشاء مجلد مخصص لكل مانجا",
                subtitle = "حفظ فصول كل مانجا تلقائياً في مجلد خاص باسم العمل",
                icon = Icons.Default.Folder,
                checked = readerSettings.createMangaSubfolders,
                onCheckedChange = { createSub ->
                    onUpdateSettings(readerSettings.copy(createMangaSubfolders = createSub))
                }
            )

            SettingsDivider()

            // مسار الحفظ بالهاتف
            SettingsClickableRow(
                title = "موقع مجلد الحفظ في الهاتف",
                subtitle = "التخزين الداخلي / Downloads / SpeedManga / [اسم العمل]",
                icon = Icons.Default.Save,
                onClick = {
                    Toast.makeText(
                        context,
                        "يتم حفظ الفصول في مجلد Downloads/SpeedManga لتتمكن من تصفحها ونقلها لأي جهاز بسهولة 📁",
                        Toast.LENGTH_LONG
                    ).show()
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section: اخرى
            SettingsSectionHeader(title = "اخرى")

            // 6. مشاركة التطبيق
            SettingsClickableRow(
                title = "مشاركة التطبيق",
                subtitle = "شارك التطبيق مع أصدقائك ومحبي المانجا",
                icon = Icons.Default.Share,
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "تطبيق Speed Manga")
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "حمّل تطبيق Speed Manga لقراءة ومتابعة أحدث فصول المانجا والمانهوا المترجمة مجاناً وبأعلى سرعة وبدون إعلانات مزعجة!"
                        )
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة التطبيق عبر"))
                }
            )

            SettingsDivider()

            // 7. حول
            SettingsClickableRow(
                title = "حول",
                subtitle = "معلومات الإصدار وتفاصيل التطبيق",
                icon = Icons.Default.Info,
                onClick = { showAboutDialog = true }
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Download Quality Selection Dialog
    if (showDownloadQualityDialog) {
        val qualities = listOf(
            Triple("HIGH", "عالية (الجودة الأصلية)", "أفضل دقة ونقاء للصور"),
            Triple("MEDIUM", "متوسطة (متوازنة)", "توفير 40% من المساحة والبيانات"),
            Triple("LOW", "منخفضة (توفير المساحة)", "أسرع تنزيل وأقل استهلاك للذاكرة")
        )
        AlertDialog(
            onDismissRequest = { showDownloadQualityDialog = false },
            title = {
                Text(
                    text = "اختر جودة التنزيل الافتراضية",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    qualities.forEach { (code, title, desc) ->
                        val isSelected = readerSettings.downloadQuality == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdateSettings(readerSettings.copy(downloadQuality = code))
                                    showDownloadQualityDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(readerSettings.copy(downloadQuality = code))
                                    showDownloadQualityDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = desc,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showDownloadQualityDialog = false }) {
                    Text("إغلاق", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Export Format Selection Dialog (PDF vs CBZ)
    if (showExportFormatDialog) {
        val formats = listOf(
            Triple("PDF", "مستند PDF عالي الجودة (.pdf)", "ملف كتاب إلكتروني شامل لجميع الصفحات، سهل القراءة والطباعة والمشاركة"),
            Triple("CBZ", "أرشيف كوميكس مضغوط (.cbz)", "المعيار العالمي لتطبيقات قراءة المانجا، سريع ومضغوط بأعلى جودة")
        )
        AlertDialog(
            onDismissRequest = { showExportFormatDialog = false },
            title = {
                Text(
                    text = "اختر صيغة الحفظ الافتراضية في الهاتف",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    formats.forEach { (code, title, desc) ->
                        val isSelected = readerSettings.exportFormat == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdateSettings(readerSettings.copy(exportFormat = code))
                                    showExportFormatDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(readerSettings.copy(exportFormat = code))
                                    showExportFormatDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = desc,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExportFormatDialog = false }) {
                    Text("إغلاق", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // About Dialog
    if (showAboutDialog) {
        AlertDialog(
            onDismissRequest = { showAboutDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = null,
                        tint = MangaRedPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Speed Manga",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MangaRedPrimary
                    )
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "الإصدار: 2.4.0 (النسخة المستقرة)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "تطبيق متكامل لتصفح وقراءة وتحميل فصول المانجا والمانهوا العربية بأعلى سرعة وكفاءة، مستوحى من تجربة مانجا سلاير الأصيلة.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "جميع الحقوق محفوظة © 2026",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showAboutDialog = false }) {
                    Text("حسناً", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun ReaderSettingsSubView(
    readerSettings: ReaderSettings,
    onUpdateSettings: (ReaderSettings) -> Unit,
    onBackClick: () -> Unit
) {
    var showReadingModeDialog by remember { mutableStateOf(false) }
    var showScalingDialog by remember { mutableStateOf(false) }
    var showTintColorDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Red Top App Bar for Reader Settings
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MangaRedPrimary)
                .statusBarsPadding()
                .padding(horizontal = 4.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "الرجوع للإعدادات",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إعدادات العارض",
                    color = Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Reader Settings Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(vertical = 12.dp)
        ) {
            // Section 1: نمط وتنسيق القراءة
            SettingsSectionHeader(title = "نمط وتنسيق القراءة")

            // Reading Mode Selector
            val readingModeLabel = when (readerSettings.readingMode) {
                "RTL" -> "مانجا من اليمين لليسار (RTL)"
                "LTR" -> "مانهوا من اليسار لليمين (LTR)"
                "VERTICAL_PAGED" -> "صفحات رأسية منفصلة"
                else -> "ويب تون عمودي متصل (Webtoon)"
            }
            SettingsValueRow(
                title = "نمط القراءة الافتراضي",
                valueText = readingModeLabel,
                icon = Icons.AutoMirrored.Filled.MenuBook,
                onClick = { showReadingModeDialog = true }
            )

            SettingsDivider()

            // Page Scaling
            val pageScalingLabel = when (readerSettings.pageScaling) {
                "FIT_HEIGHT" -> "ملء الارتفاع"
                "ORIGINAL" -> "الحجم الطبيعي"
                else -> "ملء العرض (تلقائي)"
            }
            SettingsValueRow(
                title = "تحجيم الصور والصفحات",
                valueText = pageScalingLabel,
                icon = Icons.Default.Crop,
                onClick = { showScalingDialog = true }
            )

            SettingsDivider()

            // Crop Margins
            SettingsToggleRow(
                title = "قص الهوامش البيضاء",
                subtitle = "تكبير الصفحات تلقائياً للتركيز على المحتوى وإزالة الأطراف الفارغة",
                icon = Icons.Default.Crop,
                checked = readerSettings.cropMargins,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(cropMargins = it)) }
            )

            SettingsDivider()

            // Pair Adjacent Landscape
            SettingsToggleRow(
                title = "عرض صفحتين في الوضع الأفقي",
                subtitle = "دمج كل صفحتين متجاورتين تلقائياً عند تدوير الشاشة أفقياً",
                icon = Icons.Default.ScreenRotation,
                checked = readerSettings.pairAdjacentLandscape,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(pairAdjacentLandscape = it)) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: التحكم والتنقل
            SettingsSectionHeader(title = "التحكم والتنقل")

            // Fullscreen
            SettingsToggleRow(
                title = "وضع ملء الشاشة",
                subtitle = "إخفاء أشرطة الحالة والتنقل للنظام أثناء القراءة",
                icon = Icons.Default.Fullscreen,
                checked = readerSettings.fullscreen,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(fullscreen = it)) }
            )

            SettingsDivider()

            // Keep Screen On
            SettingsToggleRow(
                title = "إبقاء الشاشة مضاءة دائماً",
                subtitle = "منع إيقاف تشغيل الشاشة أو قفلها أثناء قراءة الفصول",
                icon = Icons.Default.BrightnessMedium,
                checked = readerSettings.keepScreenOn,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(keepScreenOn = it)) }
            )

            SettingsDivider()

            // Tap to Navigate
            SettingsToggleRow(
                title = "تقليب الصفحات باللمس على الجوانب",
                subtitle = "النقر على طرفي الشاشة للتنقل السريع بين الصفحات",
                icon = Icons.Default.TouchApp,
                checked = readerSettings.tapToNavigate,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(tapToNavigate = it)) }
            )

            SettingsDivider()

            // Volume Keys Navigation
            SettingsToggleRow(
                title = "استخدام أزرار الصوت للتقليب",
                subtitle = "الانتقال للصفحة التالية والسابقة عبر مفتاحي رفع وخفض الصوت",
                icon = Icons.Default.VolumeUp,
                checked = readerSettings.volumeKeyNav,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(volumeKeyNav = it)) }
            )

            SettingsDivider()

            // Reading Timer Widget
            SettingsToggleRow(
                title = "عداد وقت القراءة المباشر (الأيقونة الطافية)",
                subtitle = "عرض أداة طافية وفخمة تحسب وقت القراءة ومتوسط السرعة مباشرة أثناء تصفح الفصل",
                icon = Icons.Default.Schedule,
                checked = readerSettings.enableReadingTimer,
                onCheckedChange = { onUpdateSettings(readerSettings.copy(enableReadingTimer = it)) }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Section 3: الألوان والتصفية
            SettingsSectionHeader(title = "الألوان والتصفية")

            // Tint Mode
            val tintLabel = when (readerSettings.tintMode) {
                "INVERTED" -> "عاكس الألوان (حماية العين)"
                "SEPIA" -> "بني دافئ (سيبيا)"
                else -> "قياسي (طبيعي)"
            }
            SettingsValueRow(
                title = "تدرج ألوان العرض",
                valueText = tintLabel,
                icon = Icons.Default.Palette,
                onClick = { showTintColorDialog = true }
            )

            SettingsDivider()

            // Image Filtering (Bilinear / Bicubic)
            SettingsToggleRow(
                title = "تصفية وتنعيم الصور فائقة الدقة",
                subtitle = "استخدام خوارزمية تنعيم متقدمة لتقليل التشويش عند التكبير",
                icon = Icons.Default.Check,
                checked = readerSettings.imageFiltering == "BICUBIC",
                onCheckedChange = { isBicubic ->
                    onUpdateSettings(readerSettings.copy(imageFiltering = if (isBicubic) "BICUBIC" else "BILINEAR"))
                }
            )

            Spacer(modifier = Modifier.height(40.dp))
        }
    }

    // Reading Mode Dialog
    if (showReadingModeDialog) {
        val modes = listOf(
            Triple("WEBTOON", "ويب تون عمودي (Webtoon)", "شريط تمرير عمودي متصل ومريح للمانهوا"),
            Triple("RTL", "مانجا من اليمين لليسار (RTL)", "تقليب أفقي لصفحات المانجا اليابانية التقليدية"),
            Triple("LTR", "مانهوا من اليسار لليمين (LTR)", "تقليب أفقي كلاسيكي من اليسار لليمين"),
            Triple("VERTICAL_PAGED", "صفحات رأسية مفردة", "عرض كل صفحة بشكل مستقل عمودياً")
        )
        AlertDialog(
            onDismissRequest = { showReadingModeDialog = false },
            title = {
                Text(
                    text = "اختر نمط القراءة الافتراضي",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    modes.forEach { (code, title, desc) ->
                        val isSelected = readerSettings.readingMode == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdateSettings(readerSettings.copy(readingMode = code))
                                    showReadingModeDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(readerSettings.copy(readingMode = code))
                                    showReadingModeDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = title,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = desc,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showReadingModeDialog = false }) {
                    Text("إغلاق", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Scaling Dialog
    if (showScalingDialog) {
        val scales = listOf(
            Pair("FIT_WIDTH", "ملء العرض (تلقائي)"),
            Pair("FIT_HEIGHT", "ملء الارتفاع"),
            Pair("ORIGINAL", "الحجم الطبيعي للصور")
        )
        AlertDialog(
            onDismissRequest = { showScalingDialog = false },
            title = {
                Text(
                    text = "تحجيم الصور والصفحات",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    scales.forEach { (code, title) ->
                        val isSelected = readerSettings.pageScaling == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdateSettings(readerSettings.copy(pageScaling = code))
                                    showScalingDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(readerSettings.copy(pageScaling = code))
                                    showScalingDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showScalingDialog = false }) {
                    Text("إغلاق", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Tint Mode Dialog
    if (showTintColorDialog) {
        val tints = listOf(
            Pair("STANDARD", "قياسي (الألوان الأصلية)"),
            Pair("INVERTED", "عاكس الألوان (حماية العين ليلاً)"),
            Pair("SEPIA", "بني دافئ (قراءة مريحة)")
        )
        AlertDialog(
            onDismissRequest = { showTintColorDialog = false },
            title = {
                Text(
                    text = "تدرج ألوان العرض",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    tints.forEach { (code, title) ->
                        val isSelected = readerSettings.tintMode == code
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdateSettings(readerSettings.copy(tintMode = code))
                                    showTintColorDialog = false
                                }
                                .padding(vertical = 8.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = {
                                    onUpdateSettings(readerSettings.copy(tintMode = code))
                                    showTintColorDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = MangaRedPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (isSelected) MangaRedPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTintColorDialog = false }) {
                    Text("إغلاق", color = MangaRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun SettingsSectionHeader(title: String) {
    Text(
        text = title,
        color = MangaRedPrimary,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = MangaRedPrimary,
                checkedBorderColor = MangaRedPrimary,
                uncheckedThumbColor = Color(0xFF64748B),
                uncheckedTrackColor = Color(0xFFE2E8F0),
                uncheckedBorderColor = Color(0xFFCBD5E1)
            )
        )
    }
}

@Composable
private fun SettingsClickableRow(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 16.dp)) {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (!subtitle.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
private fun SettingsValueRow(
    title: String,
    valueText: String,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f).padding(end = 12.dp)
        )
        Text(
            text = valueText,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 20.dp),
        thickness = 0.6.dp,
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
    )
}
