package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

private val SpeedMangaDarkColorScheme = darkColorScheme(
    primary = MangaRedPrimary,
    onPrimary = Color.White,
    primaryContainer = MangaRedDark,
    onPrimaryContainer = Color.White,
    secondary = MangaRedLight,
    onSecondary = Color.White,
    tertiary = MangaGold,
    background = Color(0xFF0F0F14),
    onBackground = Color(0xFFF8FAFC),
    surface = Color(0xFF1B1628),
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF251F36),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF2A233D),
    outlineVariant = Color(0xFF3B3354)
)

private val SpeedMangaLightColorScheme = lightColorScheme(
    primary = MangaRedPrimary,
    onPrimary = Color.White,
    primaryContainer = MangaRedPrimary,
    onPrimaryContainer = Color.White,
    secondary = MangaRedLight,
    onSecondary = Color.White,
    tertiary = MangaGold,
    background = Color(0xFFF6F7FB),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFE2E8F0),
    outlineVariant = Color(0xFFCBD5E1)
)

@Composable
fun SpeedMangaTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) SpeedMangaDarkColorScheme else SpeedMangaLightColorScheme

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
