package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.models.ChapterItem
import com.example.data.network.MadaraScraper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class ExportFormat(val displayName: String, val extension: String, val mimeType: String) {
    PDF("مستند PDF", "pdf", "application/pdf"),
    CBZ("أرشيف CBZ (كوميكس)", "cbz", "application/x-cbz")
}

data class ExportResult(
    val isSuccess: Boolean,
    val file: File? = null,
    val filePath: String = "",
    val errorMessage: String? = null,
    val totalPages: Int = 0
)

object ChapterExportManager {
    private const val TAG = "ChapterExportManager"
    private const val ROOT_FOLDER_NAME = "SpeedManga"

    private val httpClient get() = try {
        com.example.SpeedMangaApp.sharedOkHttpClient
    } catch (_: Exception) {
        OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Sanitizes strings to be safe for directory and file names.
     */
    fun sanitizeFileName(name: String): String {
        return name
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .trim()
            .ifEmpty { "Chapter" }
    }

    /**
     * Gets the base directory for saving manga on the phone.
     * Default: Environment.DIRECTORY_DOWNLOADS / SpeedManga
     */
    fun getMangaDirectory(mangaTitle: String, createSubfolder: Boolean = true): File {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val rootDir = File(downloadsDir, ROOT_FOLDER_NAME)
        if (!rootDir.exists()) {
            rootDir.mkdirs()
        }

        val targetDir = if (createSubfolder) {
            val safeMangaName = sanitizeFileName(mangaTitle)
            File(rootDir, safeMangaName)
        } else {
            rootDir
        }

        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }

        return targetDir
    }

    /**
     * Exports a chapter with a list of page URLs or local file paths into PDF or CBZ.
     */
    suspend fun exportChapter(
        context: Context,
        mangaTitle: String,
        chapterTitle: String,
        chapterUrl: String = "",
        pagePathsOrUrls: List<String> = emptyList(),
        format: ExportFormat = ExportFormat.PDF,
        qualitySetting: String = "HIGH",
        createMangaSubfolder: Boolean = true,
        onProgress: (current: Int, total: Int, status: String) -> Unit = { _, _, _ -> }
    ): ExportResult = withContext(Dispatchers.IO) {
        try {
            // 1. Resolve list of page sources
            var effectivePages = pagePathsOrUrls
            if (effectivePages.isEmpty() && chapterUrl.isNotBlank()) {
                onProgress(0, 0, "جاري استخراج روابط الصفحات...")
                effectivePages = MadaraScraper.fetchChapterImages(chapterUrl)
            }

            if (effectivePages.isEmpty()) {
                return@withContext ExportResult(
                    isSuccess = false,
                    errorMessage = "لم يتم العثور على صفحات لتصديرها"
                )
            }

            val targetDir = getMangaDirectory(mangaTitle, createMangaSubfolder)
            val safeChapterTitle = sanitizeFileName(chapterTitle)
            val outputFile = File(targetDir, "$safeChapterTitle.${format.extension}")

            // 2. Fetch and prepare bitmaps / raw byte data
            val totalPages = effectivePages.size

            when (format) {
                ExportFormat.PDF -> {
                    exportToPdf(
                        context = context,
                        pages = effectivePages,
                        qualitySetting = qualitySetting,
                        outputFile = outputFile,
                        onProgress = onProgress
                    )
                }
                ExportFormat.CBZ -> {
                    exportToCbz(
                        context = context,
                        pages = effectivePages,
                        qualitySetting = qualitySetting,
                        outputFile = outputFile,
                        onProgress = onProgress
                    )
                }
            }

            // 3. Scan file into MediaStore so it is immediately visible in file managers
            MediaScannerConnection.scanFile(
                context,
                arrayOf(outputFile.absolutePath),
                arrayOf(format.mimeType),
                null
            )

            ExportResult(
                isSuccess = true,
                file = outputFile,
                filePath = outputFile.absolutePath,
                totalPages = totalPages
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export chapter: ${e.message}", e)
            ExportResult(
                isSuccess = false,
                errorMessage = e.message ?: "حدث خطأ غير متوقع أثناء التصدير"
            )
        }
    }

    /**
     * Downloads and optimizes page images in parallel with bounded concurrency (5 concurrent workers).
     * Preserves image order while providing ultra-fast multi-threaded downloads.
     */
    private suspend fun downloadPagesInParallel(
        pages: List<String>,
        qualitySetting: String,
        onProgress: (current: Int, total: Int, status: String) -> Unit
    ): List<Triple<Int, Int, ByteArray>?> = coroutineScope {
        val totalPages = pages.size
        val resultsMap = java.util.concurrent.ConcurrentHashMap<Int, Triple<Int, Int, ByteArray>>()
        val completedCounter = java.util.concurrent.atomic.AtomicInteger(0)
        val semaphore = kotlinx.coroutines.sync.Semaphore(5)

        val jobs = pages.mapIndexed { index, pageSource ->
            async(Dispatchers.IO) {
                semaphore.withPermit {
                    try {
                        val rawBytes = loadPageBytes(pageSource)
                        if (rawBytes != null) {
                            val optimizedBytes = optimizeImageBytes(rawBytes, qualitySetting)
                            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            BitmapFactory.decodeByteArray(optimizedBytes, 0, optimizedBytes.size, options)
                            val w = options.outWidth
                            val h = options.outHeight
                            if (w > 0 && h > 0) {
                                resultsMap[index] = Triple(w, h, optimizedBytes)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error fetching page $index in parallel: ${e.message}")
                    } finally {
                        val curr = completedCounter.incrementAndGet()
                        onProgress(curr, totalPages, "جاري تحضير وتجهيز الصفحة $curr من $totalPages...")
                    }
                }
            }
        }

        jobs.awaitAll()
        (0 until totalPages).map { resultsMap[it] }
    }

    private suspend fun exportToPdf(
        context: Context,
        pages: List<String>,
        qualitySetting: String,
        outputFile: File,
        onProgress: (current: Int, total: Int, status: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val downloadedPages = downloadPagesInParallel(pages, qualitySetting, onProgress)
        val jpegPages = downloadedPages.filterNotNull()

        if (jpegPages.isEmpty()) {
            throw IllegalStateException("فشل تحميل أي صورة لتصدير الـ PDF")
        }

        onProgress(pages.size, pages.size, "جاري حفظ وتصدير مستند الـ PDF...")
        writePdfWithJpegPages(jpegPages, outputFile)
    }

    /**
     * Generates a compact native PDF 1.4 file with DCTDecode JPEG streams.
     * Prevents Android's PdfDocument from embedding uncompressed 100MB bitmap streams.
     */
    private fun writePdfWithJpegPages(
        jpegPagesList: List<Triple<Int, Int, ByteArray>>,
        outputFile: File
    ) {
        FileOutputStream(outputFile).use { outStream ->
            var byteCounter = 0L

            fun emitString(str: String) {
                val bytes = str.toByteArray(Charsets.US_ASCII)
                outStream.write(bytes)
                byteCounter += bytes.size
            }

            fun emitBytes(bytes: ByteArray) {
                outStream.write(bytes)
                byteCounter += bytes.size
            }

            // PDF Header
            emitString("%PDF-1.4\n%\u00e2\u00e3\u00cf\u00d3\n")

            val pageCount = jpegPagesList.size
            val totalObjects = 2 + pageCount * 3
            val objectOffsets = LongArray(totalObjects + 1)

            // Object 1: Catalog
            objectOffsets[1] = byteCounter
            emitString("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n")

            // Object 2: Pages Root
            objectOffsets[2] = byteCounter
            val kids = (0 until pageCount).joinToString(" ") { i -> "${3 + i * 3} 0 R" }
            emitString("2 0 obj\n<< /Type /Pages /Count $pageCount /Kids [ $kids ] >>\nendobj\n")

            // Emit Page, Image XObject, and Content Stream for each page
            for (i in 0 until pageCount) {
                val (w, h, jpegData) = jpegPagesList[i]
                val pageObjId = 3 + i * 3
                val imgObjId = 4 + i * 3
                val contentObjId = 5 + i * 3

                // Page Object
                objectOffsets[pageObjId] = byteCounter
                emitString("$pageObjId 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [ 0 0 $w $h ] /Resources << /XObject << /Img$i $imgObjId 0 R >> >> /Contents $contentObjId 0 R >>\nendobj\n")

                // Image XObject with JPEG DCTDecode
                objectOffsets[imgObjId] = byteCounter
                emitString("$imgObjId 0 obj\n<< /Type /XObject /Subtype /Image /Width $w /Height $h /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegData.size} >>\nstream\n")
                emitBytes(jpegData)
                emitString("\nendstream\nendobj\n")

                // Content Stream Object
                val drawCmd = "q $w 0 0 $h 0 0 cm /Img$i Do Q\n"
                val drawBytes = drawCmd.toByteArray(Charsets.US_ASCII)
                objectOffsets[contentObjId] = byteCounter
                emitString("$contentObjId 0 obj\n<< /Length ${drawBytes.size} >>\nstream\n")
                emitBytes(drawBytes)
                emitString("endstream\nendobj\n")
            }

            // Cross-Reference Table
            val startXRef = byteCounter
            emitString("xref\n0 ${totalObjects + 1}\n")
            emitString("0000000000 65535 f \n")
            for (id in 1..totalObjects) {
                val off = objectOffsets[id]
                emitString(String.format(java.util.Locale.US, "%010d 00000 n \n", off))
            }

            // Trailer
            emitString("trailer\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\n")
            emitString("startxref\n$startXRef\n%%EOF\n")
        }
    }

    private suspend fun exportToCbz(
        context: Context,
        pages: List<String>,
        qualitySetting: String,
        outputFile: File,
        onProgress: (current: Int, total: Int, status: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val downloadedPages = downloadPagesInParallel(pages, qualitySetting, onProgress)

        ZipOutputStream(FileOutputStream(outputFile).buffered()).use { zipOut ->
            downloadedPages.forEachIndexed { index, triple ->
                if (triple != null) {
                    val (_, _, optimizedBytes) = triple
                    val entryName = String.format("page_%03d.jpg", index + 1)
                    val zipEntry = ZipEntry(entryName)
                    zipOut.putNextEntry(zipEntry)
                    zipOut.write(optimizedBytes)
                    zipOut.closeEntry()
                }
            }
        }
    }

    /**
     * Compresses and resizes image byte array based on user's quality preference.
     */
    fun optimizeImageBytes(inputBytes: ByteArray, qualitySetting: String): ByteArray {
        return try {
            val (maxWidth, jpegQuality) = when (qualitySetting.uppercase()) {
                "LOW" -> Pair(720, 50)
                "MEDIUM", "SAVER", "STANDARD" -> Pair(1080, 70)
                else -> Pair(1280, 80) // HIGH / DEFAULT
            }

            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(inputBytes, 0, inputBytes.size, options)

            val origWidth = options.outWidth
            val origHeight = options.outHeight

            if (origWidth <= 0 || origHeight <= 0) return inputBytes

            var sampleSize = 1
            while (origWidth / sampleSize > maxWidth * 2) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.RGB_565
            }

            val originalBitmap = BitmapFactory.decodeByteArray(inputBytes, 0, inputBytes.size, decodeOptions)
                ?: return inputBytes

            val scaledBitmap = if (originalBitmap.width > maxWidth) {
                val scale = maxWidth.toFloat() / originalBitmap.width.toFloat()
                val targetHeight = (originalBitmap.height * scale).toInt()
                val scaled = Bitmap.createScaledBitmap(originalBitmap, maxWidth, targetHeight, true)
                if (scaled != originalBitmap) {
                    originalBitmap.recycle()
                }
                scaled
            } else {
                originalBitmap
            }

            val outStream = java.io.ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, jpegQuality, outStream)
            scaledBitmap.recycle()

            val result = outStream.toByteArray()
            if (result.isNotEmpty()) result else inputBytes
        } catch (e: Exception) {
            Log.e(TAG, "Failed to optimize image: ${e.message}")
            inputBytes
        }
    }

    private fun loadPageBytes(pageSource: String): ByteArray? {
        return try {
            if (pageSource.startsWith("file://")) {
                val localFile = File(pageSource.removePrefix("file://"))
                if (localFile.exists()) {
                    localFile.readBytes()
                } else null
            } else if (pageSource.startsWith("/") && File(pageSource).exists()) {
                File(pageSource).readBytes()
            } else {
                val request = Request.Builder()
                    .url(pageSource)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile)")
                    .build()
                httpClient.newCall(request).execute().use { response ->
                    if (response.isSuccessful && response.body != null) {
                        response.body!!.bytes()
                    } else null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading bytes for $pageSource", e)
            null
        }
    }

    private fun loadPageBitmap(pageSource: String): Bitmap? {
        val bytes = loadPageBytes(pageSource) ?: return null
        return try {
            val options = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding bitmap", e)
            null
        }
    }

    /**
     * Opens the exported PDF or CBZ file in an external app.
     */
    fun openFile(context: Context, file: File, format: ExportFormat) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, format.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(Intent.createChooser(intent, "فتح بواسطة"))
        } catch (e: Exception) {
            Log.e(TAG, "Cannot open file", e)
            Toast.makeText(context, "لا يوجد تطبيق مثبت لفتح هذا الملف (${format.extension})", Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Shares the exported file.
     */
    fun shareFile(context: Context, file: File, title: String) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (file.name.endsWith(".pdf")) "application/pdf" else "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            context.startActivity(Intent.createChooser(intent, "مشاركة $title"))
        } catch (e: Exception) {
            Log.e(TAG, "Cannot share file", e)
            Toast.makeText(context, "فشلت مشاركة الملف", Toast.LENGTH_SHORT).show()
        }
    }
}
