import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    text = f.read()

text = text.replace("import detectTransformGestures\n", "")
text = text.replace("import androidx.compose.foundation.gestures.detectTapGestures\n", "import androidx.compose.foundation.gestures.detectTapGestures\nimport androidx.compose.foundation.gestures.detectTransformGestures\n")

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(text)
