import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    lines = f.readlines()

# 1. Add import
import_stmt = "import androidx.compose.foundation.gestures.detectTransformGestures\n"
if import_stmt not in lines:
    # insert after standard imports
    lines.insert(60, import_stmt)

# 2. Fix detectTransformGestures fully qualified usage
for i in range(len(lines)):
    if "androidx.compose.foundation.gestures.detectTransformGestures" in lines[i]:
        lines[i] = lines[i].replace("androidx.compose.foundation.gestures.detectTransformGestures", "detectTransformGestures")

# 3. Replace lines from 751 to 974 (these line numbers might have shifted due to the import addition, so we use string matching)
# We look for the FIRST `} else {` that is followed by `// Horizontal Single/Double Page Mode`.
# But wait, we know the exact text we want to delete starts after the SECOND `onSuccess` block.
# Let's find the second `onSuccess = { state ->`
count = 0
start_del_idx = -1
for i in range(len(lines)):
    if "onSuccess = { state ->" in lines[i]:
        count += 1
        if count == 2:
            # this is the second onSuccess
            # the closing brace for onSuccess is at i+5 (line 745)
            # then AsyncImage is closed at i+6
            # then Box is closed at i+7
            # then Box is closed at i+8
            # then forEachIndexed is closed at i+9
            # then Row is closed at i+10 (line 750)
            start_del_idx = i + 11
            break

if start_del_idx != -1:
    # Now find the end of the garbage. We want to resume at `// Overlay Controls`
    end_del_idx = -1
    for i in range(start_del_idx, len(lines)):
        if "        // Overlay Controls" in lines[i]:
            end_del_idx = i
            break
            
    if end_del_idx != -1:
        print(f"Deleting from {start_del_idx} to {end_del_idx}")
        # Insert the correct closing braces
        correct_braces = [
            "                }\n", # end Box
            "            }\n", # end HorizontalPager
            "        }\n" # end else
        ]
        
        lines = lines[:start_del_idx] + correct_braces + lines[end_del_idx:]

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.writelines(lines)

