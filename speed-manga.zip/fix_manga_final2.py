import codecs

with codecs.open('manga_full.txt', 'r', 'utf-8') as f:
    text = f.read()

start_idx = text.find("if (isWebtoonMode || isVerticalPaged) {")
end_idx = text.find("            // Top Control Bar Overlay")

if start_idx == -1 or end_idx == -1:
    print(f"Could not find indices: start={start_idx}, end={end_idx}")
    exit(1)

part1 = text[:start_idx]
part3 = text[end_idx:]

reading_modes = """        if (isWebtoonMode || isVerticalPaged) {
            // Vertical Mode (Webtoon or Paged)
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
            ) {
                itemsIndexed(pages) { index, pageUrl ->
                    var retryCount by remember { mutableStateOf(0) }
                    var isWideImage by remember { mutableStateOf(false) }
                    
                    val finalPageUrl = remember(pageUrl, retryCount) {
                        if (retryCount > 0 && pageUrl.startsWith("http")) {
                            if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                        } else {
                            pageUrl
                        }
                    }
                    val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                        ImageRequest.Builder(context)
                            .data(finalPageUrl)
                            .addHeader("User-Agent", MadaraScraper.userAgent)
                            .addHeader("Referer", "https://mangalik.net/")
                            .apply {
                                if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                    addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                }
                            }
                            .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                            .precision(coil.size.Precision.INEXACT)
                            .crossfade(false)
                            .build()
                    }

                    val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                        androidx.compose.ui.graphics.FilterQuality.High
                    } else {
                        androidx.compose.ui.graphics.FilterQuality.Medium
                    }

                    val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                        androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                            androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                -1f,  0f,  0f,  0f,  1f,
                                 0f, -1f,  0f,  0f,  1f,
                                 0f,  0f, -1f,  0f,  1f,
                                 0f,  0f,  0f,  1f,  0f
                            ))
                        )
                    } else null

                    val contentScale = if (isWebtoonMode) ContentScale.FillWidth else ContentScale.Fit

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 350.dp)
                            .background(DarkBackground)
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onTap = {
                                        showControls = !showControls
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .clipToBounds()
                                ) {
                                    AsyncImage(
                                        model = imageRequest,
                                        contentDescription = null,
                                        modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                            .fillMaxWidth(2f)
                                            .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                        contentScale = ContentScale.FillWidth,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(1f)
                                        .clipToBounds()
                                ) {
                                    AsyncImage(
                                        model = imageRequest,
                                        contentDescription = null,
                                        modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                            .fillMaxWidth(2f)
                                            .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                        contentScale = ContentScale.FillWidth,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt
                                    )
                                }
                            }
                        } else {
                            AsyncImage(
                                model = imageRequest,
                                contentDescription = "صفحة ${index + 1}",
                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                    .fillMaxWidth()
                                    .graphicsLayer(
                                        scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                        scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                    ),
                                contentScale = contentScale,
                                filterQuality = filterQual,
                                colorFilter = colorFilt,
                                onSuccess = { state ->
                                    val drawable = state.result.drawable
                                    if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                        isWideImage = true
                                    }
                                }
                            )
                        }
                    }
                }
            }
        } else {
            // Horizontal Single/Double Page Mode (RTL or LTR) with Pinch-to-Zoom
            HorizontalPager(
                state = pagerState,
                reverseLayout = isRtlMode,
                beyondViewportPageCount = 2,
                userScrollEnabled = pagerScrollEnabled,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
            ) { pageIndex ->
                val pageUrls = displayPages[pageIndex]
                var scale by remember { mutableFloatStateOf(1f) }
                var offsetX by remember { mutableFloatStateOf(0f) }
                var offsetY by remember { mutableFloatStateOf(0f) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 3f)
                                if (scale > 1f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = {
                                    showControls = !showControls
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            ),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pageUrls.forEachIndexed { subIndex, pageUrl ->
                            var retryCount by remember { mutableStateOf(0) }
                            var isWideImage by remember { mutableStateOf(false) }
                            val finalPageUrl = remember(pageUrl, retryCount) {
                                if (retryCount > 0 && pageUrl.startsWith("http")) {
                                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                } else {
                                    pageUrl
                                }
                            }
                            val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                ImageRequest.Builder(context)
                                    .data(finalPageUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .precision(coil.size.Precision.INEXACT)
                                    .crossfade(false)
                                    .build()
                            }

                            val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                androidx.compose.ui.graphics.FilterQuality.High
                            } else {
                                androidx.compose.ui.graphics.FilterQuality.Medium
                            }

                            val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                    androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                        -1f,  0f,  0f,  0f,  1f,
                                         0f, -1f,  0f,  0f,  1f,
                                         0f,  0f, -1f,  0f,  1f,
                                         0f,  0f,  0f,  1f,  0f
                                    ))
                                )
                            } else null

                            val contentScale = ContentScale.Fit

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                    }
                                } else {
                                    AsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة $pageIndex-$subIndex",
                                        modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt,
                                        onSuccess = { state ->
                                            val drawable = state.result.drawable
                                            if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                                isWideImage = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Overlay Controls
        androidx.compose.animation.AnimatedVisibility(
            visible = showControls,
            enter = androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
"""

# Now we need to close the Box and AnimatedVisibility that wraps part3.
# Wait, part3 currently starts with `// Top Control Bar Overlay`, and goes down to the Chapter Selection Dialog.
# Where do we close `Box` and `AnimatedVisibility`?
# They enclose `// Top Control Bar Overlay` and `// Bottom Control Bar Overlay`.
# The dialog is probably outside of `AnimatedVisibility` or inside it?
# Let's just look at the end of part3.
# The original structure had `AnimatedVisibility` closing right before `// Chapter Selection Dialog`.

part3_lines = part3.split('\n')
idx_dialog = -1
for i, line in enumerate(part3_lines):
    if "// Chapter Selection Dialog" in line:
        idx_dialog = i
        break

if idx_dialog != -1:
    part3_before_dialog = '\n'.join(part3_lines[:idx_dialog])
    part3_after_dialog = '\n'.join(part3_lines[idx_dialog:])
    
    part3 = part3_before_dialog + """
            }
        }
        
        """ + part3_after_dialog

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(part1)
    f.write(reading_modes)
    f.write(part3)

print("Done writing MangaReaderScreen.kt")
