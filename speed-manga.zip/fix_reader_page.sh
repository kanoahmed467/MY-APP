sed -i '/var showSettingsSheet/a \
    val maxDisplayWidth = remember(readerSettings.downloadQuality) { \
        when (readerSettings.downloadQuality) { \
            "MEDIUM" -> DownloadQuality.MEDIUM.maxPixelWidth \
            "LOW" -> DownloadQuality.LOW.maxPixelWidth \
            else -> DownloadQuality.HIGH.maxPixelWidth \
        } \
    }' app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt
