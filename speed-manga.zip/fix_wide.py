import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    text = f.read()

# Replace all occurrences of:
# .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart)
# with:
# .align(Alignment.CenterEnd)
text = text.replace(".align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart)", ".align(Alignment.CenterEnd)")

# Replace all occurrences of:
# .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd)
# with:
# .align(Alignment.CenterStart)
text = text.replace(".align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd)", ".align(Alignment.CenterStart)")

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(text)
