import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    text = f.read()

zoom_old = """                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 3f)
                                if (scale > 1f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }"""

zoom_new = """                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 3f)
                                if (scale > 1.01f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                    pagerScrollEnabled = false
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                    pagerScrollEnabled = true
                                }
                            }"""

text = text.replace(zoom_old, zoom_new)

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(text)
