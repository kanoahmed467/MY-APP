import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    lines = f.readlines()

new_lines = []
i = 0
while i < len(lines):
    line = lines[i]
    if "onSuccess = { state ->" in line:
        new_lines.append(line)
        new_lines.append(lines[i+1]) # val drawable = state.result.drawable
        new_lines.append(lines[i+2]) # if (...)
        new_lines.append(lines[i+3]) # isWideImage = true
        new_lines.append(lines[i+4]) # }
        new_lines.append("                                }\n") # end of onSuccess
        new_lines.append("                            )\n") # end of AsyncImage
        new_lines.append("                        }\n") # end of Box (else)
        new_lines.append("                    }\n") # end of Box (main)
        new_lines.append("                }\n") # end of itemsIndexed
        new_lines.append("            }\n") # end of LazyColumn
        new_lines.append("        } else {\n")
        new_lines.append("            // Horizontal Single/Double Page Mode (RTL or LTR) with Pinch-to-Zoom\n")
        new_lines.append("            HorizontalPager(\n")
        new_lines.append("                state = pagerState,\n")
        new_lines.append("                reverseLayout = isRtlMode,\n")
        new_lines.append("                beyondViewportPageCount = 2,\n")
        new_lines.append("                userScrollEnabled = pagerScrollEnabled,\n")
        new_lines.append("                modifier = Modifier\n")
        new_lines.append("                    .fillMaxSize()\n")
        new_lines.append("                    .padding(horizontal = readerSettings.sidePadding.dp)\n")
        new_lines.append("            ) { pageIndex ->\n")
        new_lines.append("                val pageUrls = displayPages[pageIndex]\n")
        new_lines.append("                var scale by remember { mutableFloatStateOf(1f) }\n")
        new_lines.append("                var offsetX by remember { mutableFloatStateOf(0f) }\n")
        new_lines.append("                var offsetY by remember { mutableFloatStateOf(0f) }\n")
        new_lines.append("\n")
        new_lines.append("                Box(\n")
        new_lines.append("                    modifier = Modifier\n")
        new_lines.append("                        .fillMaxSize()\n")
        new_lines.append("                        .pointerInput(Unit) {\n")
        new_lines.append("                            androidx.compose.foundation.gestures.detectTransformGestures { _, pan, zoom, _ ->\n")
        new_lines.append("                                scale = (scale * zoom).coerceIn(1f, 3f)\n")
        new_lines.append("                                if (scale > 1f) {\n")
        new_lines.append("                                    offsetX += pan.x\n")
        new_lines.append("                                    offsetY += pan.y\n")
        new_lines.append("                                } else {\n")
        new_lines.append("                                    offsetX = 0f\n")
        new_lines.append("                                    offsetY = 0f\n")
        new_lines.append("                                }\n")
        new_lines.append("                            }\n")
        new_lines.append("                        },\n")
        new_lines.append("                    contentAlignment = Alignment.Center\n")
        new_lines.append("                ) {\n")
        
        # skip lines until Row(
        i += 5
        while "Row(" not in lines[i]:
            i += 1
        # Now we are at Row(
        continue # handled
        
    elif "contentAlignment = Alignment.Center" in line and "Row(" in lines[i+1] if i+1 < len(lines) else False:
        # We already handled it above, if it matched
        pass
    
    new_lines.append(line)
    i += 1
    
with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.writelines(new_lines)
    
