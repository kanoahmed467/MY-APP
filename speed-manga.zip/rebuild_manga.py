import codecs

with codecs.open('manga_full.txt', 'r', 'utf-8') as f:
    lines = f.readlines()

# Find line 439 (index 438) where `} else if (isWebtoonMode) {` is.
split_idx = -1
for i, line in enumerate(lines):
    if "} else if (isWebtoonMode) {" in line:
        split_idx = i
        break

if split_idx == -1:
    print("Could not find } else if (isWebtoonMode) {")
    exit(1)

part1 = "".join(lines[:split_idx])

# Now find the end of the reading modes and start of overlay.
# The `Row` at line 942 is the start of the Top Control Bar.
# We will just write the reading modes manually.
reading_modes = """        if (isWebtoonMode || isVerticalPaged) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
                    .pointerInput(readerSettings.tapToNavigate) {
                        detectTapGestures(
                            onTap = { offset ->
                                val screenWidth = size.width.toFloat()
                                val x = offset.x
                                val leftBoundary = screenWidth / 3f
                                val rightBoundary = (screenWidth / 3f) * 2f
                                
                                if (readerSettings.tapToNavigate) {
                                    if (x < leftBoundary) {
                                        scope.launch {
                                            val target = maxOf(0, lazyListState.firstVisibleItemIndex - 1)
                                            lazyListState.animateScrollToItem(target)
                                        }
                                    } else if (x > rightBoundary) {
                                        scope.launch {
                                            val target = minOf(displayPages.size - 1, lazyListState.firstVisibleItemIndex + 1)
                                            lazyListState.animateScrollToItem(target)
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                } else {
                                    showControls = !showControls
                                }
                            }
                        )
                    }
            ) {
                itemsIndexed(displayPages) { index, pageUrls ->
                    var retryCount by remember { mutableStateOf(0) }
                    var isWideImage by remember { mutableStateOf(false) }
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pageUrls.forEachIndexed { subIndex, pageUrl ->
                            val finalPageUrl = remember(pageUrl, retryCount) {
                                if (retryCount > 0 && pageUrl.startsWith("http")) {
                                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                } else {
                                    pageUrl
                                }
                            }
                            val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                ImageRequest.Builder(context)
                                    .data(finalPageUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .precision(coil.size.Precision.INEXACT)
                                    .crossfade(false)
                                    .build()
                            }

                            val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                androidx.compose.ui.graphics.FilterQuality.High
                            } else {
                                androidx.compose.ui.graphics.FilterQuality.Medium
                            }

                            val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                    androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                        -1f,  0f,  0f,  0f,  1f,
                                         0f, -1f,  0f,  0f,  1f,
                                         0f,  0f, -1f,  0f,  1f,
                                         0f,  0f,  0f,  1f,  0f
                                    ))
                                )
                            } else null

                            val contentScale = if (isWebtoonMode) ContentScale.FillWidth else ContentScale.Fit

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                    }
                                } else {
                                    AsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة $index-$subIndex",
                                        modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt,
                                        onSuccess = { state ->
                                            val drawable = state.result.drawable
                                            if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                                isWideImage = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Horizontal Single/Double Page Mode (RTL or LTR) with Pinch-to-Zoom
            HorizontalPager(
                state = pagerState,
                reverseLayout = isRtlMode,
                beyondViewportPageCount = 2,
                userScrollEnabled = pagerScrollEnabled,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = readerSettings.sidePadding.dp)
            ) { pageIndex ->
                val pageUrls = displayPages[pageIndex]
                var scale by remember { mutableFloatStateOf(1f) }
                var offsetX by remember { mutableFloatStateOf(0f) }
                var offsetY by remember { mutableFloatStateOf(0f) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 3f)
                                if (scale > 1f) {
                                    offsetX += pan.x
                                    offsetY += pan.y
                                } else {
                                    offsetX = 0f
                                    offsetY = 0f
                                }
                            }
                        }
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onTap = { offset ->
                                    val screenWidth = size.width.toFloat()
                                    val x = offset.x
                                    val leftBoundary = screenWidth / 3f
                                    val rightBoundary = (screenWidth / 3f) * 2f
                                    
                                    if (readerSettings.tapToNavigate) {
                                        if (x < leftBoundary) {
                                            scope.launch {
                                                val target = maxOf(0, pagerState.currentPage - 1)
                                                pagerState.animateScrollToPage(target)
                                            }
                                        } else if (x > rightBoundary) {
                                            scope.launch {
                                                val target = minOf(displayPages.size - 1, pagerState.currentPage + 1)
                                                pagerState.animateScrollToPage(target)
                                            }
                                        } else {
                                            showControls = !showControls
                                        }
                                    } else {
                                        showControls = !showControls
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetX,
                                translationY = offsetY
                            ),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        pageUrls.forEachIndexed { subIndex, pageUrl ->
                            var retryCount by remember { mutableStateOf(0) }
                            var isWideImage by remember { mutableStateOf(false) }
                            val finalPageUrl = remember(pageUrl, retryCount) {
                                if (retryCount > 0 && pageUrl.startsWith("http")) {
                                    if (pageUrl.contains("?")) "$pageUrl&retry_count=$retryCount" else "$pageUrl?retry_count=$retryCount"
                                } else {
                                    pageUrl
                                }
                            }
                            val imageRequest = remember(finalPageUrl, retryCount, MadaraScraper.cloudflareCookies, MadaraScraper.userAgent) {
                                ImageRequest.Builder(context)
                                    .data(finalPageUrl)
                                    .addHeader("User-Agent", MadaraScraper.userAgent)
                                    .addHeader("Referer", "https://mangalik.net/")
                                    .apply {
                                        if (MadaraScraper.cloudflareCookies.isNotBlank()) {
                                            addHeader("Cookie", MadaraScraper.cloudflareCookies)
                                        }
                                    }
                                    .memoryCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .diskCachePolicy(if (retryCount > 0) CachePolicy.DISABLED else CachePolicy.ENABLED)
                                    .precision(coil.size.Precision.INEXACT)
                                    .crossfade(false)
                                    .build()
                            }

                            val filterQual = if (readerSettings.imageFiltering == "BICUBIC") {
                                androidx.compose.ui.graphics.FilterQuality.High
                            } else {
                                androidx.compose.ui.graphics.FilterQuality.Medium
                            }

                            val colorFilt = if (readerSettings.tintMode == "INVERTED") {
                                androidx.compose.ui.graphics.ColorFilter.colorMatrix(
                                    androidx.compose.ui.graphics.ColorMatrix(floatArrayOf(
                                        -1f,  0f,  0f,  0f,  1f,
                                         0f, -1f,  0f,  0f,  1f,
                                         0f,  0f, -1f,  0f,  1f,
                                         0f,  0f,  0f,  1f,  0f
                                    ))
                                )
                            } else null

                            val contentScale = ContentScale.Fit

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isWideImage && readerSettings.doublePageSpread && !isLandscape) {
                                    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterEnd else Alignment.CenterStart),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .weight(1f)
                                                .clipToBounds()
                                        ) {
                                            AsyncImage(
                                                model = imageRequest,
                                                contentDescription = null,
                                                modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                                    .fillMaxWidth(2f)
                                                    .align(if (isRtlMode) Alignment.CenterStart else Alignment.CenterEnd),
                                                contentScale = ContentScale.FillWidth,
                                                filterQuality = filterQual,
                                                colorFilter = colorFilt
                                            )
                                        }
                                    }
                                } else {
                                    AsyncImage(
                                        model = imageRequest,
                                        contentDescription = "صفحة $pageIndex-$subIndex",
                                        modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = if (readerSettings.cropMargins) 1.05f else 1.0f,
                                                scaleY = if (readerSettings.cropMargins) 1.05f else 1.0f
                                            ),
                                        contentScale = contentScale,
                                        filterQuality = filterQual,
                                        colorFilter = colorFilt,
                                        onSuccess = { state ->
                                            val drawable = state.result.drawable
                                            if (drawable.intrinsicWidth > drawable.intrinsicHeight * 1.3f) {
                                                isWideImage = true
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Overlay Controls
        androidx.compose.animation.AnimatedVisibility(
            visible = showControls,
            enter = androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
"""

# Now find the Top Control Bar Overlay from manga_full.txt
top_bar_idx = -1
for i, line in enumerate(lines):
    if "Row(" in line and i > 940 and i < 945:
        # line 942 was the Row
        top_bar_idx = i
        break

if top_bar_idx == -1:
    print("Could not find Top Control Bar Overlay")
    exit(1)

part3 = "".join(lines[top_bar_idx:])

# Insert the end of Box and AnimatedVisibility before Chapter Selection Dialog
idx_dialog = part3.find("        // Chapter Selection Dialog")
if idx_dialog != -1:
    part3 = part3[:idx_dialog] + """            }
        }
        
""" + part3[idx_dialog:]

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(part1)
    f.write(reading_modes)
    f.write(part3)

print("Done rebuilding MangaReaderScreen.kt")
