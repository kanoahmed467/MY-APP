import re

with open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r') as f:
    code = f.read()

# Replace SubcomposeAsyncImage with AsyncImage
code = code.replace('SubcomposeAsyncImage(', 'AsyncImage(')
code = code.replace('import coil.compose.SubcomposeAsyncImage', 'import coil.compose.AsyncImage')

# Now for the blocks like `loading = { ... }, error = { ... }`
# These blocks can span multiple lines. Since there are only a few, we can remove them using regex or manual string replacement.

# Block 1
block1 = """loading = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(350.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CircularProgressIndicator(
                                            color = MangaRedPrimary,
                                            strokeWidth = 3.dp,
                                            modifier = Modifier.size(40.dp)
                                        )
                                    }
                                },
                                error = {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(350.dp)
                                            .clickable { retryCount++ },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Icon(
                                                imageVector = Icons.Default.Refresh,
                                                contentDescription = null,
                                                tint = MangaRedPrimary,
                                                modifier = Modifier.size(40.dp)
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "تعذر تحميل الصفحة، اضغط لإعادة المحاولة",
                                                fontSize = 13.sp,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }"""

# Block 2
block2 = """loading = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    color = MangaRedPrimary,
                                                    strokeWidth = 3.dp,
                                                    modifier = Modifier.size(40.dp)
                                                )
                                            }
                                        },
                                        error = {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(DarkBackground)
                                                    .clickable { retryCount++ },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Icon(
                                                        imageVector = Icons.Default.Refresh,
                                                        contentDescription = null,
                                                        tint = MangaRedPrimary,
                                                        modifier = Modifier.size(40.dp)
                                                    )
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Text(
                                                        text = "تعذر تحميل الصفحة، اضغط لإعادة المحاولة",
                                                        fontSize = 13.sp,
                                                        color = TextPrimary,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                        }"""

code = code.replace(block1, "")
code = code.replace(block2, "")

# We need to remove the trailing comma from onSuccess = { ... }, if it's the last argument before the closing parenthesis.
code = re.sub(r'(onSuccess\s*=\s*\{[^\}]*\})[\s,]+(\n\s*\))', r'\1\2', code, flags=re.MULTILINE)


# Now add the background modifier to the AsyncImage modifiers.
# We can search for `modifier = Modifier` inside AsyncImage calls and append `.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))`
# A simple way: find `Modifier` when it's followed by some methods, and right after `Modifier`, we add `.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))`
# Actually, it's safer to just replace `modifier = Modifier` with `modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))`
# Let's see if all AsyncImages use `modifier = Modifier`.
# Wait, replacing all `modifier = Modifier` might affect other Composables! 
# Better: use regex to only target `AsyncImage` modifiers.
# Or simpler:
# Just replace `modifier = Modifier` with `modifier = Modifier.background(androidx.compose.ui.graphics.Color(0xFF1E1E1E))` but ONLY between `AsyncImage(` and `)`, which is a bit complex in regex.
# Actually, looking at the code, all `SubcomposeAsyncImage` modifiers are on the next line:
# `modifier = Modifier\n    .fillMaxSize()` etc.

import codecs
with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(code)

