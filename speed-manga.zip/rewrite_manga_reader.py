import re

with open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r') as f:
    content = f.read()

# Replace SubcomposeAsyncImage import
content = content.replace("import coil.compose.SubcomposeAsyncImage", "import coil.compose.AsyncImage")

# We need to find `ImageRequest.Builder(context)` and add `.crossfade(false)`
# Also remove any `.crossfade(true)` if it exists.
# Wait, let's see how the ImageRequest is built.
