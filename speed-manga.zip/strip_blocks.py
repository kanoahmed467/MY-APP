import re
import codecs

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'r', 'utf-8') as f:
    code = f.read()

# Remove loading block
code = re.sub(r'loading\s*=\s*\{\s*Box\([^\{]*\{.*?CircularProgressIndicator[^\{]*\{.*?\}\s*\)\s*\}\s*\},', '', code, flags=re.DOTALL)
code = re.sub(r'loading\s*=\s*\{\s*Box\([^\{]*\{[^{}]*CircularProgressIndicator[^{}]*\}[^{}]*\}\s*\)\s*\}\s*\},?', '', code, flags=re.DOTALL)

# Let's write a generic block remover for loading and error since they are well formed.
# Better to use a stack to find matching braces.

def remove_argument(name, text):
    start = 0
    while True:
        idx = text.find(name + " = {", start)
        if idx == -1:
            idx = text.find(name + "={", start)
        if idx == -1:
            idx = text.find(name + " = \n", start) # some formatting variations
        if idx == -1:
            break
        
        # find the brace
        brace_idx = text.find('{', idx)
        if brace_idx == -1:
            start = idx + len(name)
            continue
            
        stack = 1
        end_idx = brace_idx + 1
        while stack > 0 and end_idx < len(text):
            if text[end_idx] == '{':
                stack += 1
            elif text[end_idx] == '}':
                stack -= 1
            end_idx += 1
            
        if stack == 0:
            # check if there's a comma after
            comma_idx = end_idx
            while comma_idx < len(text) and text[comma_idx] in [' ', '\t', '\n']:
                comma_idx += 1
            if comma_idx < len(text) and text[comma_idx] == ',':
                end_idx = comma_idx + 1
            text = text[:idx] + text[end_idx:]
            start = idx # continue searching from same spot
        else:
            start = end_idx
            
    return text

code = remove_argument('loading', code)
code = remove_argument('error', code)

# Clean up any trailing commas inside AsyncImage arguments
code = re.sub(r',\s*\n\s*\)', '\n)', code)

with codecs.open('app/src/main/java/com/example/ui/screens/MangaReaderScreen.kt', 'w', 'utf-8') as f:
    f.write(code)

