import coil.request.ImageRequest
import coil.size.Precision
import android.content.Context
fun test(context: Context) {
    ImageRequest.Builder(context).size(480)
}
